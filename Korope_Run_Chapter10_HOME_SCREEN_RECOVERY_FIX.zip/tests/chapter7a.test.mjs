// Milestone 7A tests: audio survives Pause -> Continue (suspended / iOS "interrupted" contexts), pause never touches the saved mute,
// one pickup sound per coin/cash, no duplicate engine loops, HTMLAudio rejection handling.
// These run against MOCKED Web Audio / HTMLAudio / localStorage. They are not real-browser or real-device tests.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';

const el = () => ({ style: {}, classList: { add() {}, remove() {} }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {}, clearRect() {}, beginPath() {}, arc() {}, fill() {}, stroke() {}, moveTo() {}, lineTo() {}, closePath() {} }) });
globalThis.document = { createElement: el, body: { appendChild() {} } }; globalThis.innerWidth = 800; globalThis.innerHeight = 600;
let seed = 4242; Math.random = () => (seed = (seed * 16807) % 2147483647) / 2147483647; // deterministic like the earlier chapters
const store = {};
globalThis.localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } };
const clearStore = () => { for (const k of Object.keys(store)) delete store[k]; };
const tick = () => new Promise((r) => setTimeout(r, 0));
let n = 0; const t = async (name, fn) => { clearStore(); await fn(); n++; console.log('  ok -', name); };

// ---- mock Web Audio
let ctxs = [], started = 0, resumeCalls = 0;
const param = () => ({ value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} });
const node = () => ({ connect() {}, disconnect() {}, gain: param(), frequency: param(), type: '', buffer: null, start() { started++; }, stop() {}, onended: null });
class MockCtx {
  constructor() { this.state = 'suspended'; this.currentTime = 0; this.sampleRate = 8000; this.destination = {}; ctxs.push(this); }
  resume() { resumeCalls++; this.state = 'running'; return Promise.resolve(); }
  createGain() { return node(); } createOscillator() { return node(); } createBiquadFilter() { return node(); } createBufferSource() { return node(); }
  createBuffer(c, l) { return { getChannelData: () => new Float32Array(l) }; }
}
class DecodingCtx extends MockCtx { decodeAudioData(ab, ok) { const b = { duration: 0.36 }; ok && ok(b); return Promise.resolve(b); } }
globalThis.window = globalThis;
const reset = (Ctx = MockCtx) => { ctxs = []; started = 0; resumeCalls = 0; globalThis.AudioContext = Ctx; };
// Audio mock (HTMLAudio)
let htmlPlays = 0, htmlReject = false;
globalThis.Audio = class { constructor(src) { this.src = String(src); this.volume = 1; this.currentTime = 0; } pause() {} play() { htmlPlays++; return htmlReject ? Promise.reject(new Error('NotAllowedError')) : Promise.resolve(); } };
// fetch mock for the pickup buffer
let fetchUrls = [];
globalThis.fetch = async (u) => { fetchUrls.push(String(u)); return { ok: true, arrayBuffer: async () => new ArrayBuffer(8) }; };

const { Sound } = await import('../src/audio.js');
const { createWorld } = await import('../src/world.js');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const audioSrc = fs.readFileSync(new URL('../src/audio.js', import.meta.url), 'utf8');

const pausedBody = main.slice(main.indexOf('function setPaused(p)'), main.indexOf('function startGame()'));

await t('Pause -> Continue wakes a SUSPENDED context; engine and coin sound come back', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick(); assert.equal(s.ready, true);
  s.engine(20, true, 0.1); s.engine(20, true, 0.1); assert(s.eng.g.gain.value > 0, 'engine audible while driving');
  s.pauseAudio(); assert.equal(s.eng.g.gain.value, 0, 'engine hum cut on pause');
  ctxs[0].state = 'suspended'; // the browser/OS suspends the context while paused or hidden
  htmlPlays = 0; started = 0; s.coin(); assert.equal(started, 0, 'no Web Audio source while the context is suspended (and no crash)');
  s.unlock(); await tick(); // Continue
  assert.equal(ctxs[0].state, 'running'); assert.equal(ctxs.length, 1, 'no new AudioContext on Continue');
  for (let i = 0; i < 20; i++) s.engine(20, true, 0.05); assert(s.eng.g.gain.value > 0.02, 'engine restored after Continue');
  htmlPlays = 0; started = 0; s.coin(); assert.equal(started + htmlPlays, 1, 'coin sound plays exactly once after Continue');
});

await t('iOS "interrupted" state is resumed too (old code only handled "suspended")', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick(); ctxs[0].state = 'interrupted'; assert.equal(s.ready, false);
  s.unlock(); await tick(); assert.equal(ctxs[0].state, 'running'); assert.equal(s.ready, true);
});

await t('20 Pause/Continue cycles: one context, one engine oscillator, sound still works', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick(); s.engine(15, true, 0.1); const afterEngine = started;
  for (let i = 0; i < 20; i++) { s.pauseAudio(); ctxs[0].state = 'suspended'; s.unlock(); await tick(); s.engine(15, true, 0.05); }
  assert.equal(ctxs.length, 1); assert.equal(started, afterEngine, 'engine oscillator started exactly once');
  started = 0; s.bump(); assert.equal(started, 1);
});

await t('pause never changes the saved preference; Continue never forces sound on', async () => {
  reset(); const s = new Sound(); s.unlock(); s.setOn(false); const snap = JSON.stringify(store);
  assert.equal(store.koroperun_sound, 'off'); assert.equal(store.koroperun_game_sound, '0');
  for (let i = 0; i < 5; i++) { s.pauseAudio(); s.unlock(); s.resume(); await tick(); }
  assert.equal(s.on, false); assert.equal(JSON.stringify(store), snap, 'storage identical after pause/continue');
  started = 0; htmlPlays = 0; s.coin(); s.cash(); s.bump(); s.crash(); s.engine(20, true, 0.5); assert.equal(started <= 0 || s.eng.g.gain.value === 0, true);
  assert.equal(htmlPlays, 0, 'muted = no pickup audio'); assert.equal(new Sound().on, false, 'mute survives a reload');
  s.setOn(true); assert.equal(store.koroperun_game_sound, '1'); assert.equal(new Sound().on, true);
});

await t('Settings key and legacy key can no longer disagree (mute wins, then both are normalised)', () => {
  store.koroperun_game_sound = '0'; store.koroperun_sound = 'on'; assert.equal(new Sound().on, false);
  assert.equal(store.koroperun_game_sound, '0'); assert.equal(store.koroperun_sound, 'off');
  clearStore(); store.koroperun_sound = 'off'; assert.equal(new Sound().on, false); assert.equal(store.koroperun_game_sound, '0');
  clearStore(); assert.equal(new Sound().on, true, 'no saved choice = default on');
});

await t('local WAV is decoded once and every coin / cash pickup plays it exactly once', async () => {
  reset(DecodingCtx); fetchUrls = []; htmlPlays = 0; const s = new Sound(); s.unlock(); s.unlock(); await tick(); await tick();
  assert.equal(fetchUrls.length, 1, 'fetched once'); assert(fetchUrls[0].endsWith('/assets/coin-pickup.wav') && !/youtube|youtu\.be/i.test(fetchUrls[0]));
  assert(s.pickupBuf, 'buffer decoded');
  for (let i = 0; i < 5; i++) { started = 0; s.coin(); assert.equal(started, 1, 'coin #' + i + ' = one source'); }
  for (let i = 0; i < 5; i++) { started = 0; s.cash(); assert.equal(started, 1, 'cash #' + i + ' = one source'); }
  assert.equal(htmlPlays, 0, 'buffer path used, no double playback from HTMLAudio');
});

await t('pickup after a Pause/Continue cycle still plays once (buffer path)', async () => {
  reset(DecodingCtx); const s = new Sound(); s.unlock(); await tick(); await tick();
  for (let i = 0; i < 6; i++) { s.pauseAudio(); ctxs[0].state = 'suspended'; s.unlock(); await tick(); started = 0; s.coin(); assert.equal(started, 1); }
});

await t('HTMLAudio rejection (mobile autoplay) falls back to the synthesized cue exactly once; no throw', async () => {
  reset(); htmlPlays = 0; htmlReject = true; const s = new Sound(); s.unlock(); await tick(); started = 0; s.coin(); await tick(); await tick();
  assert.equal(htmlPlays, 1); assert.equal(started, 3, 'cash-style three-tone fallback played once'); htmlReject = false;
});

await t('missing / failing asset is handled: no crash, synthesized fallback still plays', async () => {
  reset(DecodingCtx); const orig = globalThis.fetch; globalThis.fetch = async () => ({ ok: false, status: 404 });
  globalThis.Audio = undefined; const s = new Sound(); s.unlock(); await tick(); await tick(); assert.equal(s.pickupBuf, null);
  started = 0; s.coin(); assert.equal(started, 3); globalThis.fetch = orig;
  globalThis.Audio = class { constructor(src) { this.src = String(src); this.volume = 1; this.currentTime = 0; } pause() {} play() { htmlPlays++; return Promise.resolve(); } };
});

await t('rapid repeated taps resume the context once while a resume is pending', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick(); ctxs[0].state = 'suspended'; resumeCalls = 0;
  for (let i = 0; i < 50; i++) s.resume(); assert.equal(resumeCalls, 1); await tick(); assert.equal(ctxs[0].state, 'running');
});

await t('a context the browser CLOSED is rebuilt with exactly one new engine (no duplicate loops)', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick(); s.engine(20, true, 0.1); ctxs[0].state = 'closed';
  s.unlock(); await tick(); assert.equal(ctxs.length, 2); started = 0; s.engine(20, true, 0.1); s.engine(20, true, 0.1); s.engine(20, true, 0.1);
  assert.equal(started, 1, 'one new engine oscillator on the new context');
});

await t('crash / restart / menu: engine is silent when not playing, restart does not stack loops', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick(); s.engine(25, true, 0.1); const base = started;
  for (let i = 0; i < 10; i++) { s.crash(); s.engine(0, false, 0.1); s.silence(); s.unlock(); s.engine(25, true, 0.05); }
  const engineStarts = started - base; // crash makes 2 sources each; engine must add none
  assert.equal(engineStarts, 10 * 2, 'only the 10 crash sounds started; engine was never recreated');
  for (let i = 0; i < 60; i++) s.engine(0, false, 0.1); assert.equal(s.eng.g.gain.value, 0, 'menu / game over = engine silent');
});

await t('failed AudioContext constructor never throws and does not wedge a later retry', async () => {
  reset(class { constructor() { throw new Error('no audio'); } }); const s = new Sound(); s.unlock(); s.coin(); s.engine(10, true, 0.1); s.pauseAudio(); s.resume();
  reset(); s.unlock(); await tick(); assert.equal(s.ready, true);
});

await t('real world: each coin triggers the handler exactly once, also across pause/resume cycles (world is frozen while paused)', () => {
  const w = createWorld(new THREE.Scene()); let calls = 0; w.setCoinHandler(() => calls++);
  let got = 0, z = 0;
  for (let cycle = 0; cycle < 8; cycle++) { for (let i = 0; i < 400; i++) { got += w.update(0.016, 0, z, 0, true); z -= 0.25; } /* pause: main.js does not call world.update */ }
  assert(got > 0); assert.equal(calls, got, 'handler calls == coins collected');
  const zc = z; for (let i = 0; i < 100; i++) got += w.update(0.016, 0, zc, 0, true); assert.equal(calls, got);
});

await t('main.js wiring: Continue unlocks/resumes, Pause only cuts audio, no duplicate handlers, single sound flag', () => {
  assert(/if \(p\) \{[^}]*sound\.pauseAudio\(\)/.test(pausedBody), 'pause cuts audio'); assert(/else sound\.unlock\(\)/.test(pausedBody), 'Continue unlocks');
  assert(!/sound\.(toggle|setOn)|localStorage/.test(pausedBody), 'setPaused never touches mute/preferences');
  assert(!main.includes('localStorageSoundEnabled'), 'second divergent sound flag removed from the coin handler');
  assert.equal(main.split('world.setCoinHandler(').length - 1, 1); assert.equal(main.split('world.setCashHandler(').length - 1, 1);
  assert.equal(main.split("addEventListener('visibilitychange'").length - 1, 1); assert.equal(main.split("addEventListener('keydown'").length - 1, 1);
  assert(main.includes('sound.resume()')); assert(/if \(state === 'playing'\) \{\s*\n\s*bus\.update/.test(main), 'world only updates during active gameplay, so it stays frozen while paused, in Home, and after Game Over');
  assert(!/new (Webkit)?AudioContext/.test(main), 'no AudioContext creation in main.js'); assert((audioSrc.match(/new AC\(\)/g) || []).length === 1, 'one construction site');
  assert(!/https?:\/\/|youtu\.be/i.test(audioSrc + main), 'no remote (YouTube or other) audio URL anywhere in the runtime sources');
  assert(fs.existsSync(new URL('../assets/coin-pickup.wav', import.meta.url)));
});

console.log('Chapter 7A tests passed:', n);
