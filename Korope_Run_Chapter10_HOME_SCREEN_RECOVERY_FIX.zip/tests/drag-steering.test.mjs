// Drag-to-steer + bold translucent GAS/BRAKE tests. Logic/markup level with a fake DOM; no real browser or device is used.
import assert from 'node:assert/strict';
import fs from 'node:fs';
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };
const mk = () => ({ on: {}, addEventListener(ty, fn) { (this.on[ty] ||= []).push(fn); }, fire(ty, ev = {}) { (this.on[ty] || []).forEach(f => f({ preventDefault() { ev.prevented = true; }, ...ev })); return ev; } });
const cls = () => { const set = new Set(); return { set, add: c => set.add(c), remove: c => set.delete(c), toggle: (c, on) => (on ? set.add(c) : set.delete(c)) }; };
const win = mk(); globalThis.addEventListener = (ty, f) => win.addEventListener(ty, f);
const B = ds => Object.assign(mk(), { dataset: ds, classList: cls(), setPointerCapture() {} });
const gas = B({ hold: 'gas' }), brake = B({ hold: 'brake' }), rev = B({ hold: 'reverse' }), J = B({ jump: '' });
const props = {}; const zone = Object.assign(mk(), { classList: cls(), style: { setProperty: (k, v) => { props[k] = v; } }, getBoundingClientRect: () => ({ left: 0, width: 300 }), setPointerCapture() {} });
zone.captured = null; zone.setPointerCapture = id => { zone.captured = id; };
const sets = { '[data-hold]': [gas, brake, rev], '[data-jump]': [J] };
globalThis.document = { getElementById: id => (id === 'steerZone' ? zone : null), querySelectorAll: s => sets[s] || [], createElement: () => ({ style: {}, classList: { add() {}, remove() {} }, getContext: () => null }) };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
const { Controls, DRAG_LIMIT, DRAG_MAX_RATE } = await import('../src/controls.js');
const { Korope } = await import('../src/vehicle.js');
const { ROAD } = await import('../src/world.js');
const DT = 1 / 60;
const fresh = () => { const c = new Controls(); const b = new Korope(); b.speed = 15; return { c, b }; };
const run = (c, b, secs, g = true) => { for (let i = 0; i < Math.round(secs * 60); i++) { c.held.gas = g; c.update(DT, b.x); b.update(DT, c, true); } };
const down = (id, x) => zone.fire('pointerdown', { pointerId: id, clientX: x, target: zone });
const move = (id, x) => zone.fire('pointermove', { pointerId: id, clientX: x });
const up = (id) => zone.fire('pointerup', { pointerId: id });
const tap = (btn, id) => btn.fire('pointerdown', { pointerId: id });

t('drag limit is the outer lane centre and stays inside the road limit', () => { assert.equal(DRAG_LIMIT, 4); assert(DRAG_LIMIT < ROAD.soft && DRAG_LIMIT < ROAD.limit); });
t('touch-down alone does not steer: the target starts exactly at the korope x (no jump)', () => {
  const { c, b } = fresh(); run(c, b, 1); b.x = 2.3; c.update(DT, b.x); down(1, 100); assert.equal(c.dragTarget, 2.3); const x0 = b.x; run(c, b, 1); assert(Math.abs(b.x - x0) < 0.2, 'stays put without finger movement: ' + b.x);
});
t('dragging right moves the korope right, dragging left moves it left, smoothly and in proportion', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 100); move(1, 100 + 70); run(c, b, 3); const r = b.x; assert(r > 0.5 && r < 4, 'right x=' + r);
  move(1, 100 - 70); run(c, b, 4); assert(b.x < r - 1, 'moved left again x=' + b.x); up(1);
});
t('larger drag = further sideways; one full drag span sweeps the road; target and korope never exceed the road', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 20); let maxAbs = 0, maxTarget = 0;
  move(1, 20 + 100000); for (let i = 0; i < 600; i++) { run(c, b, DT); maxAbs = Math.max(maxAbs, Math.abs(b.x)); maxTarget = Math.max(maxTarget, Math.abs(c.dragTarget)); }
  assert(maxTarget <= DRAG_LIMIT + 1e-9); assert(maxAbs <= ROAD.limit + 1e-9, 'x ' + maxAbs); assert(Math.abs(b.x - 4) < 0.1, 'settles in the right lane'); move(1, 20 - 100000); run(c, b, 6); assert(Math.abs(b.x + 4) < 0.1, 'settles in the left lane'); up(1);
});
t('no sudden jumps: the target speed is capped and yaw/steering stay within limits even for an instant huge finger jump', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 150); move(1, 150 + 5000); let prev = c.dragTarget, maxStep = 0, maxYaw = 0;
  for (let i = 0; i < 120; i++) { run(c, b, DT); maxStep = Math.max(maxStep, Math.abs(c.dragTarget - prev)); prev = c.dragTarget; maxYaw = Math.max(maxYaw, Math.abs(b.yaw)); }
  assert(maxStep <= DRAG_MAX_RATE * DT + 1e-9, 'target step ' + maxStep); assert(maxYaw <= 0.32 + 1e-9);
});
t('smooth settling: little overshoot (< 0.3 m) when the drag target stops', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 100); move(1, 100 + 140); let over = -9; for (let i = 0; i < 300; i++) { run(c, b, DT); over = Math.max(over, b.x - c.dragGoal); } assert(over < 0.3, 'overshoot ' + over);
});
t('release clears the drag: steering target is null, the korope straightens out and keeps going; nothing sticks', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 100); move(1, 190); run(c, b, 0.6); assert(c.dragging); assert(zone.classList.set.has('dragging'));
  up(1); assert.equal(c.dragTarget, null); assert(!c.dragging); assert(!zone.classList.set.has('dragging')); run(c, b, 2); assert(Math.abs(b.yaw) < 0.02, 'yaw ' + b.yaw); const x = b.x; run(c, b, 1); assert(Math.abs(b.x - x) < 0.1, 'goes straight');
});
t('all release paths clear the drag: pointercancel, lostpointercapture, window pointerup, window blur', () => {
  for (const how of ['pointercancel', 'lostpointercapture', 'win-up', 'win-cancel', 'blur']) {
    const { c } = fresh(); down(3, 100); move(3, 150); assert(c.dragging);
    if (how === 'win-up') win.fire('pointerup', { pointerId: 3 }); else if (how === 'win-cancel') win.fire('pointercancel', { pointerId: 3 }); else if (how === 'blur') win.fire('blur'); else zone.fire(how, { pointerId: 3 });
    assert(!c.dragging && c.dragTarget === null, how);
  }
});
t('only one finger steers: a second finger on the zone is ignored and cannot release or move the first', () => {
  const { c } = fresh(); down(1, 100); down(2, 250); move(2, 280); assert.equal(c.dragPointer, 1); const g = c.dragGoal; up(2); assert(c.dragging); assert.equal(c.dragGoal, g); move(1, 130); assert(c.dragGoal !== g); up(1);
});
t('touch that starts on GAS, BRAKE, REVERSE or JUMP never steers; those buttons are not in the zone', () => {
  const { c } = fresh(); tap(gas, 1); tap(brake, 2); tap(rev, 3); tap(J, 4); assert(!c.dragging); move(1, 400); assert.equal(c.dragTarget, null);
  const child = zone.fire('pointerdown', { pointerId: 9, clientX: 50, target: {} }); assert(!c.dragging, 'event whose target is not the zone itself is ignored');
});
t('steering drag + GAS held together: independent, simultaneous, and releasing either leaves the other', () => {
  const { c, b } = fresh(); tap(gas, 11); down(12, 100); move(12, 190); assert.equal(c.throttle, 1); assert(c.dragging);
  win.fire('pointerup', { pointerId: 11 }); assert.equal(c.throttle, 0); assert(c.dragging); up(12); assert(!c.dragging);
  tap(gas, 13); down(14, 100); up(14); assert.equal(c.throttle, 1, 'ending the drag leaves GAS held'); win.fire('pointerup', { pointerId: 13 });
});
t('GAS accelerates while held and releasing it clears throttle; BRAKE slows and releasing clears; no cross activation', () => {
  const { c, b } = fresh(); b.speed = 0; tap(gas, 1); assert.deepEqual([c.throttle, c.brake, c.reverse], [1, 0, 0]); for (let i = 0; i < 240; i++) { c.update(DT, b.x); b.update(DT, c, true); } const top = b.speed; assert(top > 15);
  win.fire('pointerup', { pointerId: 1 }); assert.equal(c.throttle, 0); assert(!gas.classList.set.has('on'));
  tap(brake, 2); assert.deepEqual([c.throttle, c.brake, c.reverse], [0, 1, 0]); for (let i = 0; i < 60; i++) b.update(DT, c, true); assert(b.speed < top - 5); win.fire('pointerup', { pointerId: 2 }); assert.equal(c.brake, 0); assert(!brake.classList.set.has('on'));
  for (let i = 0; i < 400; i++) b.update(DT, c, true); assert.equal(b.speed, 0);
});
t('GAS and BRAKE held together = existing physics (brake wins, no input lock); each releases independently; second finger cannot hijack a button', () => {
  const { c, b } = fresh(); tap(gas, 1); tap(brake, 2); assert.deepEqual([c.throttle, c.brake], [1, 1]); win.fire('pointerup', { pointerId: 2 }); assert.deepEqual([c.throttle, c.brake], [1, 0]);
  tap(gas, 5); win.fire('pointerup', { pointerId: 5 }); assert.equal(c.throttle, 1, 'stale finger 5 cannot release finger 1'); win.fire('pointerup', { pointerId: 1 }); assert.equal(c.throttle, 0);
});
t('REVERSE keeps the existing safe reverse logic and JUMP still triggers the existing jump', () => {
  const { c, b } = fresh(); b.speed = 0; tap(rev, 1); for (let i = 0; i < 180; i++) b.update(DT, c, true); assert.equal(b.dir, -1); assert(b.speed > 1 && b.speed <= 6); win.fire('pointerup', { pointerId: 1 });
  const k = fresh(); k.b.speed = 10; tap(J, 2); assert.equal(k.c.jump, true); k.b.update(DT, k.c, true); assert(k.b.jumpTime > 0.7); assert.equal(k.c.jump, false);
});
t('inactive states (menu, pause, crash): setEnabled(false) ends a drag, releases GAS/BRAKE and ignores new touches and keys; pause key still works', () => {
  const { c } = fresh(); tap(gas, 1); down(2, 100); move(2, 180); c.setEnabled(false); assert.deepEqual([c.throttle, c.brake, c.reverse, c.jump], [0, 0, 0, false]); assert(!c.dragging && c.dragTarget === null);
  down(3, 100); tap(gas, 4); tap(J, 5); win.fire('keydown', { code: 'KeyW' }); assert(!c.dragging); assert.equal(c.throttle, 0); assert.equal(c.jump, false);
  let paused = 0; c.onPause = () => paused++; win.fire('keydown', { code: 'KeyP', repeat: false }); assert.equal(paused, 1); c.setEnabled(true); down(6, 100); assert(c.dragging); up(6);
});
t('pause / resume: reset() mid-drag ends the drag cleanly; after resume a fresh touch starts from the korope x', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 100); move(1, 200); run(c, b, 1); c.reset(); assert(!c.dragging); run(c, b, 2); const x = b.x; down(2, 150); c.update(DT, b.x); assert(Math.abs(c.dragTarget - x) < 0.05, "starts from the korope x"); up(2);
});
t('vehicle ignores the drag target and jump when not playing (menu, pause, crash)', () => { const { c, b } = fresh(); c.dragTarget = 4; c.jumpRequested = true; for (let i = 0; i < 120; i++) b.update(DT, c, false); assert.equal(b.x, 0); assert.equal(b.jumpTime, 0); });
t('keyboard unchanged and takes priority over the drag target (A/D/arrows steer; W/S/R/Space/P work)', () => {
  const { c, b } = fresh(); run(c, b, 1); down(1, 100); move(1, 200); win.fire('keydown', { code: 'ArrowLeft' }); assert.equal(c.steer, -1); run(c, b, 0.5, true); assert(b.x < 0.1, 'keyboard left wins x=' + b.x); win.fire('keyup', { code: 'ArrowLeft' }); up(1);
  win.fire('keydown', { code: 'KeyD' }); assert.equal(c.steer, 1); win.fire('keyup', { code: 'KeyD' }); win.fire('keydown', { code: 'KeyW' }); assert.equal(c.throttle, 1); win.fire('keyup', { code: 'KeyW' });
});
t('drag zone blocks page scroll on itself only (touchstart/touchmove/contextmenu) and uses pointer events only', () => {
  assert(zone.fire('touchstart').prevented && zone.fire('touchmove').prevented && zone.fire('contextmenu').prevented); const c = fresh().c; const before = c.dragging; zone.fire('touchstart', {}); zone.fire('click', {}); assert.equal(c.dragging, before);
  assert(down(20, 10).prevented); up(20);
});
t('duplicate events: a repeated pointerdown for the same drag pointer does not restart it', () => {
  const { c } = fresh(); down(1, 100); move(1, 160); const g = c.dragGoal; down(1, 300); assert.equal(c.dragGoal, g); up(1);
});

// ---- markup / CSS / source ----
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8'), css = fs.readFileSync(new URL('../css/style.css', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8'), ctrlSrc = fs.readFileSync(new URL('../src/controls.js', import.meta.url), 'utf8');
t('no lane buttons or wheel left; one drag zone', () => { for (const f of ['index.html', 'css/style.css', 'src/controls.js', 'src/main.js', 'src/vehicle.js']) { const s = fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8').replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, ''); assert(!/steeringWheel|steering-wheel|wheelAngle|WHEEL_|data-lane|tapLane|lane-pad/.test(s), f); } assert.equal((html.match(/id="steerZone"/g) || []).length, 1); });
t('GAS: bold label + accelerator SVG icon + green translucent background + visible border + pressed state', () => {
  assert(/data-hold="gas"[^>]*><svg class="ico-svg"[\s\S]*?<\/svg><b>GAS<\/b>/.test(html)); assert(/\.big-row \.gas\{[^}]*rgba\(34,197,94,\.5\d?\)/.test(css)); assert(/\.big-row \.gas\{[^}]*border-color:#c8ffd9/.test(css));
  assert(/#touch button\{[^}]*border:3px solid/.test(css)); assert(/\.big-row \.gas\.on[^{]*\{[^}]*rgba\(34,197,94,\.8/.test(css)); assert(/\.big-row b\{[^}]*font-weight:1000[^}]*text-shadow/.test(css));
});
t('BRAKE: bold label + brake SVG icon + red translucent background + visible border + pressed state', () => {
  assert(/data-hold="brake"[^>]*><svg class="ico-svg"[\s\S]*?<\/svg><b>BRAKE<\/b>/.test(html)); assert(/\.big-row \.brk\{[^}]*rgba\(239,68,68,\.5\d?\)/.test(css)); assert(/\.big-row \.brk\{[^}]*border-color:#ffd0d0/.test(css)); assert(/\.big-row \.brk\.on[^{]*\{[^}]*rgba\(239,68,68,\.8/.test(css));
});
t('translucency never hurts readability: backgrounds are 0.5-0.65 alpha (not faint), white text with dark outline shadow', () => { for (const m of css.match(/\.big-row \.(gas|brk)\{[^}]*\}/g)) { const a = Number(m.match(/rgba\([\d,]+,(\.\d+)\)/)[1]); assert(a >= 0.5 && a <= 0.7, m); } assert(/#touch button\{[^}]*color:#fff/.test(css)); });
t('GAS/BRAKE are large (>= 72px, up to 118px), on the right, GAS outermost; JUMP and REVERSE are smaller and above them', () => {
  assert(/--g:clamp\(76px,min\(22vw,22vh\),118px\)/.test(css)); assert(html.indexOf('id="steerZone"') < html.indexOf('class="pad"')); assert(html.indexOf('data-hold="brake"') < html.indexOf('data-hold="gas"')); assert(html.indexOf('data-jump') < html.indexOf('data-hold="brake"')); assert(/#touch \.pad\{[^}]*margin-left:auto/.test(css));
});
t('layering: drag zone (z 1) sits UNDER the buttons (z 2) and the HUD/pause/mute are never inside the zone (it starts below the HUD)', () => {
  assert(/#touch \.steer-zone\{[^}]*z-index:1/.test(css)); assert(/#touch \.pad\{[^}]*z-index:2/.test(css)); const top = css.match(/#touch \.steer-zone\{[^}]*top:clamp\((\d+)px/); assert(Number(top[1]) >= 100, 'zone starts below the HUD row'); assert(/#touch \.steer-zone\{[^}]*width:56%/.test(css));
  assert(/#pauseBtn\{[^}]*pointer-events:auto/.test(css) && /#soundBtn\{[^}]*pointer-events:auto/.test(css));
});
t('subtle transparent zone, safe areas respected, pressed/dragging feedback, ignores nothing else', () => {
  assert(/\.steer-zone\{[^}]*rgba\(255,255,255,\.0\d\)/.test(css)); assert(/\.steer-zone\.dragging\{/.test(css)); assert(/safe-area-inset-left/.test(css.match(/\.steer-zone\{[^}]*\}/)[0])); assert(/#touch\{[^}]*padding:0 max\(14px,env\(safe-area-inset-right\)\)/.test(css)); assert(/\.steer-hint\{[^}]*pointer-events:none/.test(css)); assert(/\.steer-ring\{[^}]*pointer-events:none/.test(css));
});
t('HUD, minimap, magnet, Terminal arrow stay clear and touch-transparent; trip panel measured from the action pad; hint above controls', () => {
  for (const sel of ['#hud', '#terminalArrow', '#trip', '#magnetStat']) assert(new RegExp(`${sel}\\{[^}]*pointer-events:none`).test(css), sel);
  assert(fs.readFileSync(new URL('../src/trippanel.js', import.meta.url), 'utf8').includes("'#touch .pad'")); assert(/#hint\{[^}]*bottom:clamp\(128px,22vh,160px\)/.test(css));
});
t('responsive: buttons fit beside a 50-56% drag zone on 320-1024 px wide screens (buttons win the overlap, zone stays >= 45% wide)', () => {
  for (const W of [320, 360, 390, 412, 568, 844, 1024]) { const g = W <= 380 ? 72 : Math.max(76, Math.min(0.22 * W, 118, 0.22 * 400)); const gap = Math.max(6, Math.min(0.018 * W, 12)); const pad = 2 * g + gap; const zonePct = W <= 380 ? 0.52 : W >= 700 ? 0.48 : 0.56; assert(pad <= W * (1 - zonePct) + 0.2 * W, `${W}: pad ${Math.round(pad)} vs free ${Math.round(W * (1 - zonePct))}`); assert(zonePct * W >= 0.45 * W); assert(pad + zonePct * W * 0.5 <= W, W); }
});
t('landscape phones and tablets have their own sizing; desktop (fine pointer) hides touch UI and keeps the keyboard', () => {
  assert(/max-height:480px\) and \(pointer:coarse\)/.test(css)); assert(/min-width:700px\) and \(pointer:coarse\)/.test(css)); assert(/#touch\{position:fixed[^}]*display:none/.test(css)); assert(/@media\(pointer:coarse\)\{#touch\{display:flex\}\}/.test(css));
  for (const k of ["gas: ['ArrowUp', 'KeyW']", "brake: ['ArrowDown', 'KeyS']", "reverse: ['KeyR']", "left: ['ArrowLeft', 'KeyA']", "right: ['ArrowRight', 'KeyD']", "jump: ['Space']"]) assert(ctrlSrc.includes(k), k); assert(/html,body\{[^}]*overflow:hidden[^}]*touch-action:none/.test(css));
});
t('main.js wiring: input only while playing; korope x fed to controls; reset on pause/crash/home/restart; existing physics reused (no second steering system)', () => {
  assert(/controls\.enabled !== active\) controls\.setEnabled\(active\)/.test(main)); assert(main.includes('controls.update(dt, bus.x)')); assert((main.match(/controls\.reset\(\)/g) || []).length >= 5);
  const v = fs.readFileSync(new URL('../src/vehicle.js', import.meta.url), 'utf8'); assert(v.includes('const targetYaw = -steer * 0.32 * grip * dir')); assert(v.includes('typeof input.dragTarget')); assert(!/addEventListener|pointer/i.test(v));
});
t('tutorial/start text describes dragging, not a wheel or lane buttons', () => { assert(/<b>Drag<\/b> your thumb left or right/.test(html)); assert(/drag the left side to steer/.test(html)); assert(!/steering wheel|LEFT \/ MIDDLE/i.test(html)); });
t('preserved features still present (korope text, wallets, garage, leaderboard, settings, mute, pause, magnet, arrow, restart)', () => {
  assert(fs.readFileSync(new URL('../src/vehicle.js', import.meta.url), 'utf8').includes('OSOGBO TO THE WORLD')); for (const id of ['coins', 'cash', 'terminalArrow', 'minimap', 'garageBtn', 'leaderboardBtn', 'settingsBtn', 'soundBtn', 'pauseBtn', 'magnetStat', 'restartBtn', 'walletBalance', 'pauseCash']) assert(html.includes(`id="${id}"`), id);
});
console.log('Drag steering tests passed:', n);
