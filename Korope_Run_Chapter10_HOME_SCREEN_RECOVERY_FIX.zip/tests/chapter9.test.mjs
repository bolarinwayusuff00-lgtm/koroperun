// Chapter 9: connected Osogbo city streets and landmark layer.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';
import { createWorld, CITY_JUNCTIONS, CITY_LANDMARKS } from '../src/world.js';
const mockElement = () => ({ style: {}, classList: { add() {}, remove() {}, toggle() {} }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {}, beginPath() {}, arc() {}, fill() {}, stroke() {}, moveTo() {}, lineTo() {}, closePath() {} }) });
globalThis.document = { createElement: mockElement, body: { appendChild() {} } };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('  ok -', name); }

test('city map defines a connected sequence of named cross streets including existing route areas', () => {
  assert(CITY_JUNCTIONS.length >= 10);
  assert.deepEqual([...CITY_JUNCTIONS].sort((a,b)=>a.d-b.d), CITY_JUNCTIONS);
  for (const name of ['STATION ROAD','OLD GARAGE','OJA OBA','IGBONA','LAMENCO','ALEKUWODO','OKE BAALE','GRA','OROKI ESTATE','ILOBU ROAD','GBODOFON']) assert(CITY_JUNCTIONS.some(j=>j.name===name), name);
  assert(CITY_JUNCTIONS.every((j,i)=>Number.isFinite(j.d) && j.d >= 0 && (i===0 || j.d>CITY_JUNCTIONS[i-1].d)));
});

test('recognisable landmark set includes market, central mosque, Nike Art Centre and Sacred Grove', () => {
  assert.deepEqual(CITY_LANDMARKS.map(x=>x.id), ['oja-oba-market','central-mosque','nike-art-centre','sacred-grove']);
  assert(CITY_LANDMARKS.every(x=>x.d>0 && x.d<2600));
});

test('city geometry is built into the actual scene and follows the trip origin on restart', () => {
  const scene = new THREE.Scene(), world = createWorld(scene, { trafficRandom: () => 0.9 });
  const city = scene.children.find(o => o.isGroup && o.children.length > 200);
  assert(city, 'city layer should be present in the game scene');
  assert.equal(world.cityMap.junctions.length, CITY_JUNCTIONS.length);
  world.setRouteOrigin(-125);
  assert(scene.children.some(o => o.isGroup && o.position.z === -125 && o.children.length > 200), 'city layer follows new trip origin');
  assert(city.children.length > 200, 'city contains roads, street furniture and landmark meshes');
});

test('chapter 9 remains additive and preserves the existing route and gameplay integration', () => {
  const route = fs.readFileSync(new URL('../src/route.js', import.meta.url), 'utf8');
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  const world = fs.readFileSync(new URL('../src/world.js', import.meta.url), 'utf8');
  assert(route.includes('LAMENCO_D = 1000') && route.includes('AGUNBELEWO_D = 2600'));
  assert(main.includes('new Korope()') && main.includes('world.update(dt, bus.x, bus.z, t, state === \'playing\')'));
  assert(world.includes('const city = buildCity(); scene.add(city.g)'));
  assert(world.includes('route.g.position.z = z; city.g.position.z = z'));
});
console.log('Chapter 9 tests passed:', passed);
