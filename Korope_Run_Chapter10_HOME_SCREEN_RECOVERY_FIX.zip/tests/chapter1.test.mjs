// Chapter 1 controls tests (updated for Hybrid Steering): keyboard, hold pedals and markup. Lane tests live in hybrid-steering.test.mjs.
import assert from 'node:assert/strict';
import fs from 'node:fs';
let n=0; const t=(name,fn)=>{fn();n++;console.log('  ok -',name);};
const listeners=()=>({on:{},addEventListener(type,fn){(this.on[type]||=[]).push(fn);},fire(type,ev={}){(this.on[type]||[]).forEach(f=>f({preventDefault(){ev.prevented=true;},...ev}));return ev;}});
const win=listeners();globalThis.addEventListener=(t,f)=>win.addEventListener(t,f);
function btn(dataset={}){return Object.assign(listeners(),{dataset,classList:{values:new Set(),add(c){this.values.add(c)},remove(c){this.values.delete(c)},toggle(c,v){if(v)this.values.add(c);else this.values.delete(c)}},setPointerCapture(){}});}
const holds=[btn({hold:'gas'}),btn({hold:'brake'}),btn({hold:'reverse'})];
globalThis.document={getElementById(){return null;},querySelectorAll(sel){return sel==='[data-hold]'?holds:[];}};
const {Controls}=await import('../src/controls.js'); const c=new Controls();
t('steering is a single left-side drag zone: no window-level move listeners, no wheel, no lane buttons',()=>{const src=fs.readFileSync(new URL('../src/controls.js',import.meta.url),'utf8').replace(/\/\/.*$/gm,'');assert(src.includes('steerZone'));assert(!/wheelAngle|WHEEL_|data-lane/.test(src));assert(!/(^|[^.\w])addEventListener\('pointermove'/m.test(src));});
t('keyboard A/D and arrows remain available (held steering)',()=>{win.fire('keydown',{code:'ArrowLeft'});assert.equal(c.steer,-1);win.fire('keyup',{code:'ArrowLeft'});assert.equal(c.steer,0);win.fire('keydown',{code:'KeyD'});assert.equal(c.steer,1);win.fire('keyup',{code:'KeyD'});assert.equal(c.steer,0);});
t('GAS/BRAKE/REVERSE hold controls remain wired',()=>{holds[0].fire('pointerdown',{pointerId:1});assert.equal(c.throttle,1);holds[0].fire('pointerup',{pointerId:1});assert.equal(c.throttle,0);holds[1].fire('pointerdown',{pointerId:2});assert.equal(c.brake,1);holds[1].fire('pointerup',{pointerId:2});holds[2].fire('pointerdown',{pointerId:3});assert.equal(c.reverse,1);holds[2].fire('pointerup',{pointerId:3});assert.equal(c.reverse,0);});
t('keyboard jump and pause shortcuts still work',()=>{let pauses=0;c.onPause=()=>pauses++;win.fire('keydown',{code:'Space',repeat:false});assert.equal(c.jump,true);c.consumeJump();win.fire('keydown',{code:'KeyP',repeat:false});assert.equal(pauses,1);});
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8'),css=fs.readFileSync(new URL('../css/style.css',import.meta.url),'utf8');
t('touch markup: drag zone, GAS/BRAKE/REVERSE and JUMP; wheel and lane buttons removed',()=>{for(const x of ['id="steerZone"','data-jump','data-hold="gas"','data-hold="brake"','data-hold="reverse"'])assert(html.includes(x),x);assert(!html.includes('steeringWheel'));assert(!html.includes('data-lane'));assert(!css.includes('steering-wheel'));});
t('leaderboard period filters are inside a closed panel until requested',()=>{assert(html.includes('id="leaderboardBtn"'));assert(html.includes('id="leaderboardPanel" class="overlay hidden modal-overlay"'));for(const x of ['data-period="today"','data-period="week"','data-period="month"'])assert(html.includes(x));});
t('jump model and local coin sound remain included',()=>{const vehicle=fs.readFileSync(new URL('../src/vehicle.js',import.meta.url),'utf8'),audio=fs.readFileSync(new URL('../src/audio.js',import.meta.url),'utf8');assert(vehicle.includes('jumpHeight'));assert(audio.includes('coin-pickup.wav'));assert(fs.existsSync(new URL('../assets/coin-pickup.wav',import.meta.url)));});
console.log('Chapter 1 tests passed:',n);
