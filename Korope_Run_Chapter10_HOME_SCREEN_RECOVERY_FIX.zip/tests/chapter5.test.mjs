// Chapter 5 tests: purple magnet power-up (activation, attraction of coins AND cash only, smoothness, expiry, refresh, pause/crash/restart, HUD, glow, sound, cleanup).
import assert from 'node:assert';
import fs from 'node:fs';

// ---- minimal DOM / storage / Web Audio mocks (same style as the earlier chapters)
const made = [];
const mk = () => { const e = { style: {}, className: '', textContent: '', classes: new Set(), classList: { add(...c) { c.forEach((x) => e.classes.add(x)); }, remove(...c) { c.forEach((x) => e.classes.delete(x)); }, toggle(c, on) { on ? e.classes.add(c) : e.classes.delete(c); }, contains: (c) => e.classes.has(c) }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {} }) }; e.parentElement = { classList: e.classList }; made.push(e); return e; };
const byId = {};
globalThis.document = { createElement: mk, body: { appendChild() {} }, getElementById: (id) => (byId[id] ||= mk()) };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
const store = {}; globalThis.localStorage = { getItem: (k) => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); } };
let started = 0, created = 0;
class Param { constructor() { this.value = 0; } setValueAtTime() {} exponentialRampToValueAtTime() {} }
const node = () => ({ connect() {}, disconnect() {}, gain: new Param(), frequency: new Param(), type: '', start() { started++; }, stop() {}, onended: null });
globalThis.window = globalThis;
globalThis.AudioContext = class { constructor() { created++; this.state = 'suspended'; this.currentTime = 0; this.sampleRate = 8000; this.destination = {}; }
  resume() { this.state = 'running'; return Promise.resolve(); }
  createGain() { return node(); } createOscillator() { return node(); } createBiquadFilter() { return node(); } createBufferSource() { return node(); }
  createBuffer(c, l) { return { getChannelData: () => new Float32Array(l) }; } };

const THREE = await import('three');
const { MagnetBox, MAGNET, MAGNET_DURATION, attract } = await import('../src/magnet.js');
const { CASH, CASH_REWARD } = await import('../src/cash.js');
const { createWorld } = await import('../src/world.js');
const { Hud } = await import('../src/hud.js');
const { Effects } = await import('../src/effects.js');
const { Sound } = await import('../src/audio.js');

let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };
const seeded = (s) => () => (s = (s * 16807) % 2147483647) / 2147483647;
const read = (f) => fs.readFileSync(new URL(f, import.meta.url), 'utf8');
const DT = 1 / 60;
const newWorld = (opts = {}) => { const scene = new THREE.Scene(); const w = createWorld(scene, { random: seeded(7), magnetRandom: seeded(11), ...opts }); return { scene, w }; };
const coinsOf = (scene) => scene.children.filter((c) => c.isMesh && c.geometry.type === 'CylinderGeometry');
// Park every pickup far away so a test can place exactly what it needs.
const clearField = (w, scene) => { coinsOf(scene).forEach((c, i) => c.position.set(0, 1.1, -3000 - i * 9)); w.cash.items.forEach((b, i) => b.g.position.set(0, 1.25, -3500 - i * 150)); w.magnetBox.g.position.set(0, 1.25, -4000); };
const tick = (w, px, pz, secs, time0 = 0, collect = true) => { let tm = time0; for (let i = 0; i < Math.round(secs * 60); i++) { tm += DT; w.update(DT, px, pz, tm, collect); } return tm; };
const activate = (w, pz = -100) => { w.magnetBox.g.position.set(0, 1.25, pz); w.update(DT, 0, pz, 0, true); };

// ---------------- configuration and rarity
t('default duration is 8 s and is configurable (createWorld option, setMagnetDuration); bad values are ignored', () => {
  assert.strictEqual(MAGNET_DURATION, 8); assert.strictEqual(newWorld().w.magnetDuration, 8);
  assert.strictEqual(newWorld({ magnetDuration: 3 }).w.magnetDuration, 3);
  const { w } = newWorld(); assert.strictEqual(w.setMagnetDuration(12), 12);
  for (const bad of [0, -1, NaN, Infinity, 'x', null, undefined]) assert.strictEqual(w.setMagnetDuration(bad), 12, String(bad));
  for (const bad of [0, -2, NaN, 'x']) assert.strictEqual(newWorld({ magnetDuration: bad }).w.magnetDuration, 8, 'bad option falls back to the default');
});
t('rarity: spacing is longer than cash bundles and far longer than coins; only one box exists', () => {
  assert(MAGNET.GAP_MIN > CASH.GAP_MAX, 'rarer than cash'); assert(MAGNET.GAP_MIN >= 40 * 9, 'much rarer than coins (~9 m apart)');
  const { scene, w } = newWorld(); const boxes = scene.children.filter((c) => c === w.magnetBox.g); assert.strictEqual(boxes.length, 1);
  const f = new MagnetBox(new THREE.Scene(), { random: seeded(5) }); const gaps = [];
  for (let i = 0; i < 40; i++) { const z0 = -200 - i * 3000; f.g.position.set(0, 1.25, z0); f.update(DT, 0, z0, 0, true); gaps.push(z0 - f.g.position.z); }
  assert(gaps.every((g) => g >= MAGNET.GAP_MIN + 60 - 1e-6 && g <= MAGNET.GAP_MAX + 60 + 1e-6), 'next box is 460-760 m ahead');
  const first = new MagnetBox(new THREE.Scene(), { random: seeded(9) }); assert(first.g.position.z <= -MAGNET.FIRST_MIN && first.g.position.z >= -MAGNET.FIRST_MAX);
  assert(new Set(gaps.map((g) => Math.round(g))).size > 20, 'spacing is varied');
});
t('slots: every box is at a reachable x, never the same slot twice in a row', () => {
  const f = new MagnetBox(new THREE.Scene(), { random: seeded(21) }); let last = null;
  for (let i = 0; i < 60; i++) { f.g.position.set(f.g.position.x, 1.25, -100); f.update(DT, f.g.position.x, -100, 0, true); const x = f.g.position.x; assert(MAGNET.SLOTS.includes(x)); assert(Math.abs(x) <= 4.75); assert(x !== last); last = x; }
});
t('visual: purple 3D box (4 printed sides + a real horseshoe magnet on top), shared geometry, textures built once', () => {
  const { w } = newWorld(); const g = w.magnetBox.g; const meshes = []; g.traverse((o) => o.isMesh && meshes.push(o));
  assert(meshes.length >= 6, 'box + bend + 2 legs + 2 tips'); const box = meshes.find((m) => m.geometry.type === 'BoxGeometry' && Array.isArray(m.material));
  assert(box, 'box with per-face materials'); assert.strictEqual(box.material.length, 6);
  assert(meshes.some((m) => m.geometry.type === 'TorusGeometry'), 'horseshoe bend'); const col = w.magnetBox.mats[0].color; assert(col.b > col.g && col.r > col.g, 'purple body colour (blue+red over green)');
  assert(w.magnetBox.mats[1].map, 'magnet symbol texture on the faces');
});

// ---------------- activation
t('activation: driving into the box starts the magnet at the full duration; handler fires once; the box moves far ahead at once', () => {
  const { scene, w } = newWorld(); clearField(w, scene); let hits = 0, wasActive = null; w.setMagnetHandler((x, y, z, was) => { hits++; wasActive = was; });
  assert.strictEqual(w.magnetActive, false); assert.strictEqual(w.magnetLeft, 0);
  w.magnetBox.g.position.set(2, 1.25, -100); w.update(DT, 2, -100, 0, true);
  assert.strictEqual(w.magnetActive, true); assert.strictEqual(w.magnetLeft, 8); assert.strictEqual(hits, 1); assert.strictEqual(wasActive, false); assert.strictEqual(w.magnetBox.collected, 1);
  assert(w.magnetBox.g.position.z < -100 - MAGNET.GAP_MIN, 'relocated far ahead');
  for (let i = 0; i < 300; i++) w.update(DT, 2, -100, i * DT, true); assert.strictEqual(hits, 1, 'sitting on the spot never pays twice');
});
t('pickup box: inside collects, just outside does not; collect=false (menu / after a crash) never activates', () => {
  const { scene, w } = newWorld(); clearField(w, scene); const at = (px, pz, collect = true) => { w.resetMagnet(0); w.magnetBox.g.position.set(0, 1.25, -100); w.update(DT, px, pz, 0, collect); return w.magnetActive; };
  assert(at(MAGNET.RADIUS_X - 0.05, -100)); assert(!at(MAGNET.RADIUS_X + 0.05, -100)); assert(at(0, -100 + MAGNET.RADIUS_Z - 0.05)); assert(!at(0, -100 + MAGNET.RADIUS_Z + 0.05)); assert(!at(0, -100, false));
});
t('a missed box is recycled to the front (never left behind, never duplicated)', () => {
  const { scene, w } = newWorld(); clearField(w, scene); w.magnetBox.g.position.set(0, 1.25, -50); w.update(DT, 0, -50 - MAGNET.PASSED - 2, 0, true); // the korope drove past it (towards -z)
  assert(w.magnetBox.g.position.z < -50 - MAGNET.PASSED - 2 - 60 - MAGNET.GAP_MIN + 1e-6); assert.strictEqual(w.magnetActive, false); assert.strictEqual(scene.children.filter((c) => c === w.magnetBox.g).length, 1);
});

// ---------------- attraction
t('coins within range are pulled smoothly (never faster than the per-frame cap, never overshooting) and are collected exactly once', () => {
  const { scene, w } = newWorld(); clearField(w, scene); activate(w); const [coin] = coinsOf(scene); let pops = 0; w.setCoinHandler(() => pops++);
  coin.position.set(4, 1.1, -112); // 12 m ahead and 4 m to the side: outside the normal pickup box, inside the magnet range
  let prev = null, collected = 0, d0 = Math.hypot(4, 12), maxStep = 0, tm = 0;
  for (let i = 0; i < 400; i++) {
    tm += DT; const bx = 0, bz = -100, before = { x: coin.position.x, z: coin.position.z };
    const got = w.update(DT, bx, bz, tm, true); collected += got;
    if (got) break;
    const step = Math.hypot(coin.position.x - before.x, coin.position.z - before.z); maxStep = Math.max(maxStep, step);
    const d = Math.hypot(coin.position.x - bx, coin.position.z - bz); if (prev !== null) assert(d <= prev + 1e-9, 'distance never grows'); prev = d;
  }
  assert.strictEqual(collected, 1); assert.strictEqual(pops, 1); assert(maxStep <= MAGNET.PULL_MAX_STEP + 1e-9, 'max step ' + maxStep); assert(maxStep > 0.05, 'it really moved'); assert(d0 > MAGNET.RADIUS_X);
  assert(coin.position.z < -100 - 100, 'collected coin was sent far ahead at once');
});
t('without the magnet the same coin is NOT collected (the pull is what collects it)', () => {
  const { scene, w } = newWorld(); clearField(w, scene); const [coin] = coinsOf(scene); coin.position.set(4, 1.1, -112); let got = 0;
  for (let i = 0; i < 60; i++) got += w.update(DT, 0, -100, i * DT, true); assert.strictEqual(got, 0); assert.strictEqual(coin.position.x, 4); assert.strictEqual(coin.position.z, -112);
});
t('cash bundles within range are pulled in and pay exactly one reward each', () => {
  const { scene, w } = newWorld(); clearField(w, scene); activate(w); let hits = 0, naira = 0; w.setCashHandler((x, y, z, a) => hits++);
  const b = w.cash.items[0].g; b.position.set(-4, 1.25, -110); let maxStep = 0;
  for (let i = 0; i < 400; i++) { const bx = b.position.x, bz = b.position.z; w.update(DT, 0, -100, 1 + i * DT, true); naira += w.cashGot; if (w.cashGot) break; maxStep = Math.max(maxStep, Math.hypot(b.position.x - bx, b.position.z - bz)); }
  assert.strictEqual(hits, 1); assert.strictEqual(naira, CASH_REWARD); assert(maxStep <= MAGNET.PULL_MAX_STEP + 1e-9); assert(b.position.z < -100 - CASH.GAP_MIN, 'bundle sent far ahead at once');
  for (let i = 0; i < 200; i++) w.update(DT, 0, -100, 5 + i * DT, true); assert.strictEqual(hits, 1, 'no duplicate collection');
});
t('items outside the range are left alone; the range is sensible (16 m)', () => {
  const { scene, w } = newWorld(); clearField(w, scene); activate(w); assert(MAGNET.RANGE >= 12 && MAGNET.RANGE <= 25);
  const [c1, c2] = coinsOf(scene); c1.position.set(0, 1.1, -100 - MAGNET.RANGE - 1); c2.position.set(MAGNET.RANGE + 1, 1.1, -100); const b = w.cash.items[0].g; b.position.set(0, 1.25, -100 - MAGNET.RANGE - 1);
  const snap = [c1.position.clone(), c2.position.clone()]; const bz = b.position.z;
  w.update(DT, 0, -100, 0, true); assert(c1.position.equals(snap[0])); assert(c2.position.equals(snap[1])); assert.strictEqual(b.position.z, bz);
});
t('ONLY coins and cash bundles move: traffic, passengers, signs, road and scenery are identical with the magnet on and off', () => {
  const run = (magnetOn) => {
    let seed = 4242; const realRandom = Math.random; Math.random = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    try {
      const { scene, w } = newWorld({ trafficRandom: () => 0.9 }); clearField(w, scene); w.resetTraffic(-100); w.setBoarded(3);
      const coins = new Set(coinsOf(scene)), cash = new Set(w.cash.items.map((b) => b.g));
      coins.forEach((c) => c.position.set(3, 1.1, -108)); w.cash.items[0].g.position.set(-3, 1.25, -108); // pickups sitting right where the pull works
      if (magnetOn) activate(w); else w.update(DT, 0, -100, 0, true);
      tickAll(w, scene, 3);
      const out = []; scene.traverse((o) => { if (o === scene || coins.has(o) || cash.has(o) || o === w.magnetBox.g || o.parent === w.magnetBox.g) return; for (let p = o.parent; p; p = p.parent) if (coins.has(p) || cash.has(p) || p === w.magnetBox.g) return; out.push(o.position.toArray().map((v) => Math.round(v * 1e4) / 1e4).join(',') + '|' + o.visible); });
      return out;
    } finally { Math.random = realRandom; }
  };
  function tickAll(w, scene, secs) { let tm = 0; for (let i = 0; i < secs * 60; i++) { tm += DT; w.update(DT, 0, -100, tm, true); } }
  const on = run(true), off = run(false); assert(on.length > 100, 'compared the whole scene'); assert.deepStrictEqual(on, off);
});
t('performance: pulling does not allocate (object / geometry / material counts are constant over a long magnet run) and is cheap', () => {
  const { scene, w } = newWorld(); const count = () => { let o = 0; scene.traverse(() => o++); return o; }; const before = count();
  const t0 = performance.now(); let tm = 0; for (let i = 0; i < 20000; i++) { tm += DT; if (i % 400 === 0) activate(w, -100 - i * 0.5); w.update(DT, (i % 9) - 4, -100 - i * 0.5, tm, true); }
  assert.strictEqual(count(), before, 'no objects created or leaked'); assert(performance.now() - t0 < 4000, 'a 5-minute run simulates well under a few seconds');
  const dt50 = 0.05; clearField(w, scene); activate(w); const [c] = coinsOf(scene); c.position.set(0, 1.1, -112); const z0 = c.position.z; w.update(dt50, 0, -100, 0, true); assert(Math.abs(c.position.z - z0) <= MAGNET.PULL_MAX_STEP + 1e-9, 'even a 50 ms frame cannot teleport a pickup');
});
t('attract(): range edge, zero distance and bad values never produce NaN or overshoot', () => {
  const p = { x: 0, z: -MAGNET.RANGE }; assert.strictEqual(attract(p, 0, 0, DT), false); assert.strictEqual(p.z, -MAGNET.RANGE);
  const q = { x: 0, z: 0 }; assert.strictEqual(attract(q, 0, 0, DT), false); assert.strictEqual(q.x, 0);
  const r = { x: 1, z: 1 }; for (let i = 0; i < 500; i++) attract(r, 0, 0, 1); assert(Number.isFinite(r.x) && Number.isFinite(r.z)); assert(Math.hypot(r.x, r.z) < 1e-6 || Math.hypot(r.x, r.z) >= 0, 'lands on the target at most');
  const s = { x: 0.5, z: 0 }; attract(s, 0, 0, 10); assert(s.x >= 0 && s.x < 0.5, 'a huge dt cannot jump past the target');
});

// ---------------- duration, expiry, cleanup
t('expiry: the magnet runs for 8 s (+/- one frame), then stops; the end handler fires once and attraction ceases', () => {
  const { scene, w } = newWorld(); clearField(w, scene); let ended = 0; w.setMagnetEndHandler(() => ended++); activate(w);
  let frames = 0; while (w.magnetActive && frames < 2000) { w.update(DT, 0, -100, frames * DT, true); frames++; } assert(Math.abs(frames * DT - 8) < 2 * DT + 1e-9, 'lasted ' + frames * DT + ' s'); assert.strictEqual(ended, 1);
  const [c] = coinsOf(scene); c.position.set(4, 1.1, -112); const b = w.cash.items[0].g; b.position.set(-4, 1.25, -110); const cs = c.position.clone(), bs = b.position.clone();
  for (let i = 0; i < 120; i++) w.update(DT, 0, -100, 20 + i * DT, true); assert(c.position.equals(cs), 'coin no longer pulled'); assert(Math.abs(b.position.x - bs.x) + Math.abs(b.position.z - bs.z) < 1e-9, 'cash no longer pulled'); assert.strictEqual(w.magnetLeft, 0); assert.strictEqual(ended, 1, 'ended only once');
});
t('a different duration is honoured (1 s and 20 s)', () => {
  for (const d of [1, 20]) { const { scene, w } = newWorld({ magnetDuration: d }); clearField(w, scene); activate(w); assert.strictEqual(w.magnetLeft, d); let f = 0; while (w.magnetActive) { w.update(DT, 0, -100, f * DT, true); f++; } assert(Math.abs(f * DT - d) < 2 * DT + 1e-9, 'd=' + d + ' lasted ' + f * DT); }
});
t('repeated collection: a second box while active refreshes to the full duration (no stacking), once more handler call (was active), ends once', () => {
  const { scene, w } = newWorld(); clearField(w, scene); let ended = 0, calls = []; w.setMagnetEndHandler(() => ended++); w.setMagnetHandler((x, y, z, was) => calls.push(was)); activate(w);
  let tm = tick(w, 0, -100, 5); assert(Math.abs(w.magnetLeft - 3) < 0.05); w.magnetBox.g.position.set(0, 1.25, -100); tm += DT; w.update(DT, 0, -100, tm, true);
  assert(w.magnetLeft > 7.9 && w.magnetLeft <= 8, 'refreshed to 8, not 11: ' + w.magnetLeft); assert.deepStrictEqual(calls, [false, true]); assert.strictEqual(ended, 0, 'no end between the two pickups');
  tm = tick(w, 0, -100, 7.5, tm); assert(w.magnetActive); tm = tick(w, 0, -100, 1, tm); assert(!w.magnetActive); assert.strictEqual(ended, 1);
  w.magnetBox.g.position.set(0, 1.25, -100); w.update(DT, 0, -100, tm, true); assert(w.magnetActive, 'it can be collected again after it ended'); assert.strictEqual(calls.length, 3); assert.strictEqual(calls[2], false);
});
t('a refresh in the very frame the old timer would have ended does not end it', () => {
  const { scene, w } = newWorld(); clearField(w, scene); let ended = 0; w.setMagnetEndHandler(() => ended++); activate(w); w.update(7.99, 0, -100, 1, true); assert(w.magnetActive);
  w.magnetBox.g.position.set(0, 1.25, -100); w.update(0.02, 0, -100, 2, true); assert(w.magnetLeft > 7.9); assert.strictEqual(ended, 0);
});

// ---------------- pause / crash / restart
t('pause: the world is not updated while paused, so the timer, pull and glow freeze and resume where they were (main.js loop)', () => {
  const main = read('../src/main.js'); assert(/if \(state === 'playing'\) \{\s*\n\s*bus\.update/.test(main), 'vehicle/world simulation only advances during active gameplay'); assert(/const got = world\.update\(dt, bus\.x, bus\.z, t, state === 'playing'\)/.test(main), 'pickup/timer updates stay inside the active driving branch');
  const { scene, w } = newWorld(); clearField(w, scene); activate(w); const tm = tick(w, 0, -100, 3); const left = w.magnetLeft; /* paused: no update calls */ assert.strictEqual(w.magnetLeft, left); tick(w, 0, -100, 1, tm); assert(Math.abs(w.magnetLeft - (left - 1)) < 0.02, 'resumes from the same value');
  assert(main.includes("document.hidden && state === 'playing'") , 'tab switch pauses');
  assert(!/setPaused[^\n]*clearMagnet|setPaused[^\n]*resetMagnet/.test(main), 'pausing never cancels the magnet');
});
t('collect=false (menu, game over): the timer does not run and nothing is pulled', () => {
  const { scene, w } = newWorld(); clearField(w, scene); activate(w); const [c] = coinsOf(scene); c.position.set(4, 1.1, -112); const cs = c.position.clone(); const left = w.magnetLeft;
  tick(w, 0, -100, 2, 0, false); assert.strictEqual(w.magnetLeft, left); assert(c.position.equals(cs));
});
t('crash: clearMagnet() stops it at once (end handler once, double call safe); restart/PLAY: resetMagnet() = off + fresh box ahead, no leftover pull', () => {
  const { scene, w } = newWorld(); clearField(w, scene); let ended = 0; w.setMagnetEndHandler(() => ended++); activate(w); w.clearMagnet(); assert.strictEqual(w.magnetActive, false); assert.strictEqual(w.magnetLeft, 0); assert.strictEqual(ended, 1); w.clearMagnet(); assert.strictEqual(ended, 1);
  const [c] = coinsOf(scene); c.position.set(4, 1.1, -112); const cs = c.position.clone(); tick(w, 0, -100, 1); assert(c.position.equals(cs), 'no pull after the crash');
  activate(w); w.resetMagnet(-500); assert.strictEqual(w.magnetLeft, 0); assert.strictEqual(ended, 1, 'restart is silent: HUD/glow are cleared by startTrip()'); assert(w.magnetBox.g.position.z <= -500 - MAGNET.FIRST_MIN && w.magnetBox.g.position.z >= -500 - MAGNET.FIRST_MAX); assert.strictEqual(w.magnetBox.collected, 0);
  const main = read('../src/main.js'); assert(/state = 'over'; world\.clearMagnet\(\)/.test(main), 'fatal crash ends the magnet'); assert(/function startTrip\(\)[^}]*world\.resetMagnet\(bus\.z\)[^}]*hud\.updateMagnet\(0\)[^}]*fx\.magnetAura\(0/.test(main), 'PLAY and RESTART (both call startTrip) reset it');
});

// ---------------- HUD, glow, sound
t('HUD: purple "MAGNET 8s" countdown, whole seconds, hidden when off, DOM touched only when the number changes', () => {
  const hud = new Hud(); const box = byId.magnetStat, txt = byId.magnetText; assert(box && txt, 'Hud looks up #magnetStat and #magnetText');
  hud.updateMagnet(0); assert(box.classes.has('hidden') || !box.classes.has('x'));
  hud.updateMagnet(8); assert.strictEqual(txt.textContent, 'MAGNET 8s'); assert(!box.classes.has('hidden'));
  hud.updateMagnet(7.99); assert.strictEqual(txt.textContent, 'MAGNET 8s'); hud.updateMagnet(7); assert.strictEqual(txt.textContent, 'MAGNET 7s'); hud.updateMagnet(0.2); assert.strictEqual(txt.textContent, 'MAGNET 1s'); assert(box.classes.has('low'));
  let writes = 0, v = txt.textContent; Object.defineProperty(txt, 'textContent', { get: () => v, set: (x) => { v = x; writes++; }, configurable: true });
  for (let i = 0; i < 100; i++) hud.updateMagnet(0.2); assert.strictEqual(writes, 0); hud.updateMagnet(0); assert(box.classes.has('hidden')); assert(!box.classes.has('low')); hud.updateMagnet(0); hud.updateMagnet(-3); assert(box.classes.has('hidden'));
  hud.updateMagnet(3); assert(!box.classes.has('low')); assert(!box.classes.has('hidden'), 'reappears for a new run');
});
t('HUD: the magnet tile is separate from coins, cash, score, speed, distance and fares', () => {
  const hud = new Hud(); hud.update(20, 1234, 7, 999, false); hud.updateCash(1500); hud.updateTrip('Lamenco', 9, 9, 1800); hud.updateMagnet(5);
  assert.strictEqual(byId.coins.textContent, 7); assert.strictEqual(byId.score.textContent, 999); assert.strictEqual(byId.cash.textContent, '₦1,500'); assert.strictEqual(byId.fare.textContent, '1,800'); assert.strictEqual(byId.magnetText.textContent, 'MAGNET 5s');
});
t('glow: subtle purple aura only while active; off = fully hidden; restart clears; no objects created per frame', () => {
  const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(); const fx = new Effects(scene, cam); const count = () => { let o = 0; scene.traverse(() => o++); return o; }; const c0 = count();
  assert(!fx.aura.visible && !fx.pulse.visible); fx.magnetAura(0, 0, 0, 0); assert(!fx.aura.visible);
  for (let i = 0; i < 600; i++) { fx.magnetAura(8 - i / 75, 1.5, -40, i * DT); assert(fx.aura.visible && fx.pulse.visible); assert(fx.auraMat.opacity >= 0 && fx.auraMat.opacity <= 0.35, 'subtle'); assert(fx.ringMat.opacity >= 0 && fx.ringMat.opacity <= 0.5); assert.strictEqual(fx.aura.position.x, 1.5); assert.strictEqual(fx.aura.position.z, -40); assert(fx.auraMat.depthWrite === false && fx.auraMat.transparent); }
  assert.strictEqual(count(), c0, 'nothing allocated while it runs'); fx.magnetAura(0, 0, 0, 1); assert(!fx.aura.visible && !fx.pulse.visible); fx.magnetAura(5, 0, 0, 1); fx.reset(); assert(!fx.aura.visible && !fx.pulse.visible);
  assert(fx.auraMat.color.b > fx.auraMat.color.g && fx.auraMat.color.r > fx.auraMat.color.g, 'purple');
});
t('notification: "MAGNET 8s" floater from its own element + purple sparks; coin/cash notices are untouched', () => {
  const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(); cam.position.set(0, 4, 10); cam.lookAt(0, 1, -9); cam.updateMatrixWorld(); const fx = new Effects(scene, cam); const vis = () => fx.parts.filter((p) => p.m.visible).length;
  fx.magnet(0, 1, 0, 'MAGNET 8s'); assert.strictEqual(fx.magnetFloater.textContent, 'MAGNET 8s'); assert(fx.magnetFloater.classes.has('go')); assert.strictEqual(vis(), 12);
  for (let i = 0; i < 30; i++) { fx.coin(0, 1, 0, '+1 coin'); fx.cash(0, 1, 0, 'cash'); } assert.strictEqual(fx.magnetFloater.textContent, 'MAGNET 8s'); assert(vis() <= 48);
  fx.magnet(0, 1, 40, 'behind'); assert(parseFloat(fx.magnetFloater.style.left) >= 0); fx.reset(); assert(!fx.magnetFloater.classes.has('go'));
});
t('sound: magnet cue via the existing Sound class; silent before unlock, throttled, cut by silence(), respects mute; other sounds unchanged', () => {
  const pre = new Sound(); started = 0; pre.magnet(); assert.strictEqual(started, 0);
  const s = new Sound(); s.unlock(); started = 0; s.magnet(); assert(started >= 1 && started <= 3, 'short cue'); const k = started; s.magnet(); assert.strictEqual(started, k, 'double trigger throttled'); s.silence(); assert.strictEqual(s.live.size, 0);
  s.setOn(false); started = 0; s.magnet(); assert.strictEqual(started, 0, 'muted = silent'); s.setOn(true); s.lastMagnet = -1e9; started = 0; s.magnet(); assert(started >= 1);
  const c = new Sound(); c.on = true; c.unlock(); started = 0; c.coin(); assert.strictEqual(started, 3); c.lastCash = -1e9; started = 0; c.cash(); assert.strictEqual(started, 3);
  globalThis.AudioContext = class { constructor() { throw new Error('no audio'); } }; const bad = new Sound(); bad.unlock(); bad.magnet();
});

// ---------------- resources and wiring
t('dispose: removes the box from the scene and frees geometry/materials/textures; double dispose is safe', () => {
  const scene = new THREE.Scene(); const f = new MagnetBox(scene, { random: seeded(3) }); assert(scene.children.includes(f.g)); let freed = 0; f.geos.forEach((g) => g.addEventListener('dispose', () => freed++)); f.mats.forEach((m) => m.addEventListener('dispose', () => freed++));
  f.dispose(); assert(!scene.children.includes(f.g)); assert.strictEqual(freed, f.geos.length + f.mats.length); f.dispose(); assert.strictEqual(freed, f.geos.length + f.mats.length);
});
t('index.html and CSS: purple magnet tile exists, sits outside the HUD row, ignores touches; controls markup untouched', () => {
  const html = read('../index.html'); for (const id of ['magnetStat', 'magnetText', 'cash', 'coins', 'score', 'soundBtn', 'pauseBtn', 'leaderboardBtn', 'minimap', 'mapToggle']) assert(new RegExp(`id="${id}"`).test(html), 'missing #' + id);
  assert(html.indexOf('id="magnetStat"') > html.indexOf('id="pauseBtn"') && html.indexOf('id="magnetStat"') < html.indexOf('id="trip"'), 'placed after the HUD row, before the trip panel');
  const css = read('../css/style.css'); assert(/#magnetStat\{[^}]*position:fixed[^}]*pointer-events:none/.test(css), 'fixed, ignores touches'); assert(/#magnetStat\{[^}]*#a45cff/i.test(css), 'purple'); assert(/#hud\{[^}]*pointer-events:none/.test(css));
});
t('main.js wiring: handler, per-frame HUD + glow, crash and restart hooks; score formula, coin reward, cash and fares untouched', () => {
  const main = read('../src/main.js');
  for (const s of ['world.setMagnetHandler', 'sound.magnet()', 'hud.updateMagnet(world.magnetLeft)', 'fx.magnetAura(world.magnetLeft', 'magnetDuration: MAGNET_DURATION', "from './magnet.js'"]) assert(main.includes(s), s);
  for (const s of ['score = Math.floor(bus.distance / 10) + coins * COIN_POINTS', 'const COIN_POINTS = 25', 'coins += got; cash += world.cashGot', "journey.fare.toLocaleString('en-US')", 'world.collide(bus.x, bus.z)', 'controls.reset()', "sound.toggle()", "e.code === 'KeyM'", 'minimap.draw(d, bus.x, journey)']) assert(main.includes(s), s);
  const body = main.slice(main.indexOf("world.setMagnetHandler")); assert(!/coins\s*\+=\s*[^;]*magnet|score\s*\+=\s*[^;]*magnet|cash\s*\+=\s*[^;]*magnet/i.test(body), 'magnet never adds coins, cash or score');
  const mod = read('../src/magnet.js').replace(/\/\/.*$/gm, ''); assert(!/journey|COIN_POINTS|bestScore|score|fare/i.test(mod), 'magnet module knows nothing about score or fares');
  assert(!/magnet/i.test(read('../src/route.js').replace(/\/\/.*$/gm, '')), 'route.js untouched'); assert(!/magnet/i.test(read('../src/minimap.js')) && !/magnet/i.test(read('../src/controls.js')) && !/magnet/i.test(read('../src/vehicle.js')), 'minimap, controls and vehicle untouched');
});
t('the pull never changes what a pickup is worth: coin = +1, bundle = reward, a magnet box = nothing', () => {
  const { scene, w } = newWorld(); clearField(w, scene); activate(w); let coinsGot = 0, cashGot = 0; const [c1, c2] = coinsOf(scene); c1.position.set(2, 1.1, -108); c2.position.set(-2, 1.1, -106); w.cash.items[0].g.position.set(0, 1.25, -109); w.cash.items[1].g.position.set(4, 1.25, -107);
  let tm = 0; for (let i = 0; i < 200; i++) { tm += DT; coinsGot += w.update(DT, 0, -100, tm, true); cashGot += w.cashGot; } assert.strictEqual(coinsGot, 2); assert.strictEqual(cashGot, 2 * CASH_REWARD);
});

console.log('Chapter 5 tests passed: ' + n);
