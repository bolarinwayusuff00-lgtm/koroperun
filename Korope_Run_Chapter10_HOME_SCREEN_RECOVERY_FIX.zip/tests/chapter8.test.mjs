// Chapter 8 regression/quality checks: shared scene resources, stable traffic updates,
// gameplay-state freeze, adaptive mobile rendering, and accessible responsive styling.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';
import { createWorld, ROAD } from '../src/world.js';

const read = (path) => fs.readFileSync(new URL(path, import.meta.url), 'utf8');
const ctx = new Proxy({}, { get: (o, key) => key in o ? o[key] : (() => {}), set: (o, key, value) => (o[key] = value, true) });
globalThis.document = {
  createElement: () => ({ width: 0, height: 0, style: {}, className: '', classList: { add() {}, remove() {}, toggle() {} }, setAttribute() {}, getContext: () => ctx }),
  body: { appendChild() {}, removeChild() {} },
  getElementById: () => ({ style: {}, classList: { add() {}, remove() {}, toggle() {} }, setAttribute() {}, textContent: '' }),
};
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
const tests = [];
const test = (name, fn) => { fn(); tests.push(name); console.log('  ok -', name); };

const makeWorld = () => { const scene = new THREE.Scene(); const world = createWorld(scene, { trafficRandom: () => 0.9, random: (() => { let n = 17; return () => (n = n * 16807 % 2147483647) / 2147483647; })() }); return { scene, world }; };

 test('repeated road props reuse shared BoxGeometry and material resources', () => {
  const { scene } = makeWorld();
  const all = [];
  scene.traverse((o) => { if (o.isMesh) all.push(o); });
  const asphalt = all.filter((o) => o.geometry?.type === 'BoxGeometry' && o.geometry.parameters?.width === ROAD.width && o.geometry.parameters?.height === 0.1 && o.geometry.parameters?.depth === 60);
  assert(asphalt.length >= 7, 'each recycled road chunk has asphalt');
  assert.equal(new Set(asphalt.map((o) => o.geometry)).size, 1, 'identical road sections share one geometry');
  assert.equal(new Set(asphalt.map((o) => o.material)).size, 1, 'identical road sections share one material');
  assert(all.length > new Set(all.map((o) => o.geometry)).size, 'geometry cache reduces unique shapes versus rendered meshes');
});

test('traffic following decisions do not depend on the traffic array iteration order', () => {
  const a = makeWorld().world, b = makeWorld().world;
  for (const w of [a, b]) {
    for (const lane of ROAD.lanes) {
      const row = w.traffic.filter((v) => v.lane === lane).sort((x, y) => x.slot - y.slot);
      row[0].z = -220; row[0].cruiseSpeed = 4; row[0].speed = 4; row[0].hl = 1;
      row[1].z = -205; row[1].cruiseSpeed = 16; row[1].speed = 16; row[1].hl = 1;
    }
  }
  b.traffic.reverse();
  a.update(0.05, 1000, 0, 1, false); b.update(0.05, 1000, 0, 1, false);
  const as = a.traffic.slice().sort((x, y) => x.slot - y.slot), bs = b.traffic.slice().sort((x, y) => x.slot - y.slot);
  for (let i = 0; i < as.length; i++) {
    assert.equal(as[i].z, bs[i].z, `slot ${i} z should be order-independent`);
    assert.equal(as[i].speed, bs[i].speed, `slot ${i} speed should be order-independent`);
  }
});

test('mixed traffic remains in its lane and avoids physical overlap during a long simulated drive', () => {
  const { world } = makeWorld();
  let pz = 0;
  for (let frame = 0; frame < 1800; frame++) {
    pz -= 0.5;
    world.update(1 / 60, 1000, pz, frame / 60, false);
    for (const lane of ROAD.lanes) {
      const row = world.traffic.filter((v) => v.lane === lane).sort((a, b) => a.z - b.z);
      for (const v of row) assert.equal(v.x, lane, 'traffic remains centred in its assigned lane');
      for (let i = 1; i < row.length; i++) {
        const gap = row[i].z - row[i - 1].z;
        assert(gap >= row[i - 1].hl + row[i].hl - 0.25, `same-lane traffic bodies do not overlap (gap ${gap})`);
      }
    }
  }
});

test('world simulation is gated to active play; paused/menu/game-over frames do not advance traffic', () => {
  const main = read('../src/main.js');
  assert(/if \(state === 'playing'\) \{\s*\n\s*bus\.update/.test(main));
  assert(/const got = world\.update\(dt, bus\.x, bus\.z, t, state === 'playing'\)/.test(main));
  assert(main.includes("if (state === 'over') fx.update(dt);"));
  assert(main.includes("if (state !== 'playing') terminalArrow.reset();"));
});

test('renderer caps mobile pixel ratio while keeping desktop sharper and resize-aware', () => {
  const main = read('../src/main.js');
  assert(main.includes("powerPreference: 'high-performance'"));
  assert(main.includes("window.matchMedia?.('(pointer: coarse)').matches"));
  assert(main.includes('coarse ? 1.5 : 2'));
  assert(main.includes('if (ratio !== appliedPixelRatio)'));
  assert(main.includes('renderer.outputColorSpace = THREE.SRGBColorSpace'));
});

test('visual polish preserves touch UI while adding focus, landscape and reduced-motion fallbacks', () => {
  const css = read('../css/style.css');
  assert(css.includes('button:focus-visible,input:focus-visible'));
  assert(css.includes('@media (orientation:landscape) and (max-height:480px)'));
  assert(css.includes('@media (prefers-reduced-motion:reduce)'));
  assert(css.includes('#touch .steer-zone') && css.includes('#touch .big-row .gas') && css.includes('#touch .big-row .brk'));
});

test('original route, transparent steering, separate wallets, and core audio features remain in the project', () => {
  const html = read('../index.html'), main = read('../src/main.js'), controls = read('../src/controls.js');
  assert(html.includes('id="steerZone"') && html.includes('data-hold="gas"') && html.includes('data-hold="brake"'));
  assert(controls.includes('dragTarget') && controls.includes('pointerdown'));
  assert(main.includes('Lamenco') && main.includes('Agunbelewo') && main.includes('coins += got; cash += world.cashGot;'));
  assert(main.includes('sound.coin()') && main.includes('sound.cash()') && main.includes('sound.pauseAudio()'));
});

console.log('Chapter 8 tests passed:', tests.length);
