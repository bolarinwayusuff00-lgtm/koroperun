// Lets the tests `import 'three'` from the bundled vendor copy (no npm install needed).
import { register } from 'node:module';
const target = new URL('../vendor/three.module.js', import.meta.url).href;
register('data:text/javascript,' + encodeURIComponent(`export async function resolve(s, c, n) { return s === 'three' ? { url: ${JSON.stringify(target)}, shortCircuit: true } : n(s, c); }`));
