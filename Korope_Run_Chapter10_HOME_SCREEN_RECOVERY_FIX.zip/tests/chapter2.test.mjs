// Chapter 2 tests: GAS / BRAKE / REVERSE physics, reverse safety, button release safety, layout wiring.
import assert from 'node:assert';
import fs from 'node:fs';
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };

// ---- Fake DOM (no browser needed) ----
const mkTarget = () => ({ on: {}, addEventListener(type, fn) { (this.on[type] ||= []).push(fn); }, fire(type, ev = {}) { (this.on[type] || []).forEach((f) => f({ preventDefault() { ev.prevented = true; }, ...ev })); return ev; } });
const win = mkTarget(); globalThis.addEventListener = (ty, f) => win.addEventListener(ty, f);
const mkClasses = () => { const set = new Set(); return { set, add: (c) => set.add(c), remove: (c) => set.delete(c), toggle: (c, on) => (on ? set.add(c) : set.delete(c)) }; };
const button = (name, opts = {}) => Object.assign(mkTarget(), { dataset: { hold: name }, classList: mkClasses(), setPointerCapture() { if (opts.captureThrows) throw new Error('nope'); } });
const buttons = { gas: button('gas'), brake: button('brake'), reverse: button('reverse') };
const zone = Object.assign(mkTarget(), { style: { setProperty() {} }, classList: mkClasses(), setPointerCapture() {} });
globalThis.document = {
  getElementById: (id) => (id === 'steerZone' ? zone : null), querySelectorAll: (sel) => (sel === '[data-hold]' ? Object.values(buttons) : []),
  createElement: () => ({ style: {}, classList: { add() {}, remove() {} }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {} }) }), body: { appendChild() {} },
};
globalThis.innerWidth = 800; globalThis.innerHeight = 600;

const { Korope, REV_MAX, SHIFT_SPEED, REVERSE_LIMIT } = await import('../src/vehicle.js');
const { Controls } = await import('../src/controls.js');

// ---- Physics helpers: an input object like Controls (throttle, brake, reverse, steer) ----
const DT = 1 / 60;
const inp = (o = {}) => ({ throttle: 0, brake: 0, reverse: 0, steer: 0, ...o });
const run = (bus, input, secs, cb) => { for (let i = 0; i < Math.round(secs * 60); i++) { bus.update(DT, input, true); if (cb) cb(bus, i); } };
const cruise = (speed) => { const b = new Korope(); b.speed = speed; return b; };

// ---- Forward driving ----
t('GAS accelerates smoothly (no jumps) and speeds up', () => {
  const b = new Korope(); let prev = 0, maxStep = 0;
  run(b, inp({ throttle: 1 }), 3, (bus) => { maxStep = Math.max(maxStep, bus.speed - prev); assert(bus.speed >= prev - 1e-9, 'never slows while GAS is held'); prev = bus.speed; });
  assert(b.speed > 15, 'reaches a decent speed'); assert(maxStep < 14 * DT + 1e-6, 'per-frame increase stays small'); assert.strictEqual(b.dir, 1);
});
t('forward driving physics is unchanged (matches the original formula frame by frame)', () => {
  const b = new Korope(); let ref = 0; const MAX = b.MAX;
  for (let i = 0; i < 600; i++) { // 5 s GAS then 5 s coast
    const gas = i < 300; if (gas) ref += 14 * (1 - ref / (MAX * 1.1)) * DT; ref -= (gas ? 1.0 : 4.5) * DT; ref = Math.min(MAX, Math.max(0, ref));
    b.update(DT, inp({ throttle: gas ? 1 : 0 }), true); assert(Math.abs(b.speed - ref) < 1e-9, 'frame ' + i);
  }
});
t('releasing GAS removes acceleration: the bus coasts down to a stop and never reverses', () => {
  const b = cruise(20); let prev = 20, z0 = b.z;
  run(b, inp(), 10, (bus) => { assert(bus.speed <= prev + 1e-9, 'never speeds up'); prev = bus.speed; assert(bus.z <= z0 + 1e-9, 'never moves backwards'); z0 = bus.z; });
  assert.strictEqual(b.speed, 0); assert.strictEqual(b.dir, 1);
});
t('top speed is still capped at MAX', () => { const b = new Korope(); run(b, inp({ throttle: 1 }), 40); assert(b.speed <= b.MAX && b.speed > b.MAX * 0.9); });

// ---- BRAKE ----
t('BRAKE slows the bus and can stop it', () => {
  const b = cruise(25); let prev = 25; run(b, inp({ brake: 1 }), 2, (bus) => { assert(bus.speed <= prev + 1e-9); prev = bus.speed; });
  assert.strictEqual(b.speed, 0);
});
t('holding BRAKE at a standstill never reverses the bus (z does not move, direction stays forward)', () => {
  const b = cruise(10); run(b, inp({ brake: 1 }), 1); const z = b.z; run(b, inp({ brake: 1 }), 5, (bus) => assert.strictEqual(bus.speed, 0)); assert.strictEqual(b.z, z); assert.strictEqual(b.dir, 1);
});
t('releasing BRAKE does not accelerate (standing still stays still; rolling only slows)', () => {
  const s = cruise(0); run(s, inp(), 5); assert.strictEqual(s.speed, 0); assert.strictEqual(s.z, 0);
  const m = cruise(12); let prev = 12; run(m, inp({ brake: 1 }), 0.1); prev = m.speed; run(m, inp(), 3, (bus) => { assert(bus.speed <= prev + 1e-9); prev = bus.speed; });
});

// ---- REVERSE ----
t('REVERSE from standstill moves the bus backwards, slowly, up to REV_MAX', () => {
  const b = new Korope(); run(b, inp({ reverse: 1 }), 0.5); assert.strictEqual(b.dir, -1); assert(b.z > 0, 'z grows = moving backwards');
  let peak = 0; run(b, inp({ reverse: 1 }), 10, (bus) => { peak = Math.max(peak, bus.speed); }); assert(peak <= REV_MAX + 1e-9 && peak > REV_MAX * 0.8, 'levels off near the cap (drag keeps it just under)');
});
t('releasing REVERSE coasts to a stop and never swings forward', () => {
  const b = new Korope(); run(b, inp({ reverse: 1 }), 3); let zPrev = b.z, prev = b.speed;
  run(b, inp(), 6, (bus) => { assert(bus.speed <= prev + 1e-9); assert(bus.z >= zPrev - 1e-9, 'never moves forward'); prev = bus.speed; zPrev = bus.z; });
  assert.strictEqual(b.speed, 0); assert.strictEqual(b.dir, -1);
});
t('REVERSE while driving forward does NOT flip direction: it brakes first, then reverses only when stopped', () => {
  const b = cruise(20); let flippedAt = null, zPrev = b.z, minSpeedBeforeFlip = Infinity;
  run(b, inp({ reverse: 1 }), 4, (bus) => {
    if (bus.dir === 1) { assert(bus.z <= zPrev + 1e-9, 'still moving forward (never jumps backwards)'); minSpeedBeforeFlip = Math.min(minSpeedBeforeFlip, bus.speed); }
    else if (flippedAt === null) flippedAt = bus.speed;
    zPrev = bus.z;
  });
  assert.strictEqual(b.dir, -1, 'eventually reverses because REVERSE is still held'); assert(flippedAt <= SHIFT_SPEED, 'flipped only when nearly stopped'); assert(minSpeedBeforeFlip <= SHIFT_SPEED);
});
t('no frame ever changes speed by more than brake+drag (no sudden direction change)', () => {
  const b = cruise(30); let prev = b.speed, dirPrev = b.dir;
  const seq = [[inp({ reverse: 1 }), 3], [inp({ throttle: 1 }), 3], [inp({ reverse: 1 }), 3], [inp(), 2], [inp({ throttle: 1 }), 2]];
  for (const [i, secs] of seq) run(b, i, secs, (bus) => { const flipped = bus.dir !== dirPrev; assert(Math.abs(bus.speed - prev) <= 34.5 * DT + (flipped ? SHIFT_SPEED : 0) + 1e-6, 'smooth: brake + drag at most, plus the tiny <=0.5 m/s settle when changing direction'); if (flipped) assert(bus.speed <= SHIFT_SPEED + 1e-9, 'direction only changes when stopped'); prev = bus.speed; dirPrev = bus.dir; });
});
t('releasing REVERSE before the bus has stopped keeps it going forward (coasts) and it never reverses', () => {
  const b = cruise(20); run(b, inp({ reverse: 1 }), 0.2); assert.strictEqual(b.dir, 1); run(b, inp(), 5); assert.strictEqual(b.dir, 1); assert.strictEqual(b.speed, 0);
});
t('GAS while reversing: slows to a stop first, then drives forward', () => {
  const b = new Korope(); run(b, inp({ reverse: 1 }), 3); assert.strictEqual(b.dir, -1); const zBefore = b.z;
  run(b, inp({ throttle: 1 }), 0.1); assert.strictEqual(b.dir, -1, 'not instantly'); run(b, inp({ throttle: 1 }), 3); assert.strictEqual(b.dir, 1); assert(b.z < zBefore + 5, 'now heading forward'); assert(b.speed > 3);
});
t('GAS and REVERSE together at a standstill: the bus stays put', () => { const b = new Korope(); run(b, inp({ throttle: 1, reverse: 1 }), 3); assert.strictEqual(b.speed, 0); assert.strictEqual(b.z, 0); });
t('BRAKE while reversing stops the reverse without going forward', () => {
  const b = new Korope(); run(b, inp({ reverse: 1 }), 3); run(b, inp({ brake: 1 }), 1); assert.strictEqual(b.speed, 0); assert.strictEqual(b.dir, -1); const z = b.z; run(b, inp({ brake: 1 }), 2); assert.strictEqual(b.z, z);
});
t('reverse zone ends REVERSE_LIMIT m behind the furthest point (world is only built ~60 m behind)', () => {
  const b = new Korope(); run(b, inp({ throttle: 1 }), 5); const zTop = b.z; run(b, inp(), 10); const zStop = b.z; run(b, inp({ reverse: 1 }), 60);
  assert(b.z - zStop <= REVERSE_LIMIT + 1, 'cannot reverse past the limit'); assert.strictEqual(b.speed, 0); assert(b.z - zStop > REVERSE_LIMIT - 3, 'but the full zone is usable'); assert(zStop <= zTop + 1e-6, "sanity: the bus coasted further forward before stopping");
});
t('REVERSE_LIMIT is inside the guaranteed world coverage (60 m)', () => assert(REVERSE_LIMIT <= 50));
t('reversing never adds distance/score and cannot be farmed by going back and forth', () => {
  const b = new Korope(); run(b, inp({ throttle: 1 }), 6); run(b, inp(), 8); const d0 = b.distance; assert(d0 > 20);
  run(b, inp({ reverse: 1 }), 3); assert.strictEqual(b.distance, d0, 'reversing adds nothing');
  run(b, inp({ throttle: 1 }), 0.6); assert(b.distance <= d0 + 1e-9 || b.net >= d0, 'driving back over old ground adds nothing'); assert(b.distance === Math.max(d0, b.net));
});
t('steering: right means right on screen, forwards and in reverse; and steering is ignored when stopped', () => {
  const f = cruise(15); run(f, inp({ steer: 1 }), 1); assert(f.x > 0.5, 'forward right');
  const r = new Korope(); run(r, inp({ reverse: 1, steer: 1 }), 2); assert(r.x > 0.1, 'reverse right'); const l = new Korope(); run(l, inp({ reverse: 1, steer: -1 }), 2); assert(l.x < -0.1, 'reverse left');
  const s = new Korope(); run(s, inp({ steer: 1 }), 2); assert.strictEqual(s.x, 0);
});
t('when not playing (pause screen, crash, game over) all pedals are ignored', () => {
  const b = new Korope(); for (let i = 0; i < 120; i++) b.update(DT, inp({ throttle: 1 }), false); assert.strictEqual(b.speed, 0);
  for (let i = 0; i < 120; i++) b.update(DT, inp({ reverse: 1 }), false); assert.strictEqual(b.speed, 0); assert.strictEqual(b.dir, 1);
});
t('restart() puts the bus back to forward, zero progress', () => { const b = new Korope(); run(b, inp({ reverse: 1 }), 2); b.restart(); assert.strictEqual(b.dir, 1); assert.strictEqual(b.net, 0); assert.strictEqual(b.distance, 0); assert.strictEqual(b.speed, 0); });

// ---- Controls: on-screen buttons ----
const c = new Controls();
const down = (name, id) => buttons[name].fire('pointerdown', { pointerId: id });
const fire = (name, type, id) => buttons[name].fire(type, { pointerId: id });
t('buttons set throttle / brake / reverse and are separate inputs', () => {
  down('gas', 1); assert.deepStrictEqual([c.throttle, c.brake, c.reverse], [1, 0, 0]); fire('gas', 'pointerup', 1);
  down('brake', 2); assert.deepStrictEqual([c.throttle, c.brake, c.reverse], [0, 1, 0]); fire('brake', 'pointerup', 2);
  down('reverse', 3); assert.deepStrictEqual([c.throttle, c.brake, c.reverse], [0, 0, 1]); fire('reverse', 'pointerup', 3);
  assert.deepStrictEqual([c.throttle, c.brake, c.reverse], [0, 0, 0]);
});
t('releasing BRAKE does not turn on GAS (or anything else)', () => { down('brake', 1); fire('brake', 'pointerup', 1); assert.deepStrictEqual([c.throttle, c.brake, c.reverse], [0, 0, 0]); });
for (const name of ['gas', 'brake', 'reverse']) for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  t(`${name}: ${type} releases it`, () => { down(name, 5); assert(buttons[name].classList.set.has('on')); fire(name, type, 5); assert.strictEqual(c.held[name], false); assert(!buttons[name].classList.set.has('on')); });
}
t('finger lifted outside the button (window pointerup / pointercancel) still releases', () => {
  for (const type of ['pointerup', 'pointercancel']) { down('gas', 6); down('reverse', 7); win.fire(type, { pointerId: 6 }); assert.strictEqual(c.held.gas, false); assert.strictEqual(c.held.reverse, true, 'other finger unaffected'); win.fire(type, { pointerId: 7 }); assert.strictEqual(c.held.reverse, false); }
});
t('window blur releases every held driving button; no drag steering state exists', () => {
  down('gas', 8); down('brake', 9); win.fire('blur'); assert.deepStrictEqual([c.throttle, c.brake, c.reverse, c.steer], [0, 0, 0, 0]); assert(!('drag' in c));
});
t('reset() (pause / crash / restart) releases everything, and the old fingers cannot un-press a new press', () => {
  down('gas', 11); down('reverse', 12); c.reset(); assert.deepStrictEqual([c.throttle, c.brake, c.reverse], [0, 0, 0]); assert(!buttons.gas.classList.set.has('on'));
  down('gas', 13); fire('gas', 'pointerup', 11); assert.strictEqual(c.held.gas, true, 'stale finger 11 is ignored'); fire('gas', 'pointerup', 13); assert.strictEqual(c.held.gas, false);
});
t('a second finger cannot take over or release a held button', () => { down('gas', 14); down('gas', 15); fire('gas', 'pointerup', 15); assert.strictEqual(c.held.gas, true); fire('gas', 'pointerup', 14); assert.strictEqual(c.held.gas, false); });
t('buttons prevent default on press and on touchstart/touchmove (no page scroll)', () => {
  assert(down('gas', 16).prevented); fire('gas', 'pointerup', 16); assert(buttons.gas.fire('touchstart').prevented); assert(buttons.gas.fire('touchmove').prevented);
});
t('if setPointerCapture throws, the press still works and still releases', () => {
  const odd = button('gas', { captureThrows: true }); buttons.gas = odd; const c2 = new Controls();
  odd.fire('pointerdown', { pointerId: 20 }); assert.strictEqual(c2.held.gas, true); win.fire('pointerup', { pointerId: 20 }); assert.strictEqual(c2.held.gas, false);
});
t('GAS works independently of the steering drag zone', () => {
  const c3 = new Controls(); buttons.gas.fire('pointerdown', { pointerId: 30 }); zone.fire('pointerdown', { pointerId: 31, clientX: 50 }); zone.fire('pointermove', { pointerId: 31, clientX: 100 });
  assert.strictEqual(c3.throttle, 1); assert.strictEqual(c3.steer, 0, 'keyboard steer unchanged'); assert(c3.dragging); buttons.gas.fire('pointerup', { pointerId: 30 }); zone.fire('pointerup', { pointerId: 31 }); assert(!c3.dragging);
});
t('keyboard unchanged: W/S/arrows/A/D work; R reverses; ArrowDown/S are BRAKE only', () => {
  const k = (type, code) => win.fire(type, { code, repeat: false });
  const c4 = new Controls();
  k('keydown', 'KeyW'); assert.strictEqual(c4.throttle, 1); k('keyup', 'KeyW'); k('keydown', 'ArrowDown'); assert.deepStrictEqual([c4.brake, c4.reverse], [1, 0]); k('keyup', 'ArrowDown');
  k('keydown', 'KeyS'); assert.deepStrictEqual([c4.brake, c4.reverse], [1, 0]); k('keyup', 'KeyS'); k('keydown', 'KeyR'); assert.strictEqual(c4.reverse, 1); assert(win.fire('keydown', { code: 'KeyR' }).prevented); k('keyup', 'KeyR'); assert.strictEqual(c4.reverse, 0);
  k('keydown', 'ArrowLeft'); assert.strictEqual(c4.steer, -1); k('keyup', 'ArrowLeft'); k('keydown', 'KeyD'); assert.strictEqual(c4.steer, 1); k('keyup', 'KeyD'); assert.strictEqual(c4.steer, 0);
});
t('end to end: Controls -> Korope. Hold REVERSE button while rolling: brakes, then reverses; release: stops', () => {
  const b = cruise(18), c5 = new Controls(); buttons.reverse.fire('pointerdown', { pointerId: 40 });
  for (let i = 0; i < 360; i++) b.update(DT, c5, true); assert.strictEqual(b.dir, -1); assert(b.speed > 3);
  buttons.reverse.fire('pointerup', { pointerId: 40 }); for (let i = 0; i < 600; i++) b.update(DT, c5, true); assert.strictEqual(b.speed, 0);
});

// ---- Markup / layout / wiring ----
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../css/style.css', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
t('GAS, BRAKE, REVERSE, JUMP buttons and the drag zone exist; wheel and lane buttons removed', () => {
  for (const [name, label] of [['gas', 'GAS'], ['brake', 'BRAKE'], ['reverse', 'REVERSE']]) assert(new RegExp(`data-hold="${name}"[^>]*>.*<b>${label}</b>`).test(html), name);
  assert(html.includes('id="steerZone"')); assert(html.includes('data-jump')); assert(!html.includes('data-lane')); assert(!html.includes('steeringWheel'));
});
t('buttons: touch-action none and thumb sized (GAS/BRAKE min 72px, up to 118px)', () => { const r = css.match(/#touch button\{[^}]*\}/)[0]; assert(/touch-action:none/.test(r)); assert(/--g:clamp\(76px,/.test(css.match(/#touch\{--g:[^}]*\}/)[0])); });
t('GAS/BRAKE sizing is responsive; the minimap is placed from the measured button row (see chapter3 tests)', () => {
  const [, minPx, vw, vh, maxPx] = css.match(/--g:clamp\((\d+)px,min\(([\d.]+)vw,(\d+)vh\),(\d+)px\)/).map(Number);
  assert(minPx >= 72 && maxPx >= 100 && vw > 0 && vh > 0); assert(!/#trip\{[^}]*translateY\(-50%\)/.test(css));
});
t('minimap, HUD stats and trip panel still ignore touches (pointer-events:none); pause and mute buttons still clickable', () => {
  assert(/#trip\{[^}]*pointer-events:none/.test(css)); assert(/#hud\{[^}]*pointer-events:none/.test(css)); assert(/#pauseBtn\{[^}]*pointer-events:auto/.test(css)); assert(/#soundBtn\{[^}]*pointer-events:auto/.test(css));
});
t('page cannot scroll or zoom during play (body touch-action none, overflow hidden, viewport locked)', () => { assert(/html,body\{[^}]*overflow:hidden[^}]*touch-action:none/.test(css)); assert(/user-scalable=no/.test(html)); });
t('main.js: controls reset on pause, crash and restart; reversing contact is a bump, forward crash rule unchanged', () => {
  assert((main.match(/controls\.reset\(\)/g) || []).length >= 3); assert(/bus\.dir > 0 \? bus\.speed - h\.v\.speed : 0/.test(main)); assert(/CRASH_CLOSING = 16/.test(main)); assert(/hud\.update\(bus\.speed, bus\.distance, coins, score, bus\.dir < 0\)/.test(main));
  assert(/score = Math\.floor\(bus\.distance \/ 10\) \+ coins \* COIN_POINTS/.test(main));
});

console.log(`Chapter 2 tests passed: ${n}`);
