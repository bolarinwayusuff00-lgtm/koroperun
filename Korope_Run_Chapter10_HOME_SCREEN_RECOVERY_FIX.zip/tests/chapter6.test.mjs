// Chapter 6: Terminal arrow timing, Osogbo route naming, and shared mixed-traffic architecture.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { TerminalArrow, TERMINAL_ARROW_START } from '../src/terminal-warning.js';
import { ROUTE, PICKUP, LAMENCO_D, AGUNBELEWO_D, Journey } from '../src/route.js';
import { createWorld, ROAD } from '../src/world.js';
import * as THREE from 'three';
const mockElement = () => ({ style: {}, classList: { add() {}, remove() {}, toggle() {} }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {}, beginPath() {}, arc() {}, fill() {}, stroke() {}, moveTo() {}, lineTo() {}, closePath() {} }) });
globalThis.document = { createElement: mockElement, body: { appendChild() {} } };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;

let count = 0;
const test = (name, fn) => { fn(); count++; console.log('  ok -', name); };

test('Oke-Fia, Lamenco, and Agunbelewo stay separate and ordered route locations', () => {
  assert.deepEqual(ROUTE.stops.map(s => s.name), ['Oke-Fia', 'Lamenco', 'Agunbelewo']);
  assert.equal(ROUTE.stops[0].d, 0); assert.equal(ROUTE.stops[1].d, LAMENCO_D); assert.equal(ROUTE.stops[2].d, AGUNBELEWO_D);
  assert(ROUTE.stops[0].d < ROUTE.stops[1].d && ROUTE.stops[1].d < ROUTE.stops[2].d);
});

test('Terminal approach arrow (replaces the old text alert): window starts before the bay and ends when the bay is reached', () => {
  const w = new TerminalArrow();
  assert.equal(TERMINAL_ARROW_START, PICKUP.start - 200);
  assert.equal(w.update(TERMINAL_ARROW_START - 1), null); assert.equal(w.visible, false);
  assert.equal(w.update(TERMINAL_ARROW_START), true); assert.equal(w.update(PICKUP.start - 1), null, 'no repeated show events'); assert.equal(w.visible, true);
  assert.equal(w.update(PICKUP.start), false, 'reaching the bay hides it'); assert.equal(w.visible, false);
  assert.equal(w.update(PICKUP.start + 10), null);
});

test('Terminal is a stop name only; Lamenco remains the junction/map location', () => {
  const worldSrc = fs.readFileSync(new URL('../src/world.js', import.meta.url), 'utf8');
  const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  const mapSrc = fs.readFileSync(new URL('../src/minimap.js', import.meta.url), 'utf8');
  assert(worldSrc.includes("gantry('LAMENCO JUNCTION'"));
  assert(worldSrc.includes("signMaterial('TERMINAL'"));
  assert(!worldSrc.includes("signMaterial('LAMENCO PICKUP'"));
  assert(html.includes('id="terminalArrow"')); assert(!html.includes('TERMINAL AHEAD') && !html.includes('terminalNotice'), 'old text notification removed');
  assert(mapSrc.includes("name: s.name") || mapSrc.includes('s.name'));
  assert.deepEqual(new Journey().passengers, 0, 'passenger trip starts unchanged');
});

const mkScene = () => new THREE.Scene();
test('cars remain the default majority; motorcycle and bicycle slots use same traffic lifecycle', () => {
  const s = mkScene(), w = createWorld(s, { trafficRandom: () => 0.9 });
  assert.equal(w.traffic.length, 6);
  assert.equal(w.traffic.filter(v => v.type === 'car').length, 6);
  assert.deepEqual(w.trafficProbabilities, { motorcycle: 0.14, bicycle: 0.08 });
  assert(w.traffic.every(v => v.models.car && v.models.motorcycle && v.models.bicycle));
});

test('bicycle and motorcycle variants spawn with riders and appropriate slower speeds', () => {
  const bicycleWorld = createWorld(mkScene(), { trafficRandom: () => 0.01 });
  assert(bicycleWorld.traffic.every(v => v.type === 'bicycle' && v.speed >= 3.2 && v.speed <= 5.7));
  const motorcycleWorld = createWorld(mkScene(), { trafficRandom: () => 0.15 });
  assert(motorcycleWorld.traffic.every(v => v.type === 'motorcycle' && v.speed >= 11 && v.speed <= 16));
  assert(bicycleWorld.traffic.every(v => v.models.bicycle.visible && !v.models.car.visible));
  assert(motorcycleWorld.traffic.every(v => v.models.motorcycle.visible && !v.models.car.visible));
});

test('mixed traffic stays in road lanes, starts with safe spacing, and collisions use each vehicle size', () => {
  const w = createWorld(mkScene(), { trafficRandom: () => 0.9 });
  for (const v of w.traffic) assert(ROAD.lanes.includes(v.lane) && Math.abs(v.x) + v.hw <= ROAD.width / 2);
  for (const lane of ROAD.lanes) {
    const row = w.traffic.filter(v => v.lane === lane).sort((a,b) => a.z - b.z);
    for (let i = 1; i < row.length; i++) assert(row[i].z - row[i-1].z > row[i].hl + row[i-1].hl + 10, 'traffic should have a safe starting gap');
  }
  const bikeWorld = createWorld(mkScene(), { trafficRandom: () => 0.01 });
  const bike = bikeWorld.traffic[0];
  assert(bike.hw < 1 && bike.hl < 2.1, 'bicycle collision box is smaller than a car');
  // Force a mixed-speed same-lane following scenario and ensure the fast rider yields instead of passing through the slower vehicle.
  const pair = w.traffic.filter(v => v.lane === -4).sort((a,b) => a.z - b.z);
  pair[0].z = -100; pair[1].z = -118; pair[0].cruiseSpeed = pair[0].speed = 16; pair[0].hl = 1.05;
  pair[1].cruiseSpeed = pair[1].speed = 4; pair[1].hl = 0.85;
  for (let i = 0; i < 240; i++) w.update(0.016, 0, 0, i * 0.016, false);
  assert(pair[0].z - pair[1].z >= pair[1].hl + pair[0].hl + 2, 'same-lane vehicles keep a physical gap');
});

console.log('Chapter 6 tests passed:', count);
