// Regression tests for Chapter 6 improvements: controls, bundled pickup sound, boarding animation, leaderboard modal.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';
import { createWorld } from '../src/world.js';
import { Sound } from '../src/audio.js';
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
const controls=fs.readFileSync(new URL('../src/controls.js',import.meta.url),'utf8');
const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const audio=fs.readFileSync(new URL('../src/audio.js',import.meta.url),'utf8');
const home=fs.readFileSync(new URL('../src/home.js',import.meta.url),'utf8');
let n=0;const t=(name,fn)=>{fn();n++;console.log('  ok -',name);};
const element=()=>({width:0,height:0,style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},getContext(){return {clearRect(){},fillRect(){},fillText(){},beginPath(){},arc(){},fill(){},stroke(){},moveTo(){},lineTo(){},closePath(){}}}});
globalThis.document={createElement:element,body:{appendChild(){}},querySelectorAll(){return []}};globalThis.innerWidth=800;globalThis.innerHeight=600;
t('large drag-steer zone replaces the wheel and lane buttons',()=>{for(const x of ['id="steerZone"','data-jump'])assert(html.includes(x));assert(!html.includes('steeringWheel'));assert(!html.includes('data-lane'));const code=controls.replace(/\/\/.*$/gm,'');assert(code.includes('dragTarget'));assert(!/wheel/i.test(code));assert(main.includes('controls.update(dt, bus.x)'));assert(main.includes('bus.jumpHeight > 0.72 ? null : world.collide'));});
t('keyboard jump mechanic remains available and resets on restart',()=>{const vehicle=fs.readFileSync(new URL('../src/vehicle.js',import.meta.url),'utf8');assert(controls.includes("jump: ['Space']"));assert(vehicle.includes('this.jumpTime = 0.82'));assert(vehicle.includes('Math.sin((1 - this.jumpTime / 0.82) * Math.PI) * 1.35'));assert(vehicle.includes('this.jumpTime = 0; this.jumpHeight = 0;'));});
t('original pickup sound is bundled locally and reused for coins/cash with mute handling',()=>{const wav=new URL('../assets/coin-pickup.wav',import.meta.url);assert(fs.existsSync(wav));assert(fs.statSync(wav).size>1000);assert(audio.includes("new URL('../assets/coin-pickup.wav', import.meta.url)"));assert(audio.includes('this.pickupAudio.volume = on ? 0.55 : 0'));assert(audio.includes('pickupAudio.pause()'));assert(audio.includes('promise.catch'));assert(audio.includes('#coinFallback() { this.#cashFallback(); }'));assert(audio.includes('this.#cashFallback()'));assert(main.includes('sound.coin()'));assert(main.includes('sound.cash()'));});
t('passengers walk in small groups and only disappear at the entrance',()=>{assert(fs.readFileSync(new URL('../src/world.js',import.meta.url),'utf8').includes('boardingActive.length < 3'));const w=createWorld(new THREE.Scene(),{trafficRandom:()=>0.9});w.setRouteOrigin(0);w.setBoarded(3,-4,-940);assert.equal(w.boardingDone,false);for(let i=0;i<180;i++)w.update(1/60,-4,-940,i/60,false);assert.equal(w.boardingDone,true);});
t('boarding fare is announced after boarding animation completes',()=>{assert(main.includes('boardingFarePending && world.boardingDone'));assert(main.includes('world.boardingDone ? journey.fare : 0'));});
t('leaderboard is hidden until opened and periods filter saved local runs',()=>{assert(html.includes('id="leaderboardBtn"'));assert(html.includes('id="leaderboardPanel" class="overlay hidden modal-overlay"'));assert(home.includes("$('leaderboardBtn').addEventListener('click'"));assert(home.includes("period==='week'"));assert(home.includes("period==='month'"));assert(home.includes('koroperun_local_runs'));assert(html.includes('Close leaderboard'));});
t('original route, Terminal, pause, powerups and separate balances remain present',()=>{for(const x of ['terminalArrow','pauseScreen','pauseCoins','pauseCash','garagePanel','magnetStat'])assert(html.includes(x),x);const route=fs.readFileSync(new URL('../src/route.js',import.meta.url),'utf8');for(const x of ['Oke-Fia','Lamenco','Agunbelewo'])assert(route.includes(x),x);assert(main.includes('coins += got; cash += world.cashGot'));assert(main.includes('MAGNET_DURATION'));});

t('bundled sound plays once for each successful coin/cash pickup and stops when muted',()=>{
  let plays=0,pauses=0;globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.Audio=class{constructor(src){this.src=String(src);this.volume=1;this.currentTime=0;}pause(){pauses++;}play(){plays++;return Promise.resolve();}};
  const node=()=>({gain:{value:0},frequency:{value:0,setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},disconnect(){},start(){},stop(){},type:'',onended:null});
  globalThis.window={AudioContext:class{constructor(){this.state='running';this.currentTime=0;this.sampleRate=8000;this.destination={};}createGain(){return node();}createBuffer(){return {getChannelData(){return new Float32Array(16);}};}createOscillator(){return node();}createBiquadFilter(){return node();}createBufferSource(){return node();}resume(){return Promise.resolve();}}};
  const snd=new Sound();snd.unlock();snd.coin();snd.coin();snd.cash();assert.equal(plays,3);assert(snd.pickupAudio.src.endsWith('/assets/coin-pickup.wav'));snd.setOn(false);snd.coin();snd.cash();assert.equal(plays,3);assert(pauses>=1);
});
t('motorcycle and bicycle rider models are scaled for normal camera readability',()=>{const w=createWorld(new THREE.Scene(),{trafficRandom:()=>0.01});assert(w.traffic.every(v=>v.models.motorcycle.scale.x>=1.25&&v.models.bicycle.scale.x>=1.45));assert(w.traffic.every(v=>v.models.motorcycle.children.length>=6&&v.models.bicycle.children.length>=7));});
console.log('Chapter 6 improvements tests passed:',n);
