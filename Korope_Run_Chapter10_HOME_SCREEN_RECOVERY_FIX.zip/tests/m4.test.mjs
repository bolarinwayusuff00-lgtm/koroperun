import assert from 'node:assert';
let made=[];
const mk=()=>({style:{},classList:{_s:new Set(),add(c){this._s.add(c)},remove(...c){c.forEach(x=>this._s.delete(x))}},setAttribute(){},offsetWidth:1,getContext:()=>({fillRect(){},fillText(){}})});
globalThis.document={createElement:()=>{const e=mk();made.push(e);return e},body:{appendChild(){}}};
globalThis.innerWidth=800;globalThis.innerHeight=600;
const THREE=await import('three');
const {Effects}=await import('../src/effects.js');
const {createWorld}=await import('../src/world.js');
const scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera();cam.position.set(0,4,10);cam.lookAt(0,1,-9);cam.updateMatrixWorld();
const fx=new Effects(scene,cam);
fx.coin(0,1,0,'+25');fx.hit(0,1,0,true);
const vis=()=>fx.parts.filter(p=>p.m.visible).length;
assert(vis()===30);
for(let i=0;i<60;i++)fx.update(1/60);
assert(vis()===0,'particles expire');
for(let i=0;i<200;i++)fx.hit(0,1,0,true);
assert(vis()<=48,'pool bounded');fx.reset();assert(vis()===0);
const w=createWorld(scene);let n=0;w.setCoinHandler(()=>n++);
// find a coin ahead and drive onto it
let got=0;for(let z=0;z>-300;z-=1){got+=w.update(0.016,0,z,0,true);}
const n1=n;assert(got===n1&&got>0,'callback once per coin '+got+' '+n1);
let got2=0;for(let z=-300;z>-600;z-=1){got2+=w.update(0.016,0,z,0,false);}
assert(got2===0&&n===n1,'no pickup when collect=false');
console.log('all tests passed; coins',got,'objects',scene.children.length);
