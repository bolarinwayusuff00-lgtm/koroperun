// Milestone 6A tests: route, pickup rules, capacity, fare, independence from coins/score, world wiring.
import assert from 'node:assert';
import fs from 'node:fs';
const el = () => ({ style: {}, classList: { add() {}, remove() {} }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {} }) });
globalThis.document = { createElement: el, body: { appendChild() {} } };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
const R = await import('../src/route.js');
const { Journey, PICKUP, FARE_PER_PASSENGER, DEFAULT_CAPACITY, PICKUP_MAX_SPEED, BOARD_HOLD, LAMENCO_D, AGUNBELEWO_D, inPickupZone, ROUTE, JUNCTION } = R;
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };
const mid = (PICKUP.start + PICKUP.end) / 2, bayX = -4;
const sit = (j, d, x, speed, secs) => { let ev = null; for (let i = 0; i < Math.round(secs * 60); i++) ev = j.update(1 / 60, d, x, speed) || ev; return ev; };

t('constants', () => { assert.strictEqual(FARE_PER_PASSENGER, 200); assert.strictEqual(DEFAULT_CAPACITY, 9); assert(PICKUP_MAX_SPEED <= 1.5); });
t('route order Oke-Fia < Lamenco < Agunbelewo', () => { assert.deepStrictEqual(ROUTE.stops.map((s) => s.name), ['Oke-Fia', 'Lamenco', 'Agunbelewo']); assert(ROUTE.stops[0].d < ROUTE.stops[1].d && ROUTE.stops[1].d < ROUTE.stops[2].d); assert.strictEqual(ROUTE.length, AGUNBELEWO_D); });
t('pickup bay is before and outside the junction, on the road, left side', () => {
  assert(PICKUP.end < JUNCTION.d - JUNCTION.half - 10, 'bay ends well before the junction box');
  assert(PICKUP.xMax < 0 && PICKUP.xMin >= -6, 'bay is on the left, on the asphalt');
});
t('zone detection', () => { assert(inPickupZone(mid, bayX)); assert(!inPickupZone(PICKUP.start - 1, bayX)); assert(!inPickupZone(PICKUP.end + 1, bayX)); assert(!inPickupZone(mid, 0), 'centre lane is outside'); assert(!inPickupZone(mid, 4)); });
t('driving through at normal speed never boards', () => {
  const j = new Journey(); let ev = null;
  for (let d = PICKUP.start - 50; d < PICKUP.end + 50; d += 20 * (1 / 60)) ev = j.update(1 / 60, d, bayX, 20) || ev; // 20 m/s through the bay
  assert.strictEqual(j.passengers, 0); assert.strictEqual(j.fare, 0); assert.strictEqual(j.pickup, 'missed'); assert.strictEqual(ev, 'missed'); assert.strictEqual(j.stage, 'toAgunbelewo');
});
t('too fast (just above the limit) does not board', () => { const j = new Journey(); sit(j, mid, bayX, PICKUP_MAX_SPEED + 0.1, 5); assert.strictEqual(j.passengers, 0); assert.strictEqual(j.pickup, 'pending'); });
t('stopped in zone but outside bay x does not board', () => { const j = new Journey(); sit(j, mid, 0, 0, 5); assert.strictEqual(j.passengers, 0); });
t('stopped before or after the zone does not board', () => { const j = new Journey(); sit(j, PICKUP.start - 5, bayX, 0, 5); assert.strictEqual(j.passengers, 0); });
t('nearly stopped boards after the short hold, not instantly', () => {
  const j = new Journey(); sit(j, mid, bayX, 0.5, 1 / 60); assert.strictEqual(sit(j, mid, bayX, 0.5, BOARD_HOLD / 2), null); assert.strictEqual(j.passengers, 0);
  assert.strictEqual(sit(j, mid, bayX, 0.5, BOARD_HOLD), 'boarded'); assert.strictEqual(j.passengers, 9); assert.strictEqual(j.fare, 1800); assert.strictEqual(j.stage, 'toAgunbelewo');
});
t('moving resets the hold timer', () => { const j = new Journey(); sit(j, mid, bayX, 0, BOARD_HOLD * 0.9); sit(j, mid, bayX, 5, 0.1); assert.strictEqual(j.hold, 0); sit(j, mid, bayX, 0, BOARD_HOLD * 0.9); assert.strictEqual(j.passengers, 0); });
t('boards once per trip: staying in the zone / re-entering does not duplicate', () => {
  const j = new Journey(); let boards = 0; for (let i = 0; i < 600; i++) if (j.update(1 / 60, mid, bayX, 0) === 'boarded') boards++;
  assert.strictEqual(boards, 1); assert.strictEqual(j.passengers, 9); assert.strictEqual(j.fare, 1800);
  sit(j, mid + 3, bayX, 0, 3); sit(j, mid, bayX, 0, 3); assert.strictEqual(j.passengers, 9); assert.strictEqual(j.fare, 1800);
});
t('capacity limits boarding (12 waiting, default 9)', () => { const j = new Journey(); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.waiting, 12); assert.strictEqual(j.passengers, 9); });
t('configurable capacity and fare', () => {
  let j = new Journey({ capacity: 4 }); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.passengers, 4); assert.strictEqual(j.fare, 800);
  j = new Journey({ capacity: 20, waiting: 6 }); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.passengers, 6, 'cannot board more than are waiting'); assert.strictEqual(j.fare, 1200);
  j = new Journey({ capacity: 5, farePerPassenger: 250 }); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.fare, 1250);
  j = new Journey({ capacity: 0 }); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.passengers, 0); assert.strictEqual(j.fare, 0);
  j = new Journey({ capacity: -3, waiting: NaN }); assert.strictEqual(j.capacity, 9); assert.strictEqual(j.waiting, 12);
});
t('fare = passengers x 200 for every capacity 0..12', () => { for (let c = 0; c <= 12; c++) { const j = new Journey({ capacity: c }); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.fare, j.passengers * 200); } });
t('journey progress: Lamenco reached, then Agunbelewo', () => {
  const j = new Journey(); assert(!j.reachedLamenco); assert.strictEqual(j.stage, 'toLamenco');
  assert.strictEqual(j.update(0.016, PICKUP.start + 0.1, bayX, 10), 'reachedLamenco'); assert(j.reachedLamenco);
  sit(j, mid, bayX, 0, 1); assert.strictEqual(j.stage, 'toAgunbelewo'); assert(!j.reachedAgunbelewo);
  assert.strictEqual(j.update(0.016, AGUNBELEWO_D, 0, 30), 'arrived'); assert.strictEqual(j.stage, 'arrived'); assert.strictEqual(j.passengers, 9);
  assert.strictEqual(j.update(0.016, AGUNBELEWO_D + 10, 0, 30), null, 'arrival fires once');
});
t('reset (restart) clears the trip and allows boarding again', () => { const j = new Journey(); sit(j, mid, bayX, 0, 1); j.reset(); assert.strictEqual(j.passengers, 0); assert.strictEqual(j.fare, 0); assert.strictEqual(j.stage, 'toLamenco'); assert(!j.reachedLamenco); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.passengers, 9); });
t('objective text', () => { const j = new Journey(); assert.strictEqual(j.objective(0), 'Lamenco 925 m'); sit(j, mid, bayX, 0, 1); assert.strictEqual(j.objective(1000), 'Agunbelewo 1.6 km'); assert.strictEqual(j.objective(AGUNBELEWO_D), 'Agunbelewo 0 m'); });

// ---- world wiring (real Three.js scene)
const THREE = await import('three');
const { createWorld } = await import('../src/world.js');
const { mapY } = await import('../src/minimap.js');
t('minimap maps route distance to the strip (start at bottom, end at top, Lamenco in proportion)', () => {
  assert(mapY(0, 180) > mapY(LAMENCO_D, 180) && mapY(LAMENCO_D, 180) > mapY(AGUNBELEWO_D, 180)); assert.strictEqual(mapY(-50, 180), mapY(0, 180)); assert.strictEqual(mapY(99999, 180), mapY(AGUNBELEWO_D, 180));
  const f = (mapY(0, 180) - mapY(LAMENCO_D, 180)) / (mapY(0, 180) - mapY(AGUNBELEWO_D, 180)); assert(Math.abs(f - LAMENCO_D / AGUNBELEWO_D) < 1e-9);
});
const scene = new THREE.Scene(), w = createWorld(scene);
t('world route landmarks follow the route origin and hide boarded passengers', () => {
  w.setRouteOrigin(-777); assert.strictEqual(w.routeOrigin, -777);
  const grp = scene.children.find((c) => c.isGroup && c.position.z === -777); assert(grp, 'route group moved to origin');
  const people = grp.children.filter((c) => c.isGroup && c.userData && c.userData.start); assert.strictEqual(people.length, R.WAITING_PASSENGERS);
  for (const p of people) { const d = -(p.position.z); assert(d > PICKUP.start && d < PICKUP.end, 'passenger inside bay length'); assert(p.position.x < -6, 'on the pavement, not the road'); }
  w.setBoarded(9, -4, -1717); assert.strictEqual(people.filter((p) => p.visible).length, 12, 'passengers remain visible while walking');
  for (let i = 0; i < 360; i++) w.update(1 / 60, -4, -1717, i / 60, false);
  assert.strictEqual(w.boardingDone, true); assert.strictEqual(people.filter((p) => p.visible).length, 3, 'only excess passengers remain waiting after boarding');
  w.setBoarded(0); assert.strictEqual(people.filter((p) => p.visible).length, 12, 'restart restores waiting passengers');
});
t('lane -4 has no car right behind the bus while the bay approach is active; coins still work', () => {
  w.setRouteOrigin(0); w.setPickupClear(true); const pz = -(PICKUP.start + PICKUP.end) / 2; let coins = 0, checked = 0;
  for (let i = 0; i < 1500; i++) {
    coins += w.update(0.016, -4, pz, i * 0.016, true);
    for (const g of scene.children) if (g.isGroup && g.position.x === -4 && g.children.length > 3 && g.children.length < 20) { const behind = g.position.z - pz; assert(!(behind > 8 && behind < 80), 'no lane -4 car 8-80 m behind: ' + behind); checked++; }
  }
  assert(checked > 0, 'traffic cars in lane -4 were actually inspected'); assert(coins >= 0);
  w.setPickupClear(false);
});

// ---- independence: main.js keeps coins/score/best separate from passengers/fare
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
t('main.js: score formula and coin counting unchanged; fare never feeds score/coins/best', () => {
  assert(main.includes('score = Math.floor(bus.distance / 10) + coins * COIN_POINTS;')); assert(main.includes('coins += got;'));
  assert(!/score\s*[+-]?=[^=;]*journey\./.test(main) && !/coins\s*[+-]?=[^=;]*journey\./.test(main) && !/bestScore\s*=[^=;]*journey\./.test(main));
  assert(main.includes('journey.update(') && main.includes('startTrip()'));
});
console.log('M6A tests passed:', n);
