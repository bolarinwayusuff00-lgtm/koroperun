// Coin pickup audio + Terminal arrow tests. MOCKED Web Audio / HTMLAudio / DOM / localStorage: these are not real-browser or real-device tests.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from 'three';

// ---------- environment mocks
const store = {};
globalThis.localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: (k) => { delete store[k]; } };
const clearStore = () => { for (const k of Object.keys(store)) delete store[k]; };
let fake = 1e6; performance.now = () => fake; // controllable clock: coin spacing is exact
const advance = (ms) => { fake += ms; };
const tick = () => new Promise((r) => setTimeout(r, 0));
const cls = () => { const set = new Set(['hidden']); return { toggles: 0, set, add: (c) => set.add(c), remove: (c) => set.delete(c), toggle(c, f) { this.toggles++; (f === undefined ? !set.has(c) : f) ? set.add(c) : set.delete(c); }, contains: (c) => set.has(c) }; };
const els = {};
const el = () => ({ style: { setProperty() {} }, classList: cls(), setAttribute() {}, appendChild() {}, offsetWidth: 1, textContent: '', parentElement: { classList: cls() }, firstElementChild: { textContent: '' }, lastElementChild: { textContent: '' }, getContext: () => ({ fillRect() {}, fillText() {}, clearRect() {}, beginPath() {}, arc() {}, fill() {}, stroke() {}, moveTo() {}, lineTo() {}, closePath() {} }) });
globalThis.document = { createElement: el, body: { appendChild() {} }, getElementById: (id) => (els[id] ||= el()), querySelectorAll: () => [] };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
let seed = 777; Math.random = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

let ctxs = [], started = 0;
const param = () => ({ value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} });
const node = () => ({ connect() {}, disconnect() {}, gain: param(), frequency: param(), type: '', buffer: null, start() { started++; }, stop() {}, onended: null });
class MockCtx { constructor() { this.state = 'suspended'; this.currentTime = 0; this.sampleRate = 8000; this.destination = {}; ctxs.push(this); }
  resume() { this.state = 'running'; return Promise.resolve(); } createGain() { return node(); } createOscillator() { return node(); } createBiquadFilter() { return node(); } createBufferSource() { return node(); }
  createBuffer(c, l) { return { getChannelData: () => new Float32Array(l) }; } }
class DecodingCtx extends MockCtx { decodeAudioData(ab, ok) { const b = { duration: 0.36 }; ok && ok(b); return Promise.resolve(b); } }
globalThis.window = globalThis;
// Mobile-like HTMLAudio: pause() on an element that is still sounding interrupts its play() (counted in `aborted`).
let plays = 0, aborted = 0, htmlReject = false, elements = 0;
globalThis.Audio = class { constructor(src) { this.src = String(src); this.volume = 1; this.currentTime = 0; this.duration = 0.36; this.startedAt = -1e9; elements++; }
  pause() { if (fake - this.startedAt < 360) aborted++; this.startedAt = -1e9; }
  play() { plays++; this.startedAt = fake; return htmlReject ? Promise.reject(new Error('NotAllowedError')) : Promise.resolve(); } };
let fetchOk = true, fetches = 0;
globalThis.fetch = async () => { fetches++; return fetchOk ? { ok: true, arrayBuffer: async () => new ArrayBuffer(8) } : { ok: false, status: 404 }; };
const reset = (C = MockCtx) => { ctxs = []; started = 0; plays = 0; aborted = 0; htmlReject = false; elements = 0; fetches = 0; fetchOk = true; globalThis.AudioContext = C; clearStore(); };

const { Sound } = await import('../src/audio.js');
const { createWorld } = await import('../src/world.js');
const { TerminalArrow, TERMINAL_ARROW_START, TERMINAL_ARROW_END } = await import('../src/terminal-warning.js');
const { PICKUP, Journey, LAMENCO_D, ROUTE } = await import('../src/route.js');
const { Hud } = await import('../src/hud.js');
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');
const main = read('../src/main.js'), html = read('../index.html'), css = read('../css/style.css'), audioSrc = read('../src/audio.js'), hudSrc = read('../src/hud.js'), arrowSrc = read('../src/terminal-warning.js');
let n = 0; const t = async (name, fn) => { await fn(); n++; console.log('  ok -', name); };
const heard = () => started + plays; // one pickup = exactly one Web Audio source OR one HTMLAudio play (a rejection adds the synth cue instead)

// =====================================================  COIN SOUND
await t('dense coin run (a coin every ~0.3 s, shorter than the 0.36 s sound): every coin plays once and none interrupts the previous one (HTMLAudio path)', async () => {
  reset(); const s = new Sound(); s.unlock(); await tick();
  for (let i = 0; i < 20; i++) { s.coin(); advance(300); }
  assert.equal(plays, 20, 'one play per coin'); assert.equal(aborted, 0, 'no pickup cut off a still-sounding one'); assert(elements <= 4, 'bounded pool of the same local WAV');
});

await t('coin and cash use the SAME path: Web Audio buffer when decoded, HTMLAudio otherwise, synth only as last resort', async () => {
  reset(DecodingCtx); let s = new Sound(); s.unlock(); await tick(); await tick(); assert(s.pickupBuf);
  for (const k of ['coin', 'cash', 'coin', 'cash']) { started = 0; plays = 0; s[k](); assert.equal(started, 1, k + ' = one buffer voice'); assert.equal(plays, 0); advance(50); }
  reset(); s = new Sound(); s.unlock(); await tick();
  for (const k of ['coin', 'cash']) { started = 0; plays = 0; s[k](); assert.equal(plays, 1, k + ' = one HTMLAudio play'); assert.equal(started, 0); advance(500); }
  reset(); htmlReject = true; s = new Sound(); s.unlock(); await tick(); // mobile rejects HTMLAudio: each kind plays its own synthesized cue once
  started = 0; s.coin(); await tick(); await tick(); assert.equal(started, 3, 'coin synth fallback = same 3-tone cash cue'); advance(500);
  started = 0; s.cash(); await tick(); await tick(); assert.equal(started, 3, 'cash synth fallback = 3 tones');
});

await t('every local asset path: the metallic WAV, no remote/YouTube source', async () => {
  reset(DecodingCtx); const urls = []; const f = globalThis.fetch; globalThis.fetch = async (u) => { urls.push(String(u)); return f(u); };
  const s = new Sound(); s.unlock(); await tick(); await tick(); globalThis.fetch = f;
  assert(urls[0].endsWith('/assets/coin-pickup.wav')); assert(s.pickupPool[0].src.endsWith('/assets/coin-pickup.wav'));
  assert(fs.existsSync(new URL('../assets/coin-pickup.wav', import.meta.url))); assert(!/https?:\/\/|youtu\.be/i.test(audioSrc + main));
});

await t('pickup buffer that failed to load is retried (bounded) on later pickups, and pickups still sound meanwhile', async () => {
  reset(DecodingCtx); fetchOk = false; const s = new Sound(); s.unlock(); await tick(); await tick(); assert.equal(s.pickupBuf, null);
  fetchOk = true; plays = 0; s.coin(); assert.equal(plays, 1, 'HTMLAudio covers the gap while the buffer is (re)loading'); await tick(); await tick(); advance(500);
  started = 0; plays = 0; s.coin(); assert.equal(started, 1, 'buffer path takes over after the retry'); assert.equal(plays, 0);
  fetchOk = false; fetches = 0; const b = new Sound(); b.unlock(); await tick(); await tick(); for (let i = 0; i < 20; i++) { b.coin(); advance(500); await tick(); } assert(fetches <= 3, 'retries are bounded: ' + fetches);
});

await t('Game Sound off / mute: no coin or cash sound on any path, also across Pause -> Continue, and the saved choice is unchanged', async () => {
  for (const C of [MockCtx, DecodingCtx]) {
    reset(C); const s = new Sound(); s.unlock(); await tick(); await tick(); s.setOn(false); const snap = JSON.stringify(store);
    for (let i = 0; i < 6; i++) { s.pauseAudio(); ctxs[0].state = 'suspended'; s.unlock(); await tick(); started = 0; plays = 0; s.coin(); s.cash(); advance(500); assert.equal(started + plays, 0); }
    assert.equal(JSON.stringify(store), snap); assert.equal(new Sound().on, false);
  }
  reset(); store.koroperun_game_sound = '0'; const m = new Sound(); m.unlock(); await tick(); m.coin(); m.cash(); assert.equal(plays + started, 0, 'Settings Game Sound off at load = silent coins');
  reset(); store.koroperun_game_sound = '1'; const o = new Sound(); o.unlock(); await tick(); o.coin(); assert.equal(plays, 1, 'Game Sound on = coin plays');
});

await t('Pause -> Continue (suspended and iOS interrupted): the next coin still plays exactly once, in both audio paths, over repeated cycles', async () => {
  for (const C of [MockCtx, DecodingCtx]) {
    reset(C); const s = new Sound(); s.unlock(); await tick(); await tick();
    for (let i = 0; i < 8; i++) { s.pauseAudio(); ctxs[0].state = i % 2 ? 'interrupted' : 'suspended'; s.unlock(); await tick(); advance(500); started = 0; plays = 0; s.coin(); assert.equal(started + plays, 1, 'cycle ' + i); }
    assert.equal(ctxs.length, 1, 'no extra AudioContext');
  }
});

await t('cash sound and engine audio still work after the change (cash once; one engine oscillator; engine silent when not driving)', async () => {
  reset(DecodingCtx); const s = new Sound(); s.unlock(); await tick(); await tick();
  started = 0; s.cash(); assert.equal(started, 1); s.engine(20, true, 0.1); const e = started; for (let i = 0; i < 50; i++) s.engine(25, true, 0.05); assert.equal(started, e, 'engine created once');
  s.pauseAudio(); assert.equal(s.eng.g.gain.value, 0); for (let i = 0; i < 20; i++) s.engine(0, false, 0.1); assert.equal(s.eng.g.gain.value, 0);
});

await t('real world: exactly one coin sound per collected coin, with Pause -> Continue cycles in between', async () => {
  reset(DecodingCtx); const s = new Sound(); s.unlock(); await tick(); await tick();
  const w = createWorld(new THREE.Scene()); let handlerCalls = 0, voices = 0; const orig = s.coin.bind(s);
  w.setCoinHandler(() => { handlerCalls++; started = 0; plays = 0; orig(); voices += started + plays; });
  let got = 0, z = 0;
  for (let cycle = 0; cycle < 10; cycle++) {
    for (let i = 0; i < 300; i++) { got += w.update(0.016, 0, z, 0, true); z -= 0.25; advance(16); }
    s.pauseAudio(); ctxs[0].state = 'suspended'; s.unlock(); await tick(); // pause: world.update is not called; Continue: wake audio
  }
  assert(got > 3); assert.equal(handlerCalls, got); assert.equal(voices, got, 'one sound per coin');
  const zc = z; for (let i = 0; i < 100; i++) got += w.update(0.016, 0, zc, 0, true); assert.equal(handlerCalls, got, 'standing on a collected spot never repeats');
});

await t('main.js wiring: sound plays first in the coin handler, once; cash handler unchanged; single handlers; no new contexts', () => {
  const m = main.match(/world\.setCoinHandler\(\(x, y, z\) => \{(.*?)\}\);/s)[1];
  assert(m.indexOf('sound.coin()') >= 0 && m.indexOf('sound.coin()') < m.indexOf('addEarnedCoins(1)')); assert.equal(m.split('sound.coin()').length - 1, 1);
  assert(main.includes('hud.pulseCash(); sound.cash();')); assert.equal(main.split('world.setCoinHandler(').length - 1, 1);
  assert(!/new (Webkit)?AudioContext|window\.AudioContext/.test(main)); assert(audioSrc.includes('#pickupSound(')); assert(/coin\(\) \{ try \{ this\.#pickupSound\('cash'\)/.test(audioSrc) && /cash\(\) \{ try \{ this\.#pickupSound\('cash'\)/.test(audioSrc));
});

// =====================================================  TERMINAL ARROW
await t('arrow visibility window: hidden before it, shown inside, hidden on reaching the bay and after', () => {
  const a = new TerminalArrow(); assert.equal(TERMINAL_ARROW_END, PICKUP.start); assert(TERMINAL_ARROW_START < PICKUP.start && PICKUP.start - TERMINAL_ARROW_START >= 100 && PICKUP.start - TERMINAL_ARROW_START <= 300, 'sensible approach distance');
  assert.equal(a.update(0), null); assert.equal(a.visible, false); assert.equal(a.update(TERMINAL_ARROW_START - 0.01), null);
  assert.equal(a.update(TERMINAL_ARROW_START), true); assert.equal(a.visible, true);
  for (let d = TERMINAL_ARROW_START; d < PICKUP.start; d += 5) { assert.equal(a.update(d), null, 'no repeated show events'); assert.equal(a.visible, true); }
  assert.equal(a.update(PICKUP.start), false); assert.equal(a.visible, false); assert.equal(a.update((PICKUP.start + PICKUP.end) / 2), null); assert.equal(a.update(PICKUP.end + 400), null);
});

await t('arrow hides on pause / crash / menu (not playing), on boarding or a missed pickup, and returns on Continue inside the window', () => {
  const a = new TerminalArrow(), mid = TERMINAL_ARROW_START + 80;
  assert.equal(a.update(mid, 'pending', true), true);
  assert.equal(a.update(mid, 'pending', false), false, 'paused / crashed / menu'); assert.equal(a.update(mid, 'pending', false), null);
  assert.equal(a.update(mid, 'pending', true), true, 'Continue shows it again'); assert.equal(a.update(mid, 'done', true), false, 'boarded'); assert.equal(a.update(mid, 'missed', true), null, 'stays hidden once missed (e.g. reversing back)');
  for (const bad of [NaN, undefined, null, 'x', Infinity, -Infinity]) { const b = new TerminalArrow(); b.update(mid); b.update(bad); assert.equal(b.visible, false, 'bad distance -> hidden: ' + bad); }
  a.update(mid); a.reset(); assert.equal(a.visible, false);
});

await t('driving the real Journey through the approach: exactly one show and one hide; the arrow never changes the trip', () => {
  for (const speed of [30, 8]) {
    const j = new Journey(), a = new TerminalArrow(); let shows = 0, hides = 0, boardedAt = null;
    for (let d = 0, i = 0; d < PICKUP.end + 100 && i < 20000; i++) {
      const bayX = -4, inBay = d >= PICKUP.start && d <= PICKUP.end, sp = inBay ? 0 : speed; // stop in the bay only when we get there
      const ev = j.update(1 / 60, d, bayX, sp); if (ev === 'boarded' && boardedAt === null) boardedAt = d;
      const r = a.update(d, j.pickup, true); if (r === true) shows++; if (r === false) hides++;
      if (!inBay || j.pickup === 'done') d += sp / 60 || 0.3; if (j.pickup === 'done' && d > PICKUP.end + 90) break;
    }
    assert.equal(shows, 1); assert.equal(hides, 1); assert.equal(j.passengers, 9); assert.equal(j.fare, 1800, 'fare/capacity logic untouched'); assert(boardedAt >= PICKUP.start);
  }
  assert(!/bus|journey|world|boarded|speed\s*=/.test(arrowSrc.replace(/\/\/.*$/gm, '').replace(/Journey\.pickup/g, '')), 'module is display logic only: it cannot stop the bus or board passengers');
});

await t('HUD arrow: DOM touched only when visibility changes; element is created once in index.html; cached state survives many frames', () => {
  const hud = new Hud(), box = els.terminalArrow; assert(box.classList.contains('hidden')); const base = box.classList.toggles;
  for (let i = 0; i < 500; i++) hud.showTerminalArrow(false); assert.equal(box.classList.toggles, base, 'hidden -> hidden touches nothing');
  hud.showTerminalArrow(true); assert(!box.classList.contains('hidden')); for (let i = 0; i < 500; i++) hud.showTerminalArrow(true); assert.equal(box.classList.toggles, base + 1);
  hud.showTerminalArrow(false); assert(box.classList.contains('hidden')); assert.equal(box.classList.toggles, base + 2);
  assert.equal(html.split('id="terminalArrow"').length - 1, 1); assert(!/createElement/.test(hudSrc.slice(hudSrc.indexOf('showTerminalArrow'), hudSrc.indexOf('showTerminalArrow') + 300)));
});

await t('old text notification is gone everywhere; arrow glyph is a down arrow; hidden by default; aria-hidden', () => {
  for (const [name, src] of [['html', html], ['css', css], ['main', main], ['hud', hudSrc], ['arrow', arrowSrc]]) assert(!/TERMINAL AHEAD|terminalNotice|showTerminalNotice|Prepare to stop/.test(src), name + ' still mentions the text notice');
  const tag = html.match(/<div id="terminalArrow"[^>]*>(.*?)<\/div>/s); assert(tag); assert(/class="hidden"/.test(tag[0]) && /aria-hidden="true"/.test(tag[0])); assert(/&#x2B07;|\u2B07/.test(tag[1])); assert(!/[A-Za-z]{3,}/.test(tag[1].replace(/&#x[0-9A-F]+;/gi, '')), 'no text inside');
});

await t('CSS: smooth repeating bounce (plus reduced-motion pulse), high contrast, never blocks touches, sits clear of HUD / minimap / controls / hint', () => {
  const rule = css.match(/#terminalArrow\{[^}]*\}/)[0];
  for (const x of ['position:fixed', 'left:50%', 'pointer-events:none', 'animation:terminalArrowBounce', 'infinite', 'ease-in-out', 'border:3px solid var(--yellow)', 'rgba(7,26,49']) assert(rule.includes(x), x);
  assert(/@keyframes terminalArrowBounce\{[^}]*translateY[^}]*\}[^}]*translateY/.test(css)); assert(/prefers-reduced-motion:reduce\)\{#terminalArrow\{animation:terminalArrowPulse/.test(css));
  assert(Number(rule.match(/z-index:(\d+)/)[1]) < 180, 'below the pause overlay (180)'); assert(/top:clamp\(124px/.test(rule), 'starts below the HUD row (and below the left magnet tile)');
  assert(/#hint\{[^}]*bottom:clamp\(128px/.test(css) && /#trip\{[^}]*right:max\(10px/.test(css), 'hint is bottom, minimap is at the right edge, arrow is centred at 24vh');
});

await t('main.js wiring: hides on pause, crash (state leaves playing), Home, new trip; the arrow adds no timers/listeners/rAF (the existing Home handler only resets it)', () => {
  assert(/function setPaused\(p\)[\s\S]*?sound\.pauseAudio\(\); terminalArrow\.reset\(\); hud\.showTerminalArrow\(false\)/.test(main));
  assert(main.includes("if (state !== 'playing') terminalArrow.reset();") && main.includes('hud.showTerminalArrow(terminalArrow.visible);'));
  assert(main.includes('terminalArrow.update(d, journey.pickup, true)')); assert(/startTrip\(\)[\s\S]{0,200}terminalArrow\.reset\(\); hud\.showTerminalArrow\(false\)/.test(main));
  assert(/state='menu'; terminalArrow\.reset\(\); hud\.showTerminalArrow\(false\)/.test(main));
  for (const line of (main + hudSrc + arrowSrc).split('\n').filter((l) => /terminalArrow|TerminalArrow/.test(l) && !l.startsWith("document.getElementById('homeBtn')"))) assert(!/addEventListener|setInterval|setTimeout|requestAnimationFrame|createElement|new THREE|\.animate\(/.test(line), line.slice(0, 80));
});

await t('route, Terminal sign, minimap and waiting passengers are untouched', () => {
  assert.deepEqual(ROUTE.stops.map((s) => s.name), ['Oke-Fia', 'Lamenco', 'Agunbelewo']); assert.equal(ROUTE.stops[1].d, LAMENCO_D);
  const world = read('../src/world.js'); assert(world.includes("signMaterial('TERMINAL'") && world.includes("gantry('LAMENCO JUNCTION'")); assert(read('../src/minimap.js').includes('s.name'));
  assert(main.includes('world.setBoarded(journey.passengers') && main.includes('boardingFarePending && world.boardingDone') && main.includes('tripHint(d)'));
});

console.log('Coin audio + Terminal arrow tests passed:', n);
