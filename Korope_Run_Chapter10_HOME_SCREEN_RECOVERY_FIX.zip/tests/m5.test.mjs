import assert from 'node:assert';
import fs from 'node:fs';
const el = () => ({ style: {}, classList: { add() {}, remove() {} }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {} }) });
globalThis.document = { createElement: el, body: { appendChild() {} } };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
// Fixed randomness keeps the coin-repeat regression deterministic across traffic respawn variations.
let testSeed = 12345; Math.random = () => (testSeed = (testSeed * 16807) % 2147483647) / 2147483647;
const store = {}; globalThis.localStorage = { getItem: (k) => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); } };

// ---- mock Web Audio: counts every started source
let started = 0, created = 0, stopped = 0;
class Param { constructor() { this.value = 0; } setValueAtTime() {} exponentialRampToValueAtTime() {} }
const node = () => ({ connect() {}, disconnect() {}, gain: new Param(), frequency: new Param(), type: '', start() { started++; }, stop() { stopped++; }, onended: null });
globalThis.window = globalThis;
globalThis.AudioContext = class { constructor() { created++; this.state = 'suspended'; this.currentTime = 0; this.sampleRate = 8000; this.destination = {}; }
  resume() { this.state = 'running'; return Promise.resolve(); }
  createGain() { return node(); } createOscillator() { return node(); } createBiquadFilter() { return node(); } createBufferSource() { return node(); }
  createBuffer(c, l) { return { getChannelData: () => new Float32Array(l) }; } };

const THREE = await import('three');
const { createWorld } = await import('../src/world.js');
const { Sound } = await import('../src/audio.js');

// ---- PART A: coins
const scene = new THREE.Scene(); const w = createWorld(scene);
let popups = 0; w.setCoinHandler(() => popups++);
let coins = 0, total = 0;
// drive down the road repeatedly in small steps (many frames overlapping each coin) in each lane
for (const lane of [-4, 0, 4]) for (let z = 0; z > -400; z -= 0.25) { const g = w.update(0.016, lane, z, 0, true); assert(g === 0 || g === 1 || g === 2); coins += g; }
assert(coins > 0, 'collected some coins'); assert.strictEqual(popups, coins, 'one popup per coin, equal to coin count');
// a stationary bus sitting on a coin must not re-collect it
const before = coins; let zc = null;
for (let z = -500; z > -900; z -= 0.25) { const g = w.update(0.016, 0, z, 0, true); if (g) { zc = z; coins += g; break; } }
assert(zc !== null); const afterFirst = coins;
for (let i = 0; i < 120; i++) coins += w.update(0.016, 0, zc, 0, true);
assert.strictEqual(coins, afterFirst, 'repeat contact cannot double count');
assert.strictEqual(afterFirst - before, 1, 'exactly +1 for one coin');
// after "restart" (counter reset to 0, world kept) new coins still collectible exactly once each
coins = 0; w.resetTraffic(zc);
let again = 0; for (let z = zc; z > zc - 600; z -= 0.25) again += w.update(0.016, 0, z, 0, true);
assert(again > 0, 'coins collectible after restart');
// main.js wiring: popup text is +1 coin, coins += got, score uses COIN_POINTS separately
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
assert(main.includes("'+1 coin'") && !main.includes("'+' + COIN_POINTS") && main.includes('coins += got;') && main.includes('coins * COIN_POINTS'));

// ---- PART B: audio
const s = new Sound(); assert.strictEqual(created, 0, 'no AudioContext before a user gesture');
s.coin(); s.crash(); assert.strictEqual(started, 0, 'no sound before unlock');
s.unlock(); s.unlock(); assert.strictEqual(created, 1, 'single AudioContext');
await Promise.resolve();
started = 0; s.coin(); assert.strictEqual(started, 3, 'coin = same three-tone cash cue'); s.coin(); assert.strictEqual(started, 3, 'coin sounds throttled');
started = 0; s.bump(); assert.strictEqual(started, 1);
started = 0; s.crash(); assert.strictEqual(started, 2, 'crash = noise + thud once');
s.engine(20, true, 0.016); s.engine(30, true, 0.016); assert.strictEqual(created, 1);
const engStarts = started; for (let i = 0; i < 100; i++) s.engine(25, true, 0.016); assert.strictEqual(started, engStarts, 'engine oscillator created once');
s.silence(); assert.strictEqual(s.live.size, 0, 'silence clears live sounds');
s.setOn(false); started = 0; s.coin(); s.crash(); s.bump(); assert.strictEqual(started, 0, 'muted = silent'); assert.strictEqual(store.koroperun_sound, 'off');
assert.strictEqual(new Sound().on, false, 'mute persisted');
s.setOn(true); await Promise.resolve(); started = 0; s.bump(); assert.strictEqual(started, 1, 'unmute works');
// broken audio never throws
globalThis.AudioContext = class { constructor() { throw new Error('no audio'); } };
const bad = new Sound(); bad.unlock(); bad.coin(); bad.crash(); bad.engine(10, true, 0.016);
console.log('M5 tests passed: coins', coins, 'popups', popups);
