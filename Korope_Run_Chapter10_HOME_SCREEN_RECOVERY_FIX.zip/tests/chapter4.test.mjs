// Chapter 4 tests: naira cash bundles (reward, exactly-once, rarity/positions, HUD, sound, cleanup/restart) and "nothing else changed".
import assert from 'node:assert';
import fs from 'node:fs';

// ---- minimal DOM / storage / Web Audio mocks (same style as the earlier chapters)
const made = [];
const mk = () => { const e = { style: {}, className: '', textContent: '', classes: new Set(), classList: { add(...c) { c.forEach((x) => e.classes.add(x)); }, remove(...c) { c.forEach((x) => e.classes.delete(x)); }, toggle(c, on) { on ? e.classes.add(c) : e.classes.delete(c); }, contains: (c) => e.classes.has(c) }, setAttribute() {}, offsetWidth: 1, getContext: () => ({ fillRect() {}, fillText() {} }) }; e.parentElement = { classList: e.classList }; made.push(e); return e; };
const byId = {};
globalThis.document = { createElement: mk, body: { appendChild() {} }, getElementById: (id) => (byId[id] ||= mk()) };
globalThis.innerWidth = 800; globalThis.innerHeight = 600;
const store = {}; globalThis.localStorage = { getItem: (k) => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); } };
let started = 0, created = 0;
class Param { constructor() { this.value = 0; } setValueAtTime() {} exponentialRampToValueAtTime() {} }
const node = () => ({ connect() {}, disconnect() {}, gain: new Param(), frequency: new Param(), type: '', start() { started++; }, stop() {}, onended: null });
globalThis.window = globalThis;
globalThis.AudioContext = class { constructor() { created++; this.state = 'suspended'; this.currentTime = 0; this.sampleRate = 8000; this.destination = {}; }
  resume() { this.state = 'running'; return Promise.resolve(); }
  createGain() { return node(); } createOscillator() { return node(); } createBiquadFilter() { return node(); } createBufferSource() { return node(); }
  createBuffer(c, l) { return { getChannelData: () => new Float32Array(l) }; } };

const THREE = await import('three');
const { CashField, CASH, CASH_REWARD, NAIRA, formatNaira } = await import('../src/cash.js');
const { createWorld, ROAD } = await import('../src/world.js');
const { Hud } = await import('../src/hud.js');
const { Effects } = await import('../src/effects.js');
const { Sound } = await import('../src/audio.js');
const { Journey, FARE_PER_PASSENGER, DEFAULT_CAPACITY } = await import('../src/route.js');

let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };
const seeded = (s) => () => (s = (s * 16807) % 2147483647) / 2147483647;
const read = (f) => fs.readFileSync(new URL(f, import.meta.url), 'utf8');
const bundles = (w) => w.cash.items.map((b) => b.g);
const newWorld = (opts = {}) => { const scene = new THREE.Scene(); return { scene, w: createWorld(scene, { random: seeded(7), ...opts }) }; };

// ---------------- reward amounts
t('default reward is 500 naira and is configurable', () => {
  assert.strictEqual(CASH_REWARD, 500);
  assert.strictEqual(newWorld().w.cashReward, 500);
  assert.strictEqual(newWorld({ cashReward: 1000 }).w.cashReward, 1000);
  const w = newWorld().w; assert.strictEqual(w.setCashReward(250), 250); assert.strictEqual(w.cashReward, 250);
});
t('invalid rewards fall back to the current/default value', () => {
  for (const bad of [0, -5, NaN, Infinity, 'x', null, undefined]) assert.strictEqual(new CashField(new THREE.Scene(), { reward: bad }).reward, 500, String(bad));
  const w = newWorld().w; w.setCashReward(300); w.setCashReward(-1); w.setCashReward(NaN); assert.strictEqual(w.cashReward, 300);
});
t('naira formatting: symbol and thousands separator', () => { assert.strictEqual(NAIRA, '₦'); assert.strictEqual(formatNaira(500), '₦500'); assert.strictEqual(formatNaira(1500), '₦1,500'); assert.strictEqual(formatNaira(0), '₦0'); });
t('each bundle pays exactly the reward; the total is reward x bundles', () => {
  for (const reward of [500, 1000, 75]) {
    const { w } = newWorld({ cashReward: reward }); const amounts = [];
    let total = 0, count = 0; w.setCashHandler((x, y, z, amt) => amounts.push(amt));
    for (let z = 0; z > -1500; z -= 0.5) { const got = (w.update(0.016, 0, z, 0, true), w.cashGot); assert([0, reward].includes(got), 'a frame pays 0 or one reward'); total += got; if (got) count++; }
    assert(count >= 1, 'collected something driving the centre'); assert(amounts.every((a) => a === reward)); assert.strictEqual(amounts.length, count); assert.strictEqual(total, reward * count);
  }
});

// ---------------- exactly once
t('a bundle pays once: sitting on it for hundreds of frames never pays again', () => {
  const { w } = newWorld(); let hits = 0; w.setCashHandler(() => hits++);
  const target = bundles(w).slice().sort((a, b) => b.position.z - a.position.z)[0], px = target.position.x, pz = target.position.z;
  let paid = 0; for (let i = 0; i < 600; i++) paid += (w.update(0.016, px, pz, i * 0.016, true), w.cashGot);
  assert.strictEqual(paid, 500, 'paid exactly one reward'); assert.strictEqual(hits, 1, 'handler called exactly once');
  assert.strictEqual(w.cash.collected, 1);
});
t('the collected bundle is moved far ahead at once and shown again only there', () => {
  const scene = new THREE.Scene(); const f = new CashField(scene, { random: seeded(3) });
  const b = f.items[0].g; b.position.set(0, 1.15, -50); let hits = 0; f.onCollect = () => hits++;
  assert.strictEqual(f.update(0.016, 0, -50, 0, true), 500); assert.strictEqual(hits, 1); assert.strictEqual(f.collected, 1);
  assert(b.position.z < -50 - CASH.GAP_MIN + 1 || Math.abs(b.position.z + 50) > 100, 'relocated far ahead'); assert(b.visible);
  assert.strictEqual(f.update(0.016, 0, -50, 0.016, true), 0, 'same spot, same frame position: nothing left to pay'); assert.strictEqual(hits, 1);
});
t('no pay when collect=false (menu, paused-state callers, after a crash) and the bundle stays collectable afterwards', () => {
  const f = new CashField(new THREE.Scene(), { random: seeded(5) }); f.items.forEach((b, i) => b.g.position.set(0, 1.15, -50 - i * 150)); let hits = 0; f.onCollect = () => hits++;
  assert.strictEqual(f.update(0.016, 0, -50, 0, false), 0); assert.strictEqual(hits, 0); assert.strictEqual(f.collected, 0);
  assert.strictEqual(f.update(0.016, 0, -50, 0, true), 500); assert.strictEqual(hits, 1);
});
t('the pickup box: inside pays, just outside does not', () => {
  const f = new CashField(new THREE.Scene(), { random: seeded(5) }); const at = (px, pz) => { f.items.forEach((b, i) => b.g.position.set(0, 1.15, -50 - i * 150)); return f.update(0.016, px, pz, 0, true); };
  assert.strictEqual(at(CASH.RADIUS_X - 0.05, -50), 500); assert.strictEqual(at(CASH.RADIUS_X + 0.05, -50), 0);
  assert.strictEqual(at(0, -50 + CASH.RADIUS_Z - 0.05), 500); assert.strictEqual(at(0, -50 + CASH.RADIUS_Z + 0.05), 0);
});
t('fast driving (40 m/s at the 50 ms frame cap) cannot skip a bundle', () => {
  const f = new CashField(new THREE.Scene(), { random: seeded(5) }); f.items.forEach((b, i) => b.g.position.set(0, 1.15, -100 - i * 150)); f.onCollect = () => {};
  let paid = 0; for (let z = 0; z > -130; z -= 40 * 0.05) paid += f.update(0.05, 0, z, 0, true); assert.strictEqual(paid, 500);
});
t('a missed bundle is recycled to the front (never piles up behind the bus)', () => {
  const f = new CashField(new THREE.Scene(), { random: seeded(5) }); f.items.forEach((b, i) => b.g.position.set(4, 1.15, -50 - i * 150));
  f.update(0.016, -4, -50 - CASH.PASSED - 5, 0, true); // the first one is now 17 m behind
  assert(f.items[0].g.position.z < -50 - CASH.PASSED - 5, 'recycled ahead of the bus'); assert.strictEqual(f.collected, 0);
});

// ---------------- spawning: rarer than coins, varied and reachable
t('bundles are much rarer than coins', () => {
  const { w } = newWorld(); let coins = 0, cash = 0, hits = 0; w.setCashHandler(() => hits++);
  const lanes = [-4, 0, 4, 2, -2];
  for (let z = 0, i = 0; z > -6000; z -= 0.5, i++) { coins += w.update(0.016, lanes[Math.floor(-z / 150) % 5], z, 0, true); cash += w.cashGot / 500; }
  assert(coins > 0 && cash > 0, `coins ${coins}, bundles ${cash}`); assert(cash * 4 < coins, `bundles ${cash} must be far fewer than coins ${coins}`);
});
t('spacing is 110-200 m and positions are varied, on the road and never the same slot twice in a row', () => {
  const f = new CashField(new THREE.Scene(), { random: seeded(11) }); const xs = [];
  for (let k = 0; k < 400; k++) { // fresh layouts at many positions
    f.reset(-k * 500);
    const placed = f.items.map((b) => ({ x: b.g.position.x, z: b.g.position.z })).sort((a, b) => b.z - a.z);
    for (let i = 1; i < placed.length; i++) { const gap = placed[i - 1].z - placed[i].z; assert(gap >= CASH.GAP_MIN - 1e-9 && gap <= CASH.GAP_MAX + 1e-9, 'gap ' + gap); }
    assert(placed[0].z <= -k * 500 - CASH.FIRST_MIN + 1e-9 && placed[0].z >= -k * 500 - CASH.FIRST_MAX - 1e-9, 'first bundle 80-130 m ahead');
    placed.forEach((p) => xs.push(p.x));
  }
  assert(xs.every((x) => CASH.SLOTS.includes(x))); assert(xs.every((x) => Math.abs(x) <= ROAD.limit), 'reachable: inside the road limit');
  assert.strictEqual(new Set(xs).size, CASH.SLOTS.length, 'all slots get used');
  // every placement asks avoid(x, z) once (it never says "taken" here), so the call log is the placement order, including recycled bundles
  const log = []; const g = new CashField(new THREE.Scene(), { random: seeded(2), avoid: (x) => { log.push(x); return false; } });
  for (let z = 0; z > -20000; z -= 2) g.update(0.016, 100, z, 0, true); // far to the side: nothing is collected, every bundle is missed and recycled
  assert(log.length > 100, 'many placements ' + log.length); for (let i = 1; i < log.length; i++) assert.notStrictEqual(log[i], log[i - 1], 'same slot twice in a row at placement ' + i);
  assert.strictEqual(new Set(log).size, CASH.SLOTS.length);
});
t('every x slot is reachable without the rumble strip (|x| <= soft limit, bus stays on the asphalt)', () => { for (const x of CASH.SLOTS) assert(Math.abs(x) <= ROAD.soft && Math.abs(x) <= ROAD.limit, 'x ' + x); assert(CASH.RADIUS_X >= 1.4, 'pickup box at least as forgiving as a coin'); });
t('avoid hook: a taken slot is skipped, and with everything taken a bundle still spawns', () => {
  const g = new CashField(new THREE.Scene(), { random: seeded(9), avoid: (x) => x === 0 }); let centre = 0, total = 0;
  for (let k = 0; k < 300; k++) { g.reset(-k * 300); for (const b of g.items) { total++; if (b.g.position.x === 0) centre++; } }
  assert(centre / total < 0.005, `centre lane was declared taken: ${centre}/${total}`);
  const all = new CashField(new THREE.Scene(), { random: seeded(9), avoid: () => true }); all.reset(0); assert(all.items.every((b) => b.g.visible && b.g.position.z < -CASH.FIRST_MIN + 1e-9), 'never left without a bundle');
});
t('spawned bundles keep clear of coins when a free spot exists', () => {
  const { scene, w } = newWorld(); const coins = scene.children.filter((c) => c.isMesh && c.geometry.type === 'CylinderGeometry'); assert.strictEqual(coins.length, 30);
  let overlaps = 0, total = 0;
  for (let k = 0; k < 200; k++) { // the 30 coins sit in the first ~270 m ahead of z=0: put layouts there and count bundles that land on a coin
    coins.forEach((c, i) => c.position.set([-4, 0, 4][i % 3], 1.1, -25 - i * 9)); w.resetCash(-k * 0.5);
    for (const g of bundles(w)) { total++; if (coins.some((c) => Math.abs(c.position.x - g.position.x) < 1.8 && Math.abs(c.position.z - g.position.z) < 4)) overlaps++; }
  }
  assert(total > 500); assert(overlaps / total < 0.02, `bundles on top of coins: ${overlaps}/${total}`);
});

// ---------------- look and animation
t('bundle model: notes box + paper band, both visible, printed naira symbol textures, shared lightweight geometry', () => {
  const { w } = newWorld(); const g = bundles(w)[0];
  assert.strictEqual(g.children.length, 2, 'notes + band'); const [body, band] = g.children;
  assert(body.geometry.type === 'BoxGeometry' && band.geometry.type === 'BoxGeometry');
  const bp = body.geometry.parameters, bd = band.geometry.parameters; assert(bp.width > 1.2 && bp.width < 2, 'bigger than a coin so it reads from a distance'); assert(bd.height > bp.height && bd.depth > bp.depth && bd.width < bp.width, 'band wraps around the notes');
  assert(Array.isArray(body.material) && body.material[4].map && body.material[5].map, 'naira symbol printed on both faces'); assert(band.material[4].map, 'band is printed too');
  const geos = new Set(bundles(w).flatMap((b) => b.children.map((c) => c.geometry))); assert.strictEqual(geos.size, 2, 'all bundles share two geometries');
  assert(w.cash.bodyGeo.attributes.position.count < 30, 'tiny geometry'); assert.strictEqual(w.cash.mats.length, 4);
});
t('animation: slow swaying turn (never edge-on) and gentle bobbing, bounded', () => {
  const f = new CashField(new THREE.Scene(), { random: seeded(1) }); const b = f.items[0].g; let minY = 9, maxY = -9, minR = 9, maxR = -9; const rots = new Set();
  for (let i = 0; i < 1000; i++) { f.update(0.016, 100, 0, i * 0.016, true); minY = Math.min(minY, b.position.y); maxY = Math.max(maxY, b.position.y); minR = Math.min(minR, b.rotation.y); maxR = Math.max(maxR, b.rotation.y); rots.add(b.rotation.y.toFixed(3)); }
  assert(rots.size > 100, 'rotating'); assert(minY >= CASH.Y - CASH.BOB - 1e-9 && maxY <= CASH.Y + CASH.BOB + 1e-9 && maxY - minY > CASH.BOB, 'bobs within a gentle range');
  assert(maxR - minR > 1.5, 'turns a good way each side'); assert(Math.max(Math.abs(minR), Math.abs(maxR)) < Math.PI / 2 - 0.3, 'never turns edge-on (90 deg) to the camera');
  assert(CASH.SWAY_SPEED <= 2 && CASH.BOB <= 0.2, 'gentle'); assert(Math.abs(b.rotation.x - CASH.TILT) < 1e-9, 'tilted slightly toward the camera');
});
t('works without a canvas (plain colours) and does not throw', () => {
  const saved = globalThis.document; globalThis.document = undefined; try { const f = new CashField(new THREE.Scene(), {}); assert(f.items.length === CASH.POOL); assert(!f.mats[1].map); } finally { globalThis.document = saved; }
});

// ---------------- performance / cleanup / restart
t('pooled: object count and GPU resources are constant however long you play', () => {
  const { scene, w } = newWorld(); const kids = scene.children.length; 
  w.setCashHandler(() => {});
  for (let z = 0, i = 0; z > -8000; z -= 0.5, i++) { const ahead = bundles(w).filter((g) => g.position.z <= z).sort((p, q) => q.position.z - p.position.z)[0]; w.update(0.016, ahead ? ahead.position.x : 0, z, i * 0.016, true); } // steer at the next bundle
  assert.strictEqual(scene.children.length, kids, 'no objects added while playing'); assert.strictEqual(w.cash.items.length, CASH.POOL);
  assert(w.cash.collected > 5, 'collected many bundles, still only ' + CASH.POOL + ' objects');
});
t('restart: reset clears the counter, re-lays every bundle ahead of the bus, no duplicates or leftovers', () => {
  const { scene, w } = newWorld(); const kids = scene.children.length;
  for (let z = 0; z > -800; z -= 0.5) { const ahead = bundles(w).filter((g) => g.position.z <= z).sort((a, b) => b.position.z - a.position.z)[0]; w.update(0.016, ahead ? ahead.position.x : 0, z, 0, true); } // steer at the next bundle
  assert(w.cash.collected > 2, 'collected a few: ' + w.cash.collected); const zBus = -800;
  w.resetCash(zBus); assert.strictEqual(w.cash.collected, 0); assert.strictEqual(w.cashGot, 0);
  const gs = bundles(w); assert.strictEqual(gs.length, CASH.POOL); assert.strictEqual(new Set(gs).size, CASH.POOL, 'no duplicate objects'); assert.strictEqual(scene.children.length, kids, 'scene size unchanged by restart');
  assert(gs.every((g) => g.visible && g.position.z < zBus - CASH.FIRST_MIN + 1e-9), 'all ahead of the bus, none on top of it');
  const zs = gs.map((g) => g.position.z).sort((a, b) => b - a); for (let i = 1; i < zs.length; i++) assert(zs[i - 1] - zs[i] >= CASH.GAP_MIN - 1e-9, 'no two bundles stacked in one place');
  for (let i = 0; i < 10; i++) w.resetCash(zBus); assert.strictEqual(scene.children.length, kids, 'repeated restarts never add objects');
  // after a restart a bundle is collectable exactly once again
  let paid = 0, hits = 0; w.setCashHandler(() => hits++); const target = gs.slice().sort((a, b) => b.position.z - a.position.z)[0];
  const tx = target.position.x, tz = target.position.z; // fixed spot: keep sitting where it was
  for (let i = 0; i < 300; i++) paid += (w.update(0.016, tx, tz, 0, true), w.cashGot);
  assert.strictEqual(paid, 500); assert.strictEqual(hits, 1);
});
t('dispose removes bundles from the scene and frees resources; double dispose is safe', () => {
  const scene = new THREE.Scene(); const before = scene.children.length; const f = new CashField(scene, {}); assert.strictEqual(scene.children.length, before + CASH.POOL);
  let disposed = 0; f.bodyGeo.addEventListener('dispose', () => disposed++); f.bandGeo.addEventListener('dispose', () => disposed++); f.mats.forEach((m) => m.addEventListener('dispose', () => disposed++));
  f.dispose(); assert.strictEqual(scene.children.length, before); assert.strictEqual(disposed, 6); f.dispose(); assert.strictEqual(disposed, 6); assert.strictEqual(f.update(0.016, 0, 0, 0, true), 0);
});

// ---------------- HUD
const hudIds = ['hud', 'touch', 'startScreen', 'pauseScreen', 'overScreen', 'flash', 'overDist', 'overCoins', 'overBest', 'score', 'overScore', 'overNew', 'speed', 'speedUnit', 'distance', 'coins', 'cash', 'overCash', 'trip', 'hint', 'banner', 'objective', 'pax', 'cap', 'fare'];
t('HUD: cash counter shows naira, updates, and only touches the DOM on change', () => {
  const hud = new Hud(); const el = byId.cash; assert(el, 'Hud looks up #cash');
  hud.updateCash(0); assert.strictEqual(el.textContent, '₦0'); hud.updateCash(500); assert.strictEqual(el.textContent, '₦500'); hud.updateCash(1500); assert.strictEqual(el.textContent, '₦1,500');
  let writes = 0; let v = el.textContent; Object.defineProperty(el, 'textContent', { get: () => v, set: (x) => { v = x; writes++; }, configurable: true });
  for (let i = 0; i < 100; i++) hud.updateCash(1500); assert.strictEqual(writes, 0, 'no DOM writes when unchanged'); hud.updateCash(2000); assert.strictEqual(writes, 1);
});
t('HUD: cash is separate from coins, score, distance, speed and fares', () => {
  const hud = new Hud(); hud.update(20, 1234, 7, 999, false); hud.updateCash(1500); hud.updateTrip('Lamenco', 9, 9, 1800);
  assert.strictEqual(byId.coins.textContent, 7); assert.strictEqual(byId.score.textContent, 999); assert.strictEqual(byId.cash.textContent, '₦1,500'); assert.strictEqual(byId.fare.textContent, '1,800');
  hud.update(20, 1300, 8, 1000, false); assert.strictEqual(byId.cash.textContent, '₦1,500', 'hud.update never touches cash'); hud.updateCash(2000); assert.strictEqual(byId.coins.textContent, 8); assert.strictEqual(byId.score.textContent, 1000); assert.strictEqual(byId.fare.textContent, '1,800');
});
t('HUD: pulse animates the cash tile; game-over screen lists cash', () => {
  const hud = new Hud(); hud.pulseCash(); assert(byId.cash.classes.has('pop')); hud.showGameOver(120, 4, 2500, 300, false, 1500); assert.strictEqual(byId.overCash.textContent, '₦1,500'); assert.strictEqual(byId.overCoins.textContent, 4); assert.strictEqual(byId.overScore.textContent, 120);
  hud.showGameOver(1, 2, 3, 4, false); assert.strictEqual(byId.overCash.textContent, '₦0', 'cash arg is optional');
});
t('index.html: cash tile, game-over line; every id the HUD uses exists', () => {
  const html = read('../index.html'); for (const id of hudIds) assert(new RegExp(`id="${id}"`).test(html), 'missing #' + id);
  assert(/class="stat cash"[^>]*>\s*<span id="cash">/.test(html)); assert(/<div class="stat coin"><span id="coins">/.test(html), 'coin tile intact'); assert(/id="score"/.test(html));
  const css = read('../css/style.css'); assert(/\.stat\.cash\{/.test(css) && /\.floater\.cash/.test(css)); assert(/#hud\{[^}]*pointer-events:none/.test(css), 'HUD still ignores touches');
  assert(html.indexOf('id="coins"') < html.indexOf('id="cash"') && html.indexOf('id="cash"') < html.indexOf('id="soundBtn"'), 'cash tile sits after coins, before the buttons');
});

// ---------------- effects (notification) and sound
t('notification: "+₦500 CASH" floater from its own pool, particles, never overwritten by coin floaters', () => {
  const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(); cam.position.set(0, 4, 10); cam.lookAt(0, 1, -9); cam.updateMatrixWorld();
  const fx = new Effects(scene, cam); const vis = () => fx.parts.filter((p) => p.m.visible).length;
  fx.cash(0, 1, 0, '+₦500 CASH'); const el = fx.cashFloaters[0]; assert.strictEqual(el.textContent, '+₦500 CASH'); assert(el.classes.has('go')); assert(el.className.includes('cash')); assert.strictEqual(vis(), 10);
  for (let i = 0; i < 20; i++) fx.coin(0, 1, 0, '+1 coin'); assert.strictEqual(el.textContent, '+₦500 CASH', 'coin popups do not overwrite the cash notice'); assert(fx.floaters.every((f) => f.textContent === '+1 coin' || f.textContent === ''));
  for (let i = 0; i < 40; i++) fx.cash(0, 1, 0, 'x'); assert(vis() <= 48, 'pool bounded');
  fx.cash(0, 1, 40, 'behind camera'); assert(fx.cashFloaters.some((f) => f.textContent === 'behind camera' && parseFloat(f.style.left) >= 0), 'off-screen pickup still gets a visible notice');
  fx.reset(); assert.strictEqual(vis(), 0); assert(fx.cashFloaters.every((f) => !f.classes.has('go')), 'restart clears notices');
});
t('sound: cash cue = 3 short tones via the existing Sound class; silent before unlock, throttled, cut by silence(), respects the saved mute choice', () => {
  const pre = new Sound(); started = 0; pre.cash(); assert.strictEqual(started, 0, 'silent before the first user gesture');
  const s = new Sound(); s.unlock(); started = 0; s.cash(); assert.strictEqual(started, 3, 'short three-tone cue'); s.cash(); assert.strictEqual(started, 3, 'double trigger throttled');
  s.silence(); assert.strictEqual(s.live.size, 0);
  s.setOn(false); started = 0; s.cash(); assert.strictEqual(started, 0, 'muted = silent'); assert.strictEqual(store.koroperun_sound, 'off');
  const muted = new Sound(); muted.unlock(); started = 0; muted.cash(); assert.strictEqual(started, 0, 'saved mute preference is honoured on a new session');
  s.setOn(true); s.lastCash = -1e9; started = 0; s.cash(); assert.strictEqual(started, 3, 'unmute restores it');
  const coinFirst = new Sound(); coinFirst.on = true; coinFirst.unlock(); started = 0; coinFirst.coin(); assert.strictEqual(started, 3, 'coin sound uses the same three-tone cash cue');
  globalThis.AudioContext = class { constructor() { throw new Error('no audio'); } }; const bad = new Sound(); bad.unlock(); bad.cash(); // broken audio never throws
});

// ---------------- nothing else changed
t('coins: one pickup per contact with the Chapter 6 traffic-following layout', () => {
  let seed = 12345; const realRandom = Math.random; Math.random = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  try {
    const scene = new THREE.Scene(); const w = createWorld(scene, { random: seeded(99), trafficRandom: () => 0.9 });
    w.magnetBox.onCollect = null; // Chapter 5: the purple magnet is switched off here so this stays a pure Chapter 3 coin run (magnet behaviour is tested in chapter5.test.mjs)
    const coins0 = scene.children.filter((c) => c.isMesh && c.geometry.type === 'CylinderGeometry'); coins0.forEach((c, i) => c.position.set([-4, 0, 4][i % 3], 1.1, -25 - i * 9)); seed = 12345; w.resetTraffic(0);
    let got = 0, calls = 0; w.setCoinHandler(() => calls++); const lanes = [-4, 0, 4, 0];
    for (let z = 0; z > -4000; z -= 0.5) { const g = w.update(0.016, lanes[Math.floor(-z / 300) % 4], z, 0, true); assert([0, 1, 2].includes(g), 'update() still returns the coin count'); got += g; }
    let h = 0; for (const c of coins0) h = (h * 31 + Math.round(c.position.x * 1000) + Math.round(c.position.z * 1000)) % 1000000007;
    assert.strictEqual(got, 122, 'coin pickup logic remains stable with Chapter 6 traffic following'); assert.strictEqual(calls, 122); assert.strictEqual(h, -898974216, 'coin layout is deterministic with Chapter 6 traffic following'); assert.strictEqual(coins0.length, 30);
  } finally { Math.random = realRandom; }
});
t('coins vs cash: collecting a bundle does not change the coin count, a coin does not change cash', () => {
  const { w } = newWorld(); const f = w.cash; f.items.forEach((b, i) => b.g.position.set(0, 1.15, -300 - i * 150));
  let coinPopups = 0; w.setCoinHandler(() => coinPopups++); let hits = 0; w.setCashHandler(() => hits++);
  const got = w.update(0.016, 0, -300, 0, true); assert.strictEqual(w.cashGot, 500); assert.strictEqual(hits, 1); assert.strictEqual(got, coinPopups, 'update() still returns coins only');
});
t('main.js wiring: cash is its own counter; score formula, coin reward and fares are untouched', () => {
  const main = read('../src/main.js');
  assert(main.includes('score = Math.floor(bus.distance / 10) + coins * COIN_POINTS;'), 'score formula unchanged');
  assert(/const COIN_POINTS = 25,/.test(main)); assert(main.includes("'+1 coin'") && main.includes('coins += got;') && main.includes('coins * COIN_POINTS'));
  const scoreLine = main.split('\n').find((l) => l.includes('score = Math.floor')); assert(!/cash/i.test(scoreLine), 'cash is not in the score');
  assert(!/journey\.[a-z]+\s*\+=\s*[^;]*cash|fare[^;\n]*cash|cash[^;\n]*fare/i.test(main.split('\n').filter((l) => !l.trimStart().startsWith('//') && !l.includes('Chapter 4')).join('\n').replace(/cash = 0; world\.resetCash[^\n]*/g, '')), 'cash never mixes with the fare');
  assert(main.includes('cash += world.cashGot;')); assert(main.includes('hud.update(bus.speed, bus.distance, coins, score, bus.dir < 0); hud.updateCash(cash);'));
  assert(main.includes('world.setCashHandler((x, y, z, amount) => { fx.cash(x, y, z,') && main.includes("' CASH'") && main.includes('hud.pulseCash(); sound.cash();'));
  assert.strictEqual((main.match(/setCashHandler\(/g) || []).length, 1, 'handler registered once (no double notifications)');
  assert(/function startTrip\(\)[^]*cash = 0; world\.resetCash\(bus\.z\); hud\.updateCash\(0\);[^]*\n\}/.test(main), 'PLAY and RESTART both reset cash through startTrip');
  assert(/restartBtn'\)\.addEventListener\('click'[^]*startTrip\(\); state = 'playing'/.test(main)); assert(/playBtn'\)\.addEventListener\('click'[^]*startTrip\(\)/.test(main));
  assert(main.includes('hud.showGameOver(score, coins, bus.distance, bestScore, isBest, cash)')); assert(main.includes('createWorld(scene, { cashReward: CASH_REWARD'));
  assert(main.includes('const level = Math.min(1, bus.distance / RAMP_M)') && main.includes('CRASH_CLOSING = 16') && main.includes('world.collide(bus.x, bus.z)'), 'progression and collision code intact');
  const cashSrc = read('../src/cash.js'); assert(!/journey|COIN_POINTS|bestScore|score/i.test(cashSrc.replace(/\/\/.*$/gm, '')), 'cash module knows nothing about score, fares or best score');
});
t('passenger fare is unchanged and independent of cash', () => {
  assert.strictEqual(FARE_PER_PASSENGER, 200); assert.strictEqual(DEFAULT_CAPACITY, 9);
  const j = new Journey(); for (let i = 0; i < 300; i++) j.update(1 / 60, 940, -4, 0); assert.strictEqual(j.passengers, 9); assert.strictEqual(j.fare, 1800);
  const { w } = newWorld(); w.resetCash(0); assert.strictEqual(j.fare, 1800, 'cash reset leaves the journey alone');
  assert(!/cash/i.test(read('../src/route.js').replace(/\/\/.*$/gm, '')), 'route.js untouched by cash');
});
t('other systems still wired: pause, mute key, traffic, crash, restart, controls, minimap, trip panel', () => {
  const main = read('../src/main.js');
  for (const s of ['setPaused(true)', "e.code === 'KeyM'", 'world.resetTraffic(bus.z)', 'sound.crash()', "state = 'over'", 'bus.restart()', 'controls.reset()', 'minimap.draw(d, bus.x, journey)', 'tripPanel.layout()', 'world.collide(bus.x, bus.z)', 'hud.celebrate(']) assert(main.includes(s), s);
  const w = read('../src/world.js'); for (const s of ['buildTraffic(scene)', 'collide(px, pz', 'setBoarded', 'setPickupClear', 'placeCoin']) assert(w.includes(s), s);
});

console.log('Chapter 4 tests passed:', n);
