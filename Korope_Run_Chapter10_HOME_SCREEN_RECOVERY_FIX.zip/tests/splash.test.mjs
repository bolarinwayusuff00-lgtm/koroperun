import assert from 'node:assert/strict';
import fs from 'node:fs';
const r = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
let n = 0; const ok = (name, fn) => { fn(); n++; console.log('  ok - ' + name); };

ok('splash assets are bundled locally', () => {
  for (const f of ['index.html', 'plate.webp', 'logo.webp', 'bus.webp']) assert.ok(fs.existsSync(new URL('../splash/' + f, import.meta.url)), f);
});
ok('index.html opens with the animated splash instead of the old welcome card', () => {
  const html = r('index.html');
  assert.match(html, /id="splashFrame"[^>]*src="splash\/index\.html"/);
  assert.doesNotMatch(html, /welcome-card/);
  assert.match(html, /id="loadingScreen"/);
});
ok('index has an independent splash-to-home handoff and missed-message recovery', () => {
  const html = r('index.html');
  assert.match(html, /window\.__koropeRevealHome\s*=\s*revealHome/);
  assert.match(html, /event\.data\.type === 'koperun-splash-done'/);
  assert.match(html, /setTimeout\(revealHome, 7500\)/);
  assert.match(html, /home\.classList\.remove\('hidden'\)/);
  assert.match(html, /loading\.classList\.add\('hidden'\)/);
});
ok('home.js hands over to the home screen only when the splash finishes (no fixed 6 s fake timer)', () => {
  const h = r('src/home.js');
  assert.match(h, /import \{ runSplash \} from '\.\/splash\.js'/);
  assert.match(h, /runSplash\(revealHome\)/); assert.match(h, /home\.classList\.remove\('hidden'\)/); assert.match(h, /loading\.classList\.add\('hidden'\)/);
  assert.doesNotMatch(h, /6000/); assert.match(h, /startDrive\(\)/); assert.match(h, /could not start gameplay/); assert.match(r('index.html'), /Drive across all your favourite streets/);
});
ok('splash.js is non-blocking and has a 7.5 second recovery failsafe', () => {
  const s = r('src/splash.js');
  assert.match(s, /koperun-splash-done/); assert.match(s, /koperun-splash-fast-start/); assert.match(s, /MAX_SPLASH_MS/);
  assert.match(s, /MAX_SPLASH_MS/); assert.match(s, /7500/); assert.doesNotMatch(s, /TASK_TIMEOUT_MS/); assert.doesNotMatch(s, /fetch\('assets\/coin-pickup\.wav'/);
  assert.match(s, /e\.origin !== location\.origin/);
});
ok('splash page registers only one completion message handler and one start hook', () => {
  const p = r('splash/index.html');
  assert.equal((p.match(/addEventListener\("message"/g) || []).length, 1);
  assert.equal((p.match(/addEventListener\("load"/g) || []).length, 1);
});
ok('splash page accepts progress, reports completion, and has portrait + low-power handling', () => {
  const p = r('splash/index.html');
  assert.match(p, /koperun-progress/); assert.match(p, /koperun-splash-done/); assert.match(p, /koperun-splash-started/); assert.match(p, /KL\.play\(\)/);
  assert.match(p, /START_PROGRESS=25/); assert.match(p, /DURATION_MS=6000/); assert.match(p, /performance\.now\(\)-KL\.t/); assert.match(p, /pctValue\+\"%\"/); assert.match(p, /max-aspect-ratio:1\/1/); assert.match(p, /pointer:coarse/);
  assert.match(p, /if\(playing\|\|loaded\)return/); assert.match(p, /const START_PROGRESS=25, DURATION_MS=6000/); assert.doesNotMatch(p, /this\.target=Math\.max/); assert.doesNotMatch(p, /setTimeout\(\(\)=>\{\s*KL\._cb/); assert.doesNotMatch(p, /data:image\/(png|jpeg)/); // images are separate cached files, not inlined
});
console.log('Splash tests passed: ' + n);
