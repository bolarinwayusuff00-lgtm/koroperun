// Chapter 3 tests: responsive minimap sizing, collapse/expand toggle, objective always visible, no overlap with controls.
import assert from 'node:assert';
import fs from 'node:fs';
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };

// ---- Fake DOM ----
const mkTarget = () => ({ on: {}, addEventListener(type, fn) { (this.on[type] ||= []).push(fn); }, fire(type, ev = {}) { (this.on[type] || []).forEach((f) => f({ preventDefault() {}, ...ev })); return ev; } });
const win = mkTarget(); globalThis.addEventListener = (ty, f) => win.addEventListener(ty, f);
const store = {}; let storageBroken = false;
globalThis.localStorage = { getItem: (k) => { if (storageBroken) throw new Error('blocked'); return k in store ? store[k] : null; }, setItem: (k, v) => { if (storageBroken) throw new Error('blocked'); store[k] = String(v); } };
globalThis.innerWidth = 360; globalThis.innerHeight = 640; globalThis.devicePixelRatio = 2;
const classes = () => { const set = new Set(); return { set, add: (c) => set.add(c), remove: (c) => set.delete(c), contains: (c) => set.has(c), toggle(c, on) { (on === undefined ? !set.has(c) : on) ? set.add(c) : set.delete(c); } }; };
const calls = [];
const ctx = new Proxy({}, { get: (o, k) => (k in o ? o[k] : (...a) => { calls.push([k, ...a]); }), set: (o, k, v) => { o[k] = v; return true; } });
const canvas = Object.assign(mkTarget(), { width: 0, height: 0, style: {}, getContext: () => ctx });
const hudBox = { bottom: 62, height: 62 }, padBox = { top: 550, height: 72 };
const els = {
  trip: Object.assign(mkTarget(), { style: {}, classList: classes() }),
  mapToggle: Object.assign(mkTarget(), { classList: classes(), attrs: {}, textContent: '', offsetHeight: 32, setAttribute(k, v) { this.attrs[k] = v; } }),
  tripStats: { offsetHeight: 58 },
  hud: { getBoundingClientRect: () => ({ ...hudBox }) },
  minimap: canvas,
};
const pad = { getBoundingClientRect: () => ({ ...padBox }) };
globalThis.document = { getElementById: (id) => els[id] || null, querySelector: (q) => (q === '#touch .pad' ? pad : null), createElement: () => ({ style: {}, classList: { add() {}, remove() {} }, getContext: () => ctx }), body: { appendChild() {} } };
let roCallback = null, roTarget = null;
globalThis.ResizeObserver = class { constructor(cb) { roCallback = cb; } observe(el) { roTarget = el; } };

const { mapLayout, MIN_MAP_H, PANEL_GAP, Minimap, mapY } = await import('../src/minimap.js');
const { TripPanel } = await import('../src/trippanel.js');
const { ROUTE, Journey, AGUNBELEWO_D, LAMENCO_D } = await import('../src/route.js');

// ---- Pure sizing logic ----
const VIEWPORTS = [[360, 640], [390, 844], [412, 915], [320, 568], [375, 667], [844, 390], [667, 375], [740, 360], [800, 360], [568, 320], [640, 300], [768, 1024], [1024, 768], [1280, 800], [1920, 1080]];
t('phones are "compact" in portrait AND landscape; tablets/desktop are not', () => {
  for (const [W, H] of [[360, 640], [390, 844], [844, 390], [568, 320]]) assert(mapLayout({ W, H, top: 70, bottom: 500, headerH: 90 }).compact, `${W}x${H}`);
  for (const [W, H] of [[768, 1024], [1024, 768], [1280, 800]]) assert(!mapLayout({ W, H, top: 70, bottom: 700, headerH: 90 }).compact, `${W}x${H}`);
});
t('portrait phone map is small (<= 140 px tall, 88 px wide); landscape phone map <= 120 px', () => {
  const p = mapLayout({ W: 360, H: 640, top: 70, bottom: 540, headerH: 90 }), l = mapLayout({ W: 800, H: 360, top: 70, bottom: 270, headerH: 90 });
  assert.strictEqual(p.w, 88); assert(p.mapH <= 140 && p.mapH >= MIN_MAP_H); assert(l.mapH <= 120 && l.mapH >= MIN_MAP_H);
});
t('desktop keeps the original roomy size rule (96 px wide, 120..200 tall from window height)', () => {
  for (const H of [700, 800, 1080]) { const L = mapLayout({ W: 1280, H, top: 70, bottom: H - 12, headerH: 90 }); assert.strictEqual(L.w, 96); assert.strictEqual(L.cap, Math.round(Math.min(200, Math.max(120, H * 0.32)))); assert(L.mapH <= 200); }
});
t('panel (header + border + map) always fits inside the free band, for every viewport and many HUD / button-row heights', () => {
  for (const [W, H] of VIEWPORTS) for (const hudBottom of [50, 62, 104, 116]) for (const rowTop of [H - 160, H - 100, H - 12]) {
    const top = hudBottom + PANEL_GAP, bottom = rowTop - PANEL_GAP, headerH = 90, L = mapLayout({ W, H, top, bottom, headerH });
    assert(L.mapH >= 0 && Number.isFinite(L.mapH));
    if (L.canExpand) assert(top + headerH + 4 + L.mapH <= bottom, `${W}x${H} hud ${hudBottom} row ${rowTop}: ${top + headerH + 4 + L.mapH} > ${bottom}`);
    else assert.strictEqual(L.mapH, 0);
  }
});
t('not enough room => map cannot expand (header only); more room never gives a smaller map', () => {
  assert.strictEqual(mapLayout({ W: 360, H: 640, top: 100, bottom: 200, headerH: 90 }).canExpand, false);
  let prev = 0; for (let room = 0; room < 400; room += 10) { const L = mapLayout({ W: 360, H: 640, top: 100, bottom: 100 + 94 + room, headerH: 90 }); assert(L.mapH >= prev); prev = L.mapH; }
});
t('at the smallest map the three stops are still clearly separated', () => {
  const h = MIN_MAP_H; assert(mapY(0, h) - mapY(LAMENCO_D, h) >= 18); assert(mapY(LAMENCO_D, h) - mapY(AGUNBELEWO_D, h) >= 18);
});

// ---- TripPanel behaviour ----
const mm = new Minimap(canvas);
let panel = new TripPanel(mm);
const click = () => els.mapToggle.fire('click');
t('before the game starts (HUD hidden) layout does nothing', () => { hudBox.height = 0; assert.strictEqual(panel.layout(), null); hudBox.height = 62; });
t('layout measures the HUD and button row: panel starts below the HUD, canvas is sized, default is expanded', () => {
  const L = panel.layout();
  assert.strictEqual(els.trip.style.top, (62 + PANEL_GAP) + 'px'); assert.strictEqual(els.trip.style.width, '88px'); assert(els.trip.classList.contains('compact'));
  assert(!els.trip.classList.contains('collapsed')); assert.strictEqual(mm.visible, true); assert.strictEqual(mm.h, L.mapH); assert.strictEqual(canvas.style.height, L.mapH + 'px'); assert.strictEqual(els.mapToggle.attrs['aria-expanded'], 'true');
  assert(/HIDE MAP/.test(els.mapToggle.textContent));
  assert(62 + PANEL_GAP + 32 + 58 + 4 + mm.h <= 550 - PANEL_GAP, 'bottom of panel is above the button row');
});
t('tapping the toggle collapses the map: map hidden, state saved, label and aria update', () => {
  click(); assert(els.trip.classList.contains('collapsed')); assert.strictEqual(mm.visible, false); assert.strictEqual(els.mapToggle.attrs['aria-expanded'], 'false'); assert(/SHOW MAP/.test(els.mapToggle.textContent)); assert.strictEqual(els.mapToggle.attrs['aria-label'], 'Show map'); assert.strictEqual(store.koroperun_map_open, '0');
});
t('while collapsed the minimap does no drawing', () => { calls.length = 0; mm.draw(500, 0, new Journey()); assert.strictEqual(calls.length, 0); });
t('tapping again expands: map visible and redrawn with route, stops and player', () => {
  click(); assert(!els.trip.classList.contains('collapsed')); assert.strictEqual(mm.visible, true); assert.strictEqual(store.koroperun_map_open, '1');
  calls.length = 0; mm.draw(500, 0, new Journey());
  const text = calls.filter((c) => c[0] === 'fillText').map((c) => c[1]);
  for (const stop of ROUTE.stops) assert(text.includes(stop.name), stop.name + ' label drawn');
  assert(calls.some((c) => c[0] === 'stroke'), 'route line'); assert(calls.some((c) => c[0] === 'closePath'), 'player marker'); assert(calls.some((c) => c[0] === 'arc'), 'stop dots');
  assert(calls.filter((c) => c[0] === 'fillRect').length >= 2, 'pickup bay rectangle');
});
t('the map still draws at the smallest allowed size and at desktop size', () => {
  for (const [w, h] of [[88, MIN_MAP_H], [88, 140], [96, 200]]) { mm.setSize(w, h); calls.length = 0; mm.draw(1200, 1, new Journey()); assert(calls.some((c) => c[0] === 'fillText')); }
  mm.setSize(88, panel.last.mapH);
});
t('the choice is remembered: a new panel starts collapsed if it was collapsed last time', () => {
  click(); assert.strictEqual(store.koroperun_map_open, '0'); const p2 = new TripPanel(mm); assert.strictEqual(p2.expanded, false); p2.layout(); assert(els.trip.classList.contains('collapsed')); p2.setExpanded(true); assert(!els.trip.classList.contains('collapsed'));
  panel = p2;
});
t('blocked storage (private mode) does not break the toggle', () => { storageBroken = true; const p3 = new TripPanel(mm); assert.strictEqual(p3.expanded, true); assert.doesNotThrow(() => p3.setExpanded(false)); assert.doesNotThrow(() => p3.setExpanded(true)); storageBroken = false; panel = p3; });
t('rotating the phone re-lays out the panel (portrait -> landscape -> portrait)', () => {
  panel.setExpanded(true);
  innerWidth = 800; innerHeight = 360; hudBox.bottom = 62; hudBox.height = 62; padBox.top = 360 - 18 - 65; padBox.height = 65; win.fire('resize');
  assert(panel.last.portrait === false && panel.last.compact); assert(mm.h <= 120); assert(62 + PANEL_GAP + 90 + 4 + mm.h <= padBox.top - PANEL_GAP, 'landscape: still above the buttons');
  innerWidth = 360; innerHeight = 640; padBox.top = 550; padBox.height = 72; win.fire('resize'); assert(panel.last.portrait && mm.h <= 140);
});
t('if the HUD wraps to two rows (ResizeObserver) the panel moves down and the map shrinks to stay above the buttons', () => {
  assert.strictEqual(roTarget, els.hud); const before = mm.h; hudBox.bottom = 116; hudBox.height = 116; roCallback();
  assert.strictEqual(els.trip.style.top, (116 + PANEL_GAP) + 'px'); assert(116 + PANEL_GAP + 90 + 4 + mm.h <= 550 - PANEL_GAP); assert(mm.h <= before); hudBox.bottom = 62; hudBox.height = 62; roCallback();
});
t('a very short window: no room for a map => toggle hidden, header (objective) still there, never overlapping', () => {
  innerWidth = 640; innerHeight = 300; hudBox.bottom = 62; padBox.top = 226; padBox.height = 54; win.fire('resize');
  assert.strictEqual(panel.last.canExpand, false); assert(els.trip.classList.contains('collapsed')); assert(els.mapToggle.classList.contains('hidden')); assert.strictEqual(mm.visible, false);
  innerWidth = 360; innerHeight = 640; padBox.top = 550; padBox.height = 72; win.fire('resize'); assert(!els.mapToggle.classList.contains('hidden')); assert(panel.mapVisible);
});
t('desktop (no touch buttons: pad has no size) uses the bottom of the window', () => {
  innerWidth = 1280; innerHeight = 800; padBox.height = 0; win.fire('resize'); assert(!panel.last.compact); assert.strictEqual(els.trip.style.width, '96px'); assert(mm.h >= 120 && mm.h <= 200); assert(62 + PANEL_GAP + 90 + 4 + mm.h <= 800 - 12);
  innerWidth = 360; innerHeight = 640; padBox.top = 550; padBox.height = 72; win.fire('resize');
});

// ---- Markup / CSS / wiring ----
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../css/style.css', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
t('objective, passengers and fare live in the always-visible header, not inside the hideable map', () => {
  const trip = html.match(/<div id="trip"[\s\S]*?<canvas id="minimap"[^>]*><\/canvas>\s*<\/div>/)[0];
  assert(trip.indexOf('id="mapToggle"') < trip.indexOf('id="objective"') && trip.indexOf('id="objective"') < trip.indexOf('<canvas'));
  for (const id of ['objective', 'pax', 'cap', 'fare']) assert(trip.includes(`id="${id}"`), id);
  assert(/#trip\.collapsed canvas\{display:none\}/.test(css)); assert(!/#trip\.collapsed[^{]*(tripstats|objective|\.row)/.test(css), 'collapsing never hides the objective');
});
t('toggle is a real button with a >= 32 px tap target; only it takes touches; panel is not centred over the road any more', () => {
  assert(/<button id="mapToggle" type="button"/.test(html)); const r = css.match(/#mapToggle\{[^}]*\}/)[0]; assert(/pointer-events:auto/.test(r)); assert(/height:32px/.test(r)); assert(/width:100%/.test(r)); assert(/touch-action:none/.test(r));
  assert(/#trip\{[^}]*pointer-events:none/.test(css)); assert(!/#trip\{[^}]*translateY\(-50%\)/.test(css));
});
t('panel sits on the right while the steering zone and pedals sit along the bottom (panel <= 96 px wide)', () => {
  assert(/#trip\{[^}]*right:max\(10px/.test(css)); assert(/#touch \.steer-zone\{[^}]*pointer-events:auto/.test(css)); assert(/#touch \.pad\{[^}]*pointer-events:auto/.test(css)); assert(!css.includes('#steerZone{'));
  for (const W of [320, 360, 390, 412, 568, 800]) assert(W - 10 - 96 >= W / 2, `${W}: panel left edge is right of the steering area`);
});
t('main.js: panel created once, laid out when the game starts; trip/minimap calls unchanged', () => {
  assert(/tripPanel = new TripPanel\(minimap\)/.test(main)); assert(/hud\.showGame\(\); tripPanel\.layout\(\);/.test(main)); assert(/minimap\.draw\(d, bus\.x, journey\)/.test(main)); assert(/hud\.updateTrip\(journey\.objective\(d\)/.test(main));
});
t('route data and journey numbers untouched', () => { assert.strictEqual(ROUTE.length, 2600); assert.strictEqual(LAMENCO_D, 1000); assert.deepStrictEqual(ROUTE.stops.map((s) => s.name), ['Oke-Fia', 'Lamenco', 'Agunbelewo']); });

console.log(`Chapter 3 tests passed: ${n}`);
