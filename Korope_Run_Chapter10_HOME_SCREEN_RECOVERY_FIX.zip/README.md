# Korope Run — Osogbo City (Browser Prototype 01)

A small 3D driving game: steer a bright-blue Osogbo-style korope with a narrow yellow stripe and dark bumpers down a street lined with shops, trees and utility poles, collecting coins.

## Run it
Browsers block ES modules opened from `file://`, so serve the folder:
```
cd Korope_Run_Browser_Prototype_01
python3 -m http.server 8000      # or: npx serve
```
Open http://localhost:8000. For a phone, open `http://<your-computer-IP>:8000` on the same Wi-Fi.
Three.js (MIT licence) is included in `vendor/`, so no internet is needed.

## Controls
| Action | Keyboard | Touch |
|---|---|---|
| Accelerate | W / ↑ | GAS |
| Brake | S / ↓ | BRAKE |
| Reverse | R | REVERSE |
| Steer | A D / ← → (held) | Drag your thumb left/right in the large steering area (left side) |
| Jump | Space | JUMP button |
| Pause | P, Esc or ❚❚ | ❚❚ |

## Files
- `index.html` – page, HUD, start/pause screens, import map
- `css/style.css` – responsive styling
- `src/main.js` – renderer, game state, chase camera, main loop
- `src/world.js` – road, shops, trees, poles, lighting, coins (world recycles forever)
- `src/vehicle.js` – procedural korope model and driving physics
- `src/controls.js` – keyboard, drag-to-steer zone, GAS / BRAKE / REVERSE and JUMP
- `src/trippanel.js` – trip panel: map toggle, measuring and placing the panel (Chapter 3)
- `src/hud.js` – speed / distance / coins / cash display
- `src/cash.js` – naira cash bundles: reward setting, model, spawning, pickup (Chapter 4)

## Easy things to tweak
- Top speed, acceleration, braking: `src/vehicle.js` (`MAX`, `update`)
- Shop names and colours: `SHOPS`, `PAINTS` in `src/world.js`
- Sky / sun warmth: `createWorld` in `src/world.js`

## Milestone 2
- Road edges: soft rumble zone from |x| 4.1, firm limit at 4.75 (`ROAD` in `world.js`), slowdown + gentle bounce, camera shake.
- Traffic: 6 reusable same-direction slots; Chapter 6 adds occasional motorcycles and bicycle riders alongside the most-common cars (`buildTraffic` in `world.js`).
- Collisions: side swipes scrub speed; head-on/rear-end at closing speed > 16 m/s (`CRASH_CLOSING` in `main.js`) ends the run.
- Game over screen with distance, coins, best distance (saved in localStorage) and RESTART.

- Score: 1 pt per 10 m + 25 per coin (HUD, best score saved as `koroperun_best_score`).
- Progression: top speed 32→40 m/s and traffic gaps shrink slightly over the first 5 km, then capped.

## Not yet included
Passenger missions, garages, upgrades, sound, Android packaging.

## Milestone 4 — Game feel & polish
- `src/effects.js` (new): pooled sparks/debris (48 meshes, built once) and 4 reusable "+25" floaters. No assets, no libraries.
- Coin pickup: gold sparkle burst, floating "+25", HUD coin counter pop. Coins are moved away the moment they are collected (no double pickup) and are ignored once the run is over.
- Impact: bumps give a light flash, shake and sparks once per contact (previously re-fired every frame during a side swipe). A fatal crash fires one stronger flash, capped camera shake, FOV punch and debris burst, then the Crash screen fades in after ~0.5 s.
- Steering: camera looks slightly into turns and leans up to ~3°. Controls, physics, scoring, boundaries are unchanged.
- Shake is reduced when the OS "reduce motion" setting is on.

## Milestone 5 — Audio + coin counting
- Coins vs score: one pickup = **+1 coin** (HUD counter and "+1 coin" popup) and +25 **score points** (shown only in the score). They are separate counters.
- `src/audio.js`: Web Audio effects for impacts, crash, engine and fallback pickup cues. Coin/cash pickup uses the locally bundled original sound in `assets/coin-pickup.wav` when HTML audio is available.
- Audio starts only after the PLAY/RESTART/sound-button click (autoplay rules). Failures are swallowed so the game still runs silently.
- Sound button (HUD, next to pause) or **M** key toggles sound; the choice is saved (`koroperun_sound`). Restart and mute cut any sound still playing.
- Run tests: `node tests/m5.test.mjs` needs a `three` package resolvable (e.g. `node_modules/three` containing `vendor/three.module.js`).

## Milestone 6A — Route foundation and passenger pickup
**Run:** serve the folder (`python3 -m http.server 8000`) and open http://localhost:8000. Tests: `npm test` (Node 18+; uses the bundled `vendor/three.module.js`, no install needed).

**Route:** Oke-Fia (start) → Lamenco (1,000 m) → Agunbelewo (2,600 m). The street is still one straight road driven toward −Z, so the route is that same road: landmarks are placed at route distance `d = routeOriginZ − bus.z`, where the origin is reset on PLAY/RESTART. Distances live in `src/route.js` (`LAMENCO_D`, `AGUNBELEWO_D`).

**Lamenco:** a hatched junction box with zebra crossing, stop line, two traffic lights (decorative: always green, they do not control traffic) and a "LAMENCO JUNCTION" gantry. The green **pickup bay** is on the LEFT edge of the road 45–75 m *before* the junction, with a "TERMINAL" road marking, a "TERMINAL" sign, a shelter and 12 waiting passengers on the pavement. Lamenco remains the map/junction name.

**Boarding rules:** be inside the bay (left side, route distance 925–955 m) at ≤ 1 m/s (`PICKUP_MAX_SPEED`) and stay that way for 0.6 s (`BOARD_HOLD`); a progress bar shows this. Driving through at speed never boards; if you leave the bay the progress restarts. Boarding happens once per trip. Capacity defaults to 9 (`DEFAULT_CAPACITY`, configurable via `new Journey({ capacity })`); 12 people wait, so 3 are left behind. If you pass the bay without stopping the pickup is marked missed (0 passengers) and the trip continues.

**Fare:** `FARE_PER_PASSENGER = 200` (₦). Passengers and fare live in the `Journey` object and are shown in the panel under the minimap. They are separate from coins, score and best score (the score formula and coin code are unchanged).

**Minimap:** a small strip at the right-hand side (clear of the touch buttons): route line (driven part in yellow), Oke-Fia, Lamenco (with bay mark), Agunbelewo and a live arrow for the korope. Because the street is straight, the route map is a straight line. Under it: next objective, passengers and fare.

**Feedback:** hints ("Lamenco pickup ahead", "Slow right down and stop to board", boarding bar), a "9 passengers boarded! +₦1,800 fare" banner, a +₦ floater, a short jingle (`Sound.board`, respects mute) and passengers walk to the korope entrance before disappearing from the pavement.

**Journey state:** `journey.stage` is `toLamenco` → `toAgunbelewo` → `arrived`, plus `reachedLamenco` and `pickup` (`pending`/`done`/`missed`). Reaching Agunbelewo only shows a banner; the trip-complete screen is Part B. Driving continues past Agunbelewo.

**Other changes:** `src/route.js`, `src/minimap.js` (new); `world.js` (landmarks, traffic kept out of the lane right behind the bus while approaching the bay), `main.js`, `hud.js`, `audio.js`, `index.html`, `css/style.css` (additions only); `tests/m6a.test.mjs`, `tests/register.mjs`, `package.json`.

## Chapter 1 — Virtual steering wheel (updated)
- Removed the LEFT, MIDDLE, RIGHT, and JUMP touch buttons. Mobile steering is now a circular virtual wheel with a rim, spokes, and centre hub. The user turns the wheel left/right; steering is proportional to wheel angle and the wheel smoothly self-centres on release.
- Pointer movement is handled only by the wheel element. There is no full-screen drag/swipe steering zone. GAS, BRAKE, REVERSE, pause, mute, and desktop A/D + arrow steering remain. Space still triggers the short jump on a physical keyboard; no on-screen Jump button remains.
- Tests: `npm test` includes wheel angle/clamping, self-centering, pedal controls, keyboard steering and absence of lane/jump buttons. Not tested on a physical phone.

## Chapter 2 — Mobile driving controls
- The bottom-right pedal group contains **REVERSE**, **BRAKE**, and **GAS**. The bottom-left group contains the circular virtual steering wheel.
- **GAS** accelerates with the original physics; letting go just coasts (rolling drag) to a stop. **BRAKE** slows and stops the bus; releasing it does nothing else. BRAKE never reverses.
- **REVERSE** is its own control (keyboard: **R**). The bus keeps one direction (`bus.dir`, +1 forward / -1 reverse) and may only change it when speed is <= 0.5 m/s (`SHIFT_SPEED`). Holding the opposite pedal while rolling just brakes (like BRAKE) and switches over once stopped, only if that pedal is still held. GAS + REVERSE together do nothing.
- Reverse is slow (levels off ~19 km/h, `REV_MAX`) and limited to 40 m behind your furthest point (`REVERSE_LIMIT`; the road is only built about 60 m behind). Reversing never adds distance/score. A bump while reversing is a bump, never a fatal crash. The speed readout shows `km/h · R` in reverse.
- Every button is held only while its own finger is down. Release, cancel, lost capture, a finger lifted elsewhere, window blur, pause, crash and restart all clear it. A second finger cannot steal or release a held button.
- Button size follows both width and height so the row stays below the minimap in landscape (checked down to 320 px tall; a 300 px-tall window would overlap).
- Tests: `npm test` runs everything, including `tests/chapter2.test.mjs`. Not yet tried on a real phone.

## Chapter 3 — Responsive minimap
- The trip panel now sits at the top-right, **below the HUD row (pause / mute) and above the GAS/BRAKE/REVERSE row**, instead of floating in the middle of the screen. The circular steering wheel occupies the lower-left area, separate from the right-side trip panel and the pedal group.
- Its size is worked out from the real HUD and button positions (`mapLayout` in `src/minimap.js`): phones get a compact 88 px-wide map (max 140 px tall in portrait, 120 px in landscape); tablets/desktop keep the roomy 96 px x 120-200 px map. If the HUD wraps to two rows, or the phone rotates, the panel re-fits.
- **▲ HIDE MAP / ▼ SHOW MAP** button (32 px tall, full panel width). Only the map hides: the **objective** (e.g. "Lamenco 800 m") and the **passengers / fare** stay visible. The choice is remembered (`koroperun_map_open`).
- If a screen is too short to fit a useful map (< 80 px), the map stays hidden and the toggle disappears; the objective is still shown.
- Route line, player marker, Oke-Fia / Lamenco / Agunbelewo labels and the pickup bay are unchanged (labels use a slightly tighter layout at the compact width). Route distances, passengers, fares, score and physics are untouched.
- Tests: `npm test` (adds `tests/chapter3.test.mjs`). Not yet tried on a real phone.

## Chapter 4 — Naira cash pickups
Collectible bundles of naira notes are mixed in among the coins. Tests: `npm test` (adds `tests/chapter4.test.mjs`, 32 checks; no install needed).

**What they are:** an upright brick of green notes (about 1.5 × 0.95 m, a little bigger than a coin so it reads from a distance) with a ₦ printed on each face and a cream paper band that also carries a ₦. The bundle bobs gently and sways ±57° around facing the camera, so the ₦ is never edge-on. Each one is two meshes sharing two box geometries and four materials (two small canvas textures, built once); three bundles exist in total and are reused forever (no allocation while playing, no new dependencies or asset files).

**Spawning:** bundles are placed 110–200 m apart (about one per 150 m, versus a coin every ~9 m), first one 80–130 m ahead. They use five x slots – the three lanes and the two gaps between them (`-4, -2, 0, 2, 4`) – all inside the soft edge of the road, never the same slot twice in a row. A spot next to a coin, or where a car will be when the bus arrives, is skipped (best effort; if every try is blocked the bundle still spawns). The pickup box is 1.5 m sideways × 2.4 m along the road, a little more forgiving than a coin, and cannot be skipped at top speed.

**Reward:** `CASH_REWARD = 500` (₦) in `src/cash.js`. Change it there, or pass `createWorld(scene, { cashReward: 1000 })`, or call `world.setCashReward(n)` at run time. Invalid values (0, negative, NaN) are ignored.

**On pickup:** a green "+₦500 CASH" notice floats up from the bundle (its own pool, so a run of coin popups can't overwrite it), green/gold sparkles, the HUD cash tile pops, and a short three-tone "ka-ching" plays through the existing `Sound` class (`sound.cash()`): it respects the mute button / **M** key and the saved `koroperun_sound` choice, is silent until the first click, and is cut by restart/mute.

**HUD:** a green **₦ cash** tile after the coins tile. Cash is its own counter: it is *not* added to coins, score, best score or passenger fares, and the game-over screen lists it. It is not saved between runs. On narrow phones the HUD row may wrap to two lines (Chapter 3's trip panel already moves down to follow it).

**Exactly once / restart:** a collected bundle is moved 110+ m ahead in the same frame, so it can never pay twice, even if you stop on it; nothing is collected before PLAY, after a crash or while paused. PLAY and RESTART call `world.resetCash(bus.z)`, which zeroes the counter and re-lays all three bundles ahead of the bus, so nothing is left over or duplicated. `CashField.dispose()` removes the bundles and frees their GPU resources.

**Unchanged:** coin reward (+1 coin, +25 score), score formula (`distance/10 + coins × 25`), passenger fares (₦200 × passengers), traffic, collisions, pause, crash, restart, touch/keyboard controls, minimap and trip panel. `tests/chapter4.test.mjs` includes a golden run proving the coin logic produces the same result as Chapter 3.


## Chapter 5 — Purple magnet power-up
A rare purple box with a magnet on it. Collect it and, for a few seconds, nearby coins and naira cash bundles fly to the korope. Tests: `npm test` (adds `tests/chapter5.test.mjs`, 30 checks; no install needed).

**The box:** a 1.3 m purple cube with a blocky red-and-silver horseshoe magnet printed on its four sides *and* a real 3D horseshoe magnet (bend, two legs, silver tips) standing on top, so the symbol shows from every angle and from far away. It bobs and spins slowly. One box exists in total (built once, reused forever; shared geometry/materials, one small canvas texture; no new assets or dependencies).

**Rarity:** one box per 400–700 m (`MAGNET.GAP_MIN/GAP_MAX` in `src/magnet.js`), first one 250–400 m ahead. Cash bundles come every 110–200 m and coins about every 9 m, so the magnet is the rarest pickup. It sits in the same five reachable x slots as cash (never the same slot twice in a row) and avoids spots next to coins, cash or where a car will be.

**Duration:** `MAGNET_DURATION = 8` seconds in `src/magnet.js`. Change it there, or pass `createWorld(scene, { magnetDuration: 12 })`, or call `world.setMagnetDuration(n)`. Invalid values (0, negative, NaN) are ignored. Other numbers (`RANGE` 16 m, `PULL_MIN/PULL_MAX`, per-frame cap) are in `MAGNET`.

**What is attracted:** only coins and cash bundles within 16 m of the korope (front, sides and a little behind). They glide towards it: the pull speed grows from 14 to 50 m/s as they get close, each frame's step is capped at 2.5 m (even on a 50 ms frame) and can never overshoot, so nothing teleports. Traffic, passengers, signs, the road and scenery are never touched (a test compares the whole scene with the magnet on and off). Pickup itself is unchanged: when a pulled item reaches the normal pickup box it is collected through the existing coin/cash code, which moves it far ahead in the same frame, so it can never be collected twice. Values are unchanged (coin +1 and +25 score, bundle ₦500); the magnet adds nothing to coins, cash, score or fares.

**HUD and effects:** a purple **MAGNET 8s** tile counts down in whole seconds, below the HUD row on the left (outside the HUD row, so the minimap/trip panel never has to move). It flickers in the last 2 seconds (still readable with reduced-motion) and hides when the magnet ends. While active, a soft purple glow disc sits under the korope and a ring pulses outward to show the pull range (two flat transparent meshes built once, no lights, no per-frame allocation; flickers in the last 2 s). Pickup also gives purple sparkles, a "MAGNET 8s" notice (its own element) and a short rising sound (`sound.magnet()`, respects mute, silent before the first click, cut by restart).

**Timer rules**
- *Collect another box while active:* the timer is **refreshed to the full duration** (never added: 5 s left + box = 8 s, not 13 s). It ends only once.
- *Pause* (button, P key, tab hidden): the whole simulation is skipped, so the countdown, pull and glow freeze and resume from the same value.
- *Crash:* the magnet ends at once (`world.clearMagnet()`): HUD tile and glow disappear, nothing is pulled on the game-over screen.
- *PLAY / RESTART:* `startTrip()` calls `world.resetMagnet(bus.z)`: magnet off, HUD and glow cleared, a fresh box laid ahead. No leftover effects.
- *Expiry:* attraction stops, the glow and HUD tile are hidden; pickups that were already pulled simply stay where they are and can still be collected normally.
- Menu / game over (`collect=false`): the timer does not run.

**Changes:** new `src/magnet.js`, `tests/chapter5.test.mjs`; additions to `src/world.js`, `src/effects.js`, `src/hud.js`, `src/audio.js`, `src/main.js`, `index.html`, `css/style.css`, `package.json`. Two Chapter 4 test edits (see below). Controls, vehicle, route, minimap, trip panel, score/fare logic are untouched.

**Chapter 4 test edits:** the golden coin run drives 4 km and would now meet magnet boxes (which correctly pull extra coins), so it switches the magnet off (`w.magnetBox.onCollect = null`) to stay a pure Chapter 3 coin check; and the `main.js` source check accepts the extra `magnetDuration` option in the `createWorld(...)` call.

Not yet tried on a real phone or in a real browser (headless tests only).

## Chapter 5.5 — Welcome, home, profile, settings and Garage
- First load shows a blue KOROPERUN welcome screen with a compact progress bar and Osogbo location ticker, then opens the home screen. Tapping **TAP TO DRIVE** now starts the driving game directly; there is no extra PLAY splash screen.
- The home screen includes a persistent nickname (`koroperun_nickname`), total coin wallet (`koroperun_coin_wallet`), Settings, Markets (honestly labelled Coming Soon), Garage, and a lightweight illustrated preview. The preview is a menu illustration, not a second Three.js simulation.
- Coins earned by actual coin pickups add +1 to the persistent wallet. Wallet coins are separate from run score, best score, naira cash and passenger fares. The home screen has **Leaderboard** tabs for Today, This week and This month; completed crash-ending runs are stored locally under `koroperun_local_runs`. This is a device-local leaderboard, not a shared online ranking, and browser storage is editable by the player.
- Garage purchases cost 50/100/200 coins, save unlocked item IDs in `koroperun_garage_unlocked`, and save the equipped item ID in `koroperun_garage_equipped`. The selected slogan is attached to the actual vehicle group and follows the vehicle. One equipped side decal is supported at a time. The permanent rear inscription reads **OSOGBO TO THE WORLD** and is never a purchase.
- Settings store Game Sound at `koroperun_game_sound` and Music at `koroperun_music`. No music file is bundled; the Music preference is saved but cannot play music until a licensed local track is supplied. Existing master mute remains available.
- The home screen no longer opens a tutorial. The first time the player presses the on-screen **GAS** button during a drive, a short driving tip appears; its one-time flag is `koroperun_gas_tip_seen`.
- Coin pickup still uses the project's existing Web Audio synthesized cue. A properly licensed recorded metallic coin sound was not included in this update because a recording and verifiable licence were not available in the supplied project. Replace this cue with a locally bundled licensed recording in a future audio-assets pass; no third-party audio was added.
- The pause screen shows the persistent coin wallet and current-run naira cash balance, with icon buttons for HOME, RESUME and SOUND ON/OFF, plus a prominent CONTINUE button. HOME returns to the home screen; RESUME and CONTINUE return to the same run.
- Test: `npm test` (all existing Chapter 1–5 / Milestone tests). Also check the home flow, leaderboard period filters, wallet purchases, first-GAS tip, pause actions and the rear inscription in a modern browser served over HTTP.


## Chapter 6 — Osogbo Terminal and mixed traffic

**Route names stay distinct:** Oke-Fia is the starting location (`d = 0`), Lamenco is the junction along the route (`d = 1,000 m`), and Agunbelewo is the destination (`d = 2,600 m`). These names remain in the route data and minimap. The passenger waiting bay is now signed **TERMINAL**; it is the Terminal at Lamenco, not a replacement for Lamenco on the map.

**Terminal approach alert (SUPERSEDED: replaced by the animated arrow described in the "Coin audio + Terminal arrow fix" section below):** a top-of-screen, responsive notice says “TERMINAL AHEAD — Prepare to stop for passengers!” when the korope is approximately 180 m before the pickup bay. It stays visible for about two seconds, then hides. It does not stop the vehicle or board passengers. It triggers once per trip and resets for a new trip/restart. The existing bay location, waiting passenger count, capacity, stop-speed requirement, hold duration, missed-pickup behavior, and ₦200-per-passenger fare are unchanged.

**Traffic variety:** the existing traffic system now reuses the existing six traffic slots across the same three road lanes. Cars remain the default majority. Default type probabilities are 14% motorcycle, 8% bicycle, and 78% car; configure with `createWorld(scene, { trafficProbabilities: { motorcycle: 0.14, bicycle: 0.08 } })`. Probabilities are capped so riders cannot exceed 45% combined. Each reusable slot includes hidden car, motorcycle-with-rider, and bicycle-with-rider models; only its selected type is shown. Motorcycles travel at approximately 11–16 m/s and bicycles at approximately 3.2–5.6 m/s. Their smaller collision boxes and same-lane respawn spacing use the existing collision/traffic lifecycle. The world accepts `trafficRandom` for deterministic testing.

**Tests:** run `npm test`. Chapter 6 tests cover route naming/order, Terminal warning timing and repeat behavior, Terminal-vs-Lamenco signage, traffic types/speeds, road lanes, initial spacing, and collision dimensions. These are automated code tests; a live browser/device play-through is still recommended before deployment.


## Chapter 6 Improvements — Controls, riders, boarding, audio, leaderboard

### Touch controls — virtual steering wheel
- Removed the **LEFT**, **MIDDLE**, **RIGHT**, and **JUMP** touch buttons. Mobile driving now uses a circular, touch-rotated steering wheel plus the separate **GAS**, **BRAKE**, and **REVERSE** pedals.
- Touch pointer movement is captured only while the steering-wheel control is held; there is no full-screen drag/swipe steering surface. Turning the wheel proportionally steers the korope, and the wheel smoothly returns to centre when released. Keyboard arrows / A-D remain supported on desktop.
- The short jump mechanic remains available through the desktop **Space** key; there is no on-screen Jump button. Road boundaries, collisions, pause and mute remain active. The wheel and pedal layout adapts to narrow and landscape mobile screens.

### Traffic and boarding
- Motorcycle models are scaled up by 1.28× and bicycles by 1.48×, including visible wheels, frame/body, rider and helmet/head. Their collision boxes were adjusted to match the larger silhouettes; cars remain the majority and bicycles remain slowest.
- Terminal boarding animates up to three people at a time with procedural arm/leg swings and walking toward the side entrance. A passenger only disappears after reaching the boarding point. The fare banner/HUD fare is revealed once the boarding animation finishes. Capacity and fare rules remain in `src/route.js`; excess waiting passengers remain at the stop.
- `setBoarded(0)` restores the full waiting crowd and clears animation state on a new trip/restart.

### Pickup audio source/licensing
- `assets/coin-pickup.wav` is an original short metallic coin effect synthesized for this project in this patch. It was not extracted from the supplied YouTube reference, and no YouTube URL is used at runtime. It is a locally bundled PCM WAV asset; no third-party sound license is required for this generated effect. Coin and cash pickups share it while the coin wallet and naira cash counter remain separate. Mute and Game Sound settings are respected; synthesized fallback cues remain for browsers without usable HTML audio.
- The reference YouTube Short was not downloaded or copied.

### Leaderboard
- The home screen now shows a **LEADERBOARD** button. Today / This Week / This Month filters appear only after opening the responsive modal; selected period is highlighted and the close button returns to home.
- Scores/nicknames are read from the existing local `koroperun_local_runs` storage. This is **device-local**, not a real global or online leaderboard; no fake online players are inserted. Cross-device rankings need a backend.

### Validation and limits
- `npm test` runs the existing Chapter 1–6/Milestone suites plus `tests/chapter6-improvements.test.mjs`. The tests cover discrete control wiring/no drag listeners, jump arc, route/Terminal, mixed traffic types and spacing, passenger animation completion, fare timing, local sound asset, leaderboard period filtering and preserved wallets.
- `node --check` is run on the changed JavaScript modules before packaging. ZIP integrity is checked after creation.
- No real browser session, physical mobile device, visual GPU/performance profiling, or audible speaker test was performed in this environment. Validate those manually before publishing to Netlify.


## Steering wheel update
- The mobile touch UI now uses a circular virtual steering wheel, visually styled with rim, spokes and centre hub. Touch/drag interaction is limited to the wheel itself; turning angle is clamped and self-centres after release. The discrete lane and Jump buttons are removed. GAS, BRAKE and REVERSE remain separate. Desktop arrow/A-D steering and Space jump are preserved.
- Validation for this update: `npm test`, JavaScript syntax checks and ZIP integrity checks. No live browser or physical-phone play-through was performed in this environment.


## Chapter 7A — Audio fix and Pause/Resume repair

### Run locally
```bash
cd <this folder>             # index.html is at the root
python3 -m http.server 8000  # or: npx serve
# open http://localhost:8000   (must be served over http(s); opening index.html via file:// will not load the ES modules)
npm test                     # Node 18+, no install needed (uses vendor/three.module.js)
```
### Deploy to Netlify
Drag this folder (or the ZIP contents, with `index.html` at the top level) into Netlify Drop, or connect the repo with **no build command** and publish directory `.`. Everything (Three.js, `assets/coin-pickup.wav`) is local, so no environment variables or external requests are needed. Test audio on a real phone over HTTPS after deploying.

### Actual cause (found by reading the code)
1. **`setPaused(false)` (Continue/Resume) never touched the AudioContext.** The only resume path was `Sound.unlock()`, called on PLAY/RESTART only, and it only resumed a context in state `'suspended'`. When the page is hidden (the game auto-pauses on `visibilitychange`), after a screen lock/phone call, or on iOS (state `'interrupted'`), the context stayed non-running. Every Web Audio sound (engine, bump, crash, boarding, magnet, and the synthesized coin/cash fallback) is gated on `ctx.state === 'running'`, so the game stayed silent after Continue.
2. **Coin pickup depended on HTMLAudio `play()` called outside a tap.** Mobile browsers reject that, and the only fallback needed the context that was not running, so nothing played.
3. **Two sound flags could disagree** (`koroperun_sound` used by `Sound`, `koroperun_game_sound` used by Settings and the coin handler). Pressing **M** only wrote the first, so after muting in Settings and unmuting with M, coins stayed silent while other sounds played, and Settings could show the wrong state after a reload.

### What changed
- `src/audio.js`: `unlock()` now resumes any non-running context (including `interrupted`), rebuilds a `closed` one (dropping the stale engine oscillator), and uses a pending/rate-limit guard so rapid taps issue one `resume()`. New `resume()` (safe from any gesture) and `pauseAudio()` (cuts one-shots and the engine hum; does **not** touch the preference). The bundled `assets/coin-pickup.wav` is decoded once into a Web Audio buffer and played through the same master gain for coins **and** cash, which does not need per-play user activation; HTMLAudio with the same file is the second choice and the synthesized tones the last. One preference reader/writer keeps both keys in step; if either says off, it stays muted.
- `src/main.js`: Continue calls `sound.unlock()`, Pause calls `sound.pauseAudio()`, `visibilitychange` pauses audio when hidden and tries a resume when visible, and one set of module-level `pointerup/touchend/click/keydown` listeners re-wakes a suspended context on any real tap. The coin handler now relies on `sound.coin()` (which honours the single preference). The **M** key also refreshes the pause-card label.
- `tests/chapter7a.test.mjs` (new, 15 tests, added to `npm test`). No existing test was edited.
- Unchanged: the assets, gameplay, wallets, route, controls, Garage, Settings, leaderboard, power-ups.

### Behaviour
- Sound enabled: Pause silences the engine and any in-flight one-shot; Continue wakes the context and the engine ramps back up; coin and cash pickups play once each. Sound muted: Pause/Continue/Home/restart never change the saved choice and nothing plays. The Music setting is separate and untouched.
- Browsers may still keep audio blocked until a user gesture; Continue, PLAY, RESTART, the sound button and any tap provide it. Autoplay is not forced.
- If `assets/coin-pickup.wav` is missing or cannot be decoded, the game logs nothing, falls back to HTMLAudio and then the synthesized cue (no crash). The file is present in this ZIP.

### Test status
`npm test` runs the Chapter 1–6/Milestone suites plus Chapter 7A against **mocked** Web Audio/HTMLAudio/localStorage. No real browser, real phone, audible speaker test, Safari/iOS or Android testing was performed in this environment. Please verify Pause→Continue and coin/cash sound on your devices before starting Milestone 7B.


## Coin audio + Terminal arrow fix

### Run locally / deploy (unchanged)
```bash
python3 -m http.server 8000   # or: npx serve ; open http://localhost:8000 (needs http(s), not file://)
npm test                      # Node 18+, no install needed
```
Netlify: drag this folder (index.html at the top level) into Netlify Drop, or connect a repo with no build command and publish directory `.`. Everything is local; no external requests. Test audio on a real phone over HTTPS after deploying.

### 1. Coin pickup sound on mobile
**Cause (from the code, not reproduced on a phone):** coin and cash already called the same `Sound` code; they differ in *rate*. Coins are 9 m apart, so at speed one is collected roughly every 0.3 s, shorter than the 0.36 s metallic sound, while cash bundles are rare. Whenever the decoded Web Audio buffer was not available (still decoding, failed once, or the context not running), every pickup fell to a single shared `HTMLAudio` element that was restarted with `pause()` → `currentTime = 0` → `play()`. On mobile browsers that interrupts the still-sounding previous pickup (the aborted `play()` promise), so dense coins cut each other off and sounded unreliable, while isolated cash pickups sounded fine. In the test mock that models this behaviour, the previous code cut off 19 of 20 coins at 0.3 s spacing; the new code cuts off none.

**Fix (`src/audio.js`, `src/main.js`):**
- `coin()` and `cash()` now share one path, `#pickupSound(kind)`: decoded local WAV through Web Audio → HTMLAudio → synthesized cue (last resort only; each kind keeps its own cue).
- The HTMLAudio fallback uses a small pool (max 4) of the *same* `assets/coin-pickup.wav`; a sounding element is not restarted unless all are busy.
- If the WAV buffer failed to decode earlier, later pickups retry the load (bounded to 3 attempts) instead of giving up.
- The coin handler plays its sound first, so a wallet/effects/DOM problem can never swallow it. The metallic sound is unchanged; no new audio file; no remote/YouTube source.
- Unchanged: exactly one handler call per collected coin, Game Sound/Mute and saved preferences, cash sound, engine audio, Pause/Continue resume logic from Chapter 7A.

### 2. Terminal arrow (replaces the text notice)
- The old "TERMINAL AHEAD…" text alert is removed (HTML, CSS, HUD code and the timer logic). A single animated **⬇** (`#terminalArrow`, built once in `index.html`) takes its place, in the upper middle of the view (below the HUD row, clear of the right-hand minimap, the bottom hint and the touch controls; never intercepts touches).
- It bounces up and down with a CSS animation (an opacity pulse if the device asks for reduced motion). The animation only runs while the arrow is displayed; no JavaScript timers, listeners or per-frame DOM/element creation. `Hud.showTerminalArrow()` flips a class only when visibility changes.
- Visible only while playing, with the Terminal pickup pending, from 200 m before the green bay until the bay starts (`src/terminal-warning.js`: `TERMINAL_ARROW_START`/`END`). Hidden on reaching the bay, boarding, a missed pickup, pause, crash, Home and new trips; it reappears on Continue if still inside the window.
- Screen-anchored (not projected onto the Terminal in 3D). It is display-only: it never stops the bus or boards passengers. Oke-Fia / Lamenco / Agunbelewo, the TERMINAL sign, minimap, waiting passengers, boarding animation, stop conditions, capacity and fares are untouched.

### Tests
`npm test` now also runs `tests/coin-audio-terminal-arrow.test.mjs` (17 tests: dense coins, coin/cash path parity, buffer retry, mute and saved preferences, Pause→Continue cycles, exactly-one-sound-per-coin on the real world, arrow window/conditions/cleanup, CSS, HUD caching, wiring). Three existing assertions that required the old text notice were updated to describe the arrow (`tests/chapter6.test.mjs` ×2, `tests/chapter6-improvements.test.mjs` ×1); nothing else in older tests changed.
**Not performed:** real-browser, real-device (iOS Safari / Android Chrome), audible speaker or visual on-screen testing. The mock HTMLAudio models interrupted playback but is not a real phone. Please check coin sound in dense runs, Pause→Continue, and the arrow placement on your phones.

## Drag-to-steer + bold translucent GAS / BRAKE
- Touch layout (coarse pointers only): a large steering area on the left (about half the screen width, starting below the HUD row, subtle dashed translucent panel with a "DRAG TO STEER" hint); on the right, big **GAS** (green) and **BRAKE** (red) buttons with SVG icons, bold outlined labels and visible borders, with smaller **JUMP** and **REVERSE** above them. The lane buttons and the wheel from earlier versions are gone.
- Steering is relative and smooth. Touch-down starts at the korope's current x (no jump); horizontal finger travel moves a steering target across the road (about 140-260 px sweeps the full width, scaled to the zone). The target is clamped to the outer lane centres (x = -4 … 4, inside the road's soft edge), its speed is capped at 12 m/s, and `Korope.update` follows it through the existing yaw/grip physics. Releasing the finger straightens the korope. Keyboard A/D/arrows still work and take priority.
- The zone sits under every button, the HUD, pause and mute, so a touch that starts on any of them cannot start steering. One finger steers at a time; pointer capture keeps the drag on the zone, with `pointerup`/`pointercancel`/`lostpointercapture`/blur all releasing it. Page scroll is blocked only on the controls.
- GAS/BRAKE/REVERSE use the existing hold logic (one pointer per button; release always clears); JUMP calls the existing jump mechanic.
- Gameplay input is enabled only while the state is `playing`; menus, pause, crash and Home end any drag and release every control.
- The trip panel/minimap is still placed from the top of the action pad (`#touch .pad`), so it stays clear of the buttons.
- Tests: `npm test` (adds `tests/drag-steering.test.mjs`). They are logic/markup tests with a fake DOM; no real browser or phone was used.

## Chapter 8 — Gameplay, performance and release polish

This build includes Chapter 8A–8C quality work while preserving the approved drag-steering layout and the bold, semi-transparent GAS/BRAKE buttons.

### Gameplay reliability
- Traffic following is updated in two phases using reused per-lane buckets. Each vehicle calculates its speed from a consistent frame snapshot before the traffic moves, avoiding array-order-dependent following behaviour.
- Traffic body spacing, rider lanes, collision sizes, collectible pools, route stops and passenger pickup/fare rules are covered by automated regression tests.
- The world simulation now advances only while the game state is `playing`. Home/menu and Game Over keep traffic, pickups, route/passenger animation and the bus frozen; crash particles are allowed to fade out. Pause continues to freeze the simulation and power-up timers.
- Existing score formula, coin rewards, naira cash rewards, passenger fares, Garage purchases and saved wallet/settings rules are unchanged.

### Performance and visual polish
- Reused immutable box, torus, sphere and tree-canopy geometries, plus shared world materials, reduce redundant 3D resource creation for repeated road props, traffic variants and passengers. Mesh transforms remain independent.
- Renderer sizing adapts the pixel-ratio cap to the input device: up to 1.5 on coarse-pointer/small-screen devices and up to 2 on desktop. It updates on resize/orientation changes and requests a high-performance WebGL context.
- Added tighter landscape-phone layout, keyboard focus indicators, and reduced-motion fallbacks without changing the existing steering or pedal controls.

### QA and release checks
- Run `npm test` to run the existing milestone regression suites plus `tests/chapter8.test.mjs`.
- Chapter 8 tests check geometry/material sharing, iteration-order-independent traffic following, no same-lane body overlap during a simulated drive, gameplay-state gating, responsive renderer settings, reduced-motion/focus styling, and preservation of core controls/audio/wallet/route wiring.
- Automated tests use the bundled Three.js module with mocked browser APIs. A real-browser/real-phone check was not completed in this environment; use a Netlify preview or local HTTP server to test on desktop and mobile before replacing the live deployment.

### Recommended pre-release smoke test
1. Open the site over `http://` or `https://` (not `file://`).
2. Start a trip; verify drag-to-steer and transparent GAS/BRAKE still feel correct.
3. Drive among cars, occasional motorcycles and bicycles; check collision spacing and road edges.
4. Collect coins and cash, test magnet/×5 power-ups, and stop at the Lamenco Terminal.
5. Pause/resume, crash/restart, then return Home; check audio, wallets, nickname, Garage and leaderboard.
6. Repeat on a phone in portrait and landscape, including after switching browser tabs.

### Chapter 8 validation boundary
Automated tests passed for this package. They do not prove frame-rate improvement on every device, visual fit on every display, or audible output on a physical phone. Those still need a manual browser/device check.

## Chapter 9 — Osogbo City Streets & Landmarks Expansion

Chapter 9 is added on top of the supplied Chapter 8 project. It keeps the existing main Oke-Fia → Lamenco → Agunbelewo journey, traffic, coins/cash, magnet, mobile drag steering, pause/resume audio repair, and Chapter 8 geometry/resource optimisations.

### Added city layer
- Eleven named cross-street districts along the route: Station Road, Old Garage, Oja Oba, Igbona, Lamenco, Alekuwodo, Oke Baale, GRA, Oroki Estate, Ilobu Road and Gbodofon.
- Street surfaces, road markings, crossings, signposts, local low-rise buildings and bus-stop shelters.
- Landmark silhouettes and signs for Oja Oba Market, Osogbo Central Mosque, Nike Art Centre and the Osun-Osogbo Sacred Grove, plus the existing Agunbelewo destination sign.
- The city layer is anchored to the route origin and follows the existing restart/origin reset.
- `world.cityMap.junctions` and `world.cityMap.landmarks` expose the named map data for future navigation/minimap work.

**Scope note:** this milestone adds the connected-looking city streetscape and landmarks to the current forward-running route. The existing driving physics still constrain the korope to the main road; choosing a side street and turning through the full city road graph is a separate driving/navigation milestone, not claimed as completed here.

### Test
Run `npm test` with Node.js 18 or newer. Chapter 9 adds four checks for named junctions, landmark data, scene integration/restart alignment and preservation of the existing route integration. Existing Chapter 1–8 test suites remain in the test command.


## Chapter 10 — Animated KoropeRun splash (first screen)
- The first screen is now the animated **KoropeRun splash** (`splash/index.html`, shown full-screen in `#splashFrame` inside `#loadingScreen`). The camera pushes in, a blue korope drives in from the left, the KOROPERUN logo slams in with a shockwave, then the loading panel slides up. Street lamps, the OSOGBO billboard, road-sign arrows, the monument glow, distant buses, rain and sparks keep moving. When loading finishes the bus drives off, the logo flies away and the screen fades to the **home screen**.
- **Real progress:** `src/splash.js` posts progress to the splash while real start-up tasks complete (splash frame, page load, fonts, `assets/coin-pickup.wav` cache warm-up). The bar cannot hit 100% before those finish and takes at least ~5 s so the animation plays fully. Failsafes: each task times out after 8 s and the splash is force-finished after 20 s, so it can never trap the player.
- **Responsive:** landscape and tablet screens keep the 16:9 scene with a blurred fill; portrait phones get a stacked layout (logo on top, bus in the middle, loading bar below). Touch devices use fewer particles and no blur panel. Text has minimum sizes. `prefers-reduced-motion` calms the idle loops.
- **Files:** `splash/index.html` (self-contained page), `splash/plate.webp` (background with logo/bus removed), `splash/logo.webp`, `splash/bus.webp` (transparent cut-outs, ~270 KB total), `src/splash.js`; `home.js` now calls `runSplash(...)` instead of the old fixed 6-second timer. `splash/index.html` also runs standalone (open it through a web server) as a demo that loops.
- **Deploy:** `netlify.toml` is included (no build command, publish `.`). Drag the folder or ZIP contents to Netlify Drop, or any static host over HTTPS.
- Tests: `npm test` adds `tests/splash.test.mjs`. Browser/device testing of the splash is still recommended.
