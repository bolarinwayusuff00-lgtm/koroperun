// Keyboard controls plus touch controls: a large DRAG-TO-STEER zone (left), and GAS / BRAKE / REVERSE / JUMP buttons (right).
// Drag steering is relative: the korope's x position when the finger lands is the starting point, so nothing jumps.
// Horizontal finger movement moves a steering target (clamped to the road), which Korope.update follows through its existing yaw/grip physics.
// Releasing the finger clears the target and the korope straightens out. Keyboard A/D/arrows keep their original held-steer behaviour.
import { ROAD } from './world.js';
const KEYS = {
  gas: ['ArrowUp', 'KeyW'], brake: ['ArrowDown', 'KeyS'], reverse: ['KeyR'],
  left: ['ArrowLeft', 'KeyA'], right: ['ArrowRight', 'KeyD'], jump: ['Space'],
};
export const DRAG_LIMIT = ROAD.lanes[ROAD.lanes.length - 1]; // 4: outermost lane centre, inside the road's soft edge (4.1) so dragging never scrubs speed
export const DRAG_SPAN_PX = [140, 260];                      // finger travel (px) that sweeps the whole road width; scales with the zone, clamped
export const DRAG_MAX_RATE = 12;                             // m/s: the target can never move faster than this (no sudden jumps)
const clampX = (x) => Math.max(-DRAG_LIMIT, Math.min(DRAG_LIMIT, x));

export class Controls {
  constructor() {
    this.held = { gas: false, brake: false, reverse: false, left: false, right: false, jump: false };
    this.btnPointer = {}; this.jumpRequested = false; this.onPause = () => {};
    this.enabled = true;                    // main.js turns this off in menus, pause, crash
    this.allButtons = []; this.busX = 0;
    this.dragPointer = null; this.dragTarget = null; this.dragGoal = 0; this.dragStartX = 0; this.dragStartTarget = 0; this.dragSpan = 200;
    this.zone = document.getElementById?.('steerZone') ?? null;
    addEventListener('keydown', e => this.#key(e, true));
    addEventListener('keyup', e => this.#key(e, false));
    addEventListener('blur', () => this.reset());
    // Hold buttons (GAS / BRAKE / REVERSE): one pointer owns a button at a time; release always clears it.
    document.querySelectorAll('[data-hold]').forEach(btn => {
      this.allButtons.push(btn); const name = btn.dataset.hold;
      const set = v => { this.held[name] = v; btn.classList.toggle('on', v); if (!v) delete this.btnPointer[name]; };
      const release = e => { if (this.btnPointer[name] === e.pointerId) set(false); };
      btn.addEventListener('pointerdown', e => {
        e.preventDefault(); if (!this.enabled || name in this.btnPointer) return;
        this.btnPointer[name] = e.pointerId; set(true); try { btn.setPointerCapture(e.pointerId); } catch {}
      });
      ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(t => btn.addEventListener(t, release));
      ['pointerup', 'pointercancel'].forEach(t => addEventListener(t, release));
      this.#guard(btn);
    });
    // Jump: one tap = one jump request.
    document.querySelectorAll('[data-jump]').forEach(btn => {
      this.allButtons.push(btn);
      btn.addEventListener('pointerdown', e => {
        e.preventDefault(); if (!this.enabled) return; this.jumpRequested = true; btn.classList.add('on'); setTimeout(() => btn.classList.remove('on'), 160);
      });
      this.#guard(btn);
    });
    // Drag-to-steer zone. It sits UNDER every button, HUD, pause and mute control, so a touch that starts on any of those never reaches it.
    // Only one finger steers; pointer capture keeps move/up events on the zone, so no window-level move listeners are needed.
    if (this.zone) {
      const z = this.zone;
      z.addEventListener('pointerdown', e => {
        e.preventDefault(); if (!this.enabled || this.dragPointer !== null || (e.target && e.target !== z)) return;
        const w = z.getBoundingClientRect?.().width || 200;
        this.dragSpan = Math.max(DRAG_SPAN_PX[0], Math.min(DRAG_SPAN_PX[1], w * 0.8));
        this.dragPointer = e.pointerId; this.dragStartX = e.clientX;
        this.dragStartTarget = this.dragTarget = this.dragGoal = clampX(this.busX); // start exactly where the korope is: no jump on touch-down
        z.classList.add('dragging'); this.#paint(e.clientX, e.clientX);
        try { z.setPointerCapture(e.pointerId); } catch {}
      });
      z.addEventListener('pointermove', e => {
        if (this.dragPointer !== e.pointerId) return; e.preventDefault();
        this.dragGoal = clampX(this.dragStartTarget + (e.clientX - this.dragStartX) / this.dragSpan * (2 * DRAG_LIMIT));
        this.#paint(this.dragStartX, e.clientX);
      });
      const end = e => { if (this.dragPointer === e.pointerId) this.#endDrag(); };
      ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(t => z.addEventListener(t, end));
      ['pointerup', 'pointercancel'].forEach(t => addEventListener(t, end));
      this.#guard(z);
    }
  }
  #guard(el) { // stop page scroll / long-press menus only on the controls themselves
    ['touchstart', 'touchmove'].forEach(t => el.addEventListener(t, e => e.preventDefault(), { passive: false }));
    el.addEventListener('contextmenu', e => e.preventDefault());
  }
  #paint(sx, cx) { // visual feedback only: start ring and thumb ring positions (px inside the zone)
    const z = this.zone, left = z?.getBoundingClientRect?.().left || 0;
    z?.style?.setProperty?.('--sx', (sx - left) + 'px'); z?.style?.setProperty?.('--cx', (cx - left) + 'px');
  }
  #endDrag() { this.dragPointer = null; this.dragTarget = null; this.zone?.classList.remove('dragging'); }
  // Called every frame with the korope's current x. The steering target eases toward the finger at a capped rate.
  update(dt, busX) {
    if (typeof busX === 'number') this.busX = busX;
    if (this.dragPointer !== null && this.dragTarget !== null) {
      const diff = this.dragGoal - this.dragTarget, cap = DRAG_MAX_RATE * Math.max(0, dt);
      this.dragTarget += Math.max(-cap, Math.min(cap, diff * Math.min(1, 14 * Math.max(0, dt))));
    }
  }
  #key(e, down) {
    if (down && (e.code === 'KeyP' || e.code === 'Escape') && !e.repeat) { this.onPause(); return; }
    for (const [name, codes] of Object.entries(KEYS)) if (codes.includes(e.code)) {
      e.preventDefault();
      if (!this.enabled && down) continue;                    // keys are ignored while gameplay is inactive (key-up still releases)
      this.held[name] = down;
      if (name === 'jump' && down && !e.repeat) this.jumpRequested = true;
    }
  }
  setEnabled(on) { this.enabled = !!on; if (!on) this.reset(); }
  reset() { // releases every held control, including an active steering drag
    for (const k in this.held) this.held[k] = false; this.btnPointer = {};
    this.allButtons.forEach(b => b.classList.remove('on'));
    this.jumpRequested = false; this.#endDrag();
  }
  get throttle() { return this.held.gas ? 1 : 0; } get brake() { return this.held.brake ? 1 : 0; } get reverse() { return this.held.reverse ? 1 : 0; }
  get steer() { return (this.held.right ? 1 : 0) - (this.held.left ? 1 : 0); }  // keyboard only; touch drag uses dragTarget
  get dragging() { return this.dragPointer !== null; }
  get jump() { return this.jumpRequested; }
  consumeJump() { this.jumpRequested = false; }
}
