import * as THREE from 'three';
import { ROAD } from './world.js';

const mat = (c, o = {}) => new THREE.MeshLambertMaterial({ color: c, ...o });
const box = (w, h, d, m, x, y, z) => { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); b.position.set(x, y, z); return b; };

// Driving limits (Chapter 2). `speed` is always the size of the speed (>= 0); `dir` says which way the bus is going.
export const REV_MAX = 6;          // m/s reverse speed cap (it levels off near ~19 km/h because of drag): reversing is for parking, not racing
export const SHIFT_SPEED = 0.5;    // m/s: the bus must be this slow (or slower) before it may change direction
export const REVERSE_LIMIT = 40;   // m: how far back you may go past your furthest point (the world only exists ~60 m behind)

// Procedural Osogbo-style blue korope with a narrow yellow stripe and dark bumpers. The front points to -Z.
export class Korope {
  constructor() {
    this.group = new THREE.Group();
    this.wheels = [];
    this.speed = 0; this.yaw = 0; this.x = 0; this.z = 0; this.distance = 0;
    this.dir = 1; this.net = 0; // dir: +1 forward, -1 reverse. net: signed progress along the road; distance (score) only counts the furthest point reached
    this.edge = 0; this.onWall = false; this.jumpTime = 0; this.jumpHeight = 0;
    this.MAX = 36; // m/s (~130 km/h)

    const blue = mat(0x079fb8), yellow = mat(0xffc928), glass = mat(0x1a2433), dark = mat(0x353535);
    const g = this.group;
    g.add(box(2.1, 1.0, 4.8, blue, 0, 0.95, 0));       // lower body
    g.add(box(2.0, 1.0, 3.7, blue, 0, 1.95, 0.35));    // cabin
    // Keep the minibus body and roof blue; use a slim yellow centre stripe like the reference photo.
    g.add(box(0.12, 0.025, 0.92, yellow, 0, 1.465, -1.93)); // stripe on the bonnet
    g.add(box(0.12, 0.025, 2.65, yellow, 0, 2.515, 0.25)); // stripe over the blue roof
    g.add(box(1.9, 0.5, 0.06, glass, 0, 2.0, -1.52));  // windscreen
    g.add(box(2.04, 0.5, 2.9, glass, 0, 2.0, 0.55));   // side window band
    g.add(box(1.7, 0.45, 0.06, glass, 0, 2.0, 2.22));  // rear window
    this.rearText = this.makeTextMesh('OSOGBO TO THE WORLD', 1.45, 0.18, 0xffffff);
    this.rearText.position.set(0, 1.43, 2.405); g.add(this.rearText); // permanent inscription on the rear blue body panel
    g.add(box(2.3, 0.25, 0.3, dark, 0, 0.55, -2.5));   // front bumper
    g.add(box(2.3, 0.25, 0.3, dark, 0, 0.55, 2.5));    // rear bumper
    for (const s of [-1, 1]) {
      g.add(box(0.35, 0.22, 0.08, mat(0xfff2b0, { emissive: 0xffe08a }), s * 0.7, 1.05, -2.42)); // headlights
      g.add(box(0.3, 0.2, 0.08, mat(0xd62828, { emissive: 0x801010 }), s * 0.8, 1.05, 2.42));    // tail lights
    }
    const wheelGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.3, 16); wheelGeo.rotateZ(Math.PI / 2);
    for (const sx of [-1, 1]) for (const z of [-1.6, 1.6]) {
      const w = new THREE.Mesh(wheelGeo, dark); w.position.set(sx * 1.05, 0.42, z); g.add(w); this.wheels.push(w);
    }
    g.add(box(1.0, 0.25, 0.08, blue, 0, 2.75, -1.1)); // blue roof destination board
  }

  makeTextMesh(text, width, height, color = 0xffffff) {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 96;
    const ctx = canvas.getContext('2d');
    if (ctx && typeof ctx.clearRect === 'function' && typeof ctx.fillText === 'function') {
      ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = '#073b55'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = '900 52px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ffffff'; ctx.fillText(text, canvas.width / 2, canvas.height / 2, canvas.width - 12);
      const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height), new THREE.MeshBasicMaterial({map:texture, transparent:false, side:THREE.DoubleSide})); mesh.userData.canvasTexture = texture; return mesh;
    }
    // Lightweight fallback for headless unit tests that stub CanvasRenderingContext2D.
    return new THREE.Mesh(new THREE.PlaneGeometry(width, height), new THREE.MeshBasicMaterial({color:0xffffff, side:THREE.DoubleSide}));
  }

  setDecal(text) {
    if (this.customDecal) { this.group.remove(this.customDecal); this.customDecal.geometry.dispose(); this.customDecal.material.map?.dispose(); this.customDecal.material.dispose(); this.customDecal = null; }
    if (!text) return;
    this.customDecal = this.makeTextMesh(text, 1.6, 0.3);
    this.customDecal.position.set(1.058, 1.35, 0.4); this.customDecal.rotation.y = Math.PI / 2;
    this.group.add(this.customDecal);
  }

  update(dt, input, playing) {
    const gas = playing && input.throttle > 0, rev = playing && (input.reverse || 0) > 0;
    const brake = playing ? input.brake : 0;
    // Direction may only change when the bus is (nearly) stopped, and only when exactly one of GAS / REVERSE is held.
    // BRAKE never changes direction.
    if (this.speed <= SHIFT_SPEED && gas !== rev && (gas ? 1 : -1) !== this.dir) { this.dir = gas ? 1 : -1; this.speed = 0; }
    const dir = this.dir, top = dir === 1 ? this.MAX : REV_MAX;
    // The pedal for the current direction drives. The opposite pedal only slows the bus (like BRAKE) until it has stopped.
    const drive = dir === 1 ? gas && !rev : rev && !gas;
    const opposite = dir === 1 ? rev : gas;
    if (drive) this.speed += (dir === 1 ? 14 : 5) * (1 - this.speed / (top * 1.1)) * dt; // acceleration eases off near top speed
    if (brake || opposite) this.speed -= 30 * dt;
    this.speed -= (drive ? 1.0 : 4.5) * dt;                                   // rolling drag
    this.speed = THREE.MathUtils.clamp(this.speed, 0, top);
    if (dir === -1 && this.distance - this.net >= REVERSE_LIMIT) this.speed = 0; // end of the reverse zone

    // Steering needs movement (grip fades in over the first few m/s). Reversing: pressing right still sends the bus to the right.
    const grip = Math.min(1, this.speed / 6);
    let steer = playing ? input.steer : 0;
    // Drag steering (touch): while a finger drags and no keyboard steering is held, steer toward the drag target with a damped, clamped command.
    if (playing && steer === 0 && typeof input.dragTarget === 'number') steer = THREE.MathUtils.clamp((input.dragTarget - this.x) * 0.5 + this.yaw * 1.2, -1, 1);
    const targetYaw = -steer * 0.32 * grip * dir;
    this.yaw += (targetYaw - this.yaw) * Math.min(1, 7 * dt);
    this.x -= Math.sin(this.yaw) * this.speed * dt * 1.6 * dir;
    if (playing && input.jump && this.jumpTime <= 0) { this.jumpTime = 0.82; if (input.consumeJump) input.consumeJump(); }
    if (this.jumpTime > 0) { this.jumpTime = Math.max(0, this.jumpTime - dt); this.jumpHeight = Math.sin((1 - this.jumpTime / 0.82) * Math.PI) * 1.35; } else this.jumpHeight = 0;
    this.z -= Math.cos(this.yaw) * this.speed * dt * dir;
    this.net += this.speed * dt * dir;
    this.distance = Math.max(this.distance, this.net); // reversing never adds score, and going back and forth cannot farm it

    // Road edges: a soft rumble zone near the kerb, then a firm limit. No teleporting; speed bleeds off
    // while you press into the edge, and the nose is nudged back toward the road.
    this.edge = 0;
    const ax = Math.abs(this.x), sgn = Math.sign(this.x);
    if (ax > ROAD.soft) {
      const depth = Math.min(1, (ax - ROAD.soft) / (ROAD.limit - ROAD.soft));
      this.speed = Math.max(0, this.speed - (2 + 6 * depth) * dt);
      this.edge = 0.4 + 0.3 * depth;
    }
    if (ax >= ROAD.limit) {
      if (!this.onWall) this.speed *= 0.88; // first touch of the kerb
      this.onWall = true;
      this.x = sgn * ROAD.limit;
      this.speed = Math.max(0, this.speed - 7 * dt);
      this.yaw = sgn * 0.08 * dir; // gentle bounce back toward the road
      this.edge = 1;
    } else if (ax < ROAD.limit - 0.1) this.onWall = false;

    this.group.position.set(this.x, this.jumpHeight, this.z);
    this.group.rotation.y = this.yaw;
    this.group.rotation.z = -this.yaw * 0.12 * Math.min(1, this.speed / 15); // body roll
    for (const w of this.wheels) w.rotation.x -= (this.speed / 0.42) * dt * this.dir;
  }

  // Restart after a crash: keep z so the recycled road/world stays valid.
  restart() { this.speed = 0; this.yaw = 0; this.x = 0; this.distance = 0; this.dir = 1; this.net = 0; this.edge = 0; this.onWall = false; this.jumpTime = 0; this.jumpHeight = 0; }
}
