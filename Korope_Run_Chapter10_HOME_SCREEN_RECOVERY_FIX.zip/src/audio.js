// Milestone 5: tiny synthesized sound (Web Audio, no files, no libraries, nothing copyrighted).
// The AudioContext is only created after a user gesture (unlock()). Every call is wrapped so audio failures never affect gameplay.
const KEY = 'koroperun_sound';            // legacy key written by Sound.setOn()
const GAME_KEY = 'koroperun_game_sound';  // key used by Settings; setOn() now keeps BOTH in step
const PICKUP_URL = new URL('../assets/coin-pickup.wav', import.meta.url); // local bundled asset; never a remote/YouTube source
// Saved Game Sound preference. If either key says "off" the player muted on purpose, so stay muted (never force sound on).
function readSoundPref() {
  try {
    const a = localStorage.getItem(GAME_KEY), b = localStorage.getItem(KEY);
    const on = !(a === '0' || b === 'off');
    if ((a !== null || b !== null) && (a !== (on ? '1' : '0') || b !== (on ? 'on' : 'off'))) { localStorage.setItem(GAME_KEY, on ? '1' : '0'); localStorage.setItem(KEY, on ? 'on' : 'off'); }
    return on;
  } catch (e) { return true; }
}

export class Sound {
  constructor() {
    this.ctx = null; this.master = null; this.noise = null; this.eng = null;
    this.live = new Set(); this.lastCoin = -1e9; this.lastCash = -1e9; this.lastMagnet = -1e9; this.engLevel = 0;
    this.on = readSoundPref();
    this.pickupBuf = null; this.pickupLoading = false; this.pickupTries = 0; this.resumeAt = -1e9; this.resumePending = false;
    this.unlocked = false; this.pickupAudio = null; this.pickupPool = []; this.pickupBusy = []; this.pickupNext = 0;
    try { if (typeof Audio === 'function') { this.pickupAudio = new Audio(PICKUP_URL); this.pickupAudio.preload = 'auto'; this.pickupAudio.volume = this.on ? 0.55 : 0; this.pickupPool.push(this.pickupAudio); this.pickupBusy.push(0); } } catch {}
  }

  // Drop a dead/closed context and everything attached to it so a fresh one never inherits a stale engine oscillator.
  #dropContext() {
    try { this.eng?.o.stop(); } catch (e) { /* already stopped */ }
    this.ctx = null; this.master = null; this.noise = null; this.eng = null; this.engLevel = 0; this.pickupBuf = null; this.pickupLoading = false;
    this.live.clear(); this.resumePending = false;
  }
  // Resume a suspended/'interrupted' (iOS) context. force=true is for real user gestures. Never creates a context, never changes `on`.
  #resumeCtx(force) {
    const c = this.ctx; if (!c || c.state === 'running' || c.state === 'closed') return;
    const now = performance.now();
    if (this.resumePending && now - this.resumeAt < 1500) return; // a resume is already in flight (rapid taps)
    if (!force && now - this.resumeAt < 2000) return;            // automatic retries are rate-limited
    this.resumeAt = now; this.resumePending = true;
    let p; try { p = c.resume(); } catch (e) { this.resumePending = false; return; }
    const done = () => { if (this.ctx === c) this.resumePending = false; };
    if (p && p.then) p.then(done, done); else done();
  }
  // Decode the bundled WAV once into a Web Audio buffer: plays reliably on mobile once the context runs (HTMLAudio needs a gesture per play).
  #loadPickupBuffer() {
    const c = this.ctx;
    if (!c || this.pickupBuf || this.pickupLoading || this.pickupTries >= 3 || typeof c.decodeAudioData !== 'function' || typeof fetch !== 'function') return;
    this.pickupLoading = true; this.pickupTries++;
    try {
      fetch(PICKUP_URL).then((r) => { if (!r.ok) throw new Error('pickup sound HTTP ' + r.status); return r.arrayBuffer(); })
        .then((ab) => new Promise((res, rej) => { const p = c.decodeAudioData(ab, res, rej); if (p && p.catch) p.catch(rej); }))
        .then((buf) => { if (this.ctx === c) this.pickupBuf = buf; })
        .catch(() => { /* asset missing or undecodable: HTMLAudio / synthesized fallback below still work */ })
        .then(() => { if (this.ctx === c) this.pickupLoading = false; });
    } catch (e) { this.pickupLoading = false; }
  }
  // Safe to call from any gesture, Continue or visibility change. Only resumes an existing context.
  resume() { try { this.#resumeCtx(true); } catch (e) { /* ignore */ } }
  // Pause / tab hidden: cut one-shots and the engine hum at once. Does NOT touch the saved mute or Game Sound preference.
  pauseAudio() {
    try { this.silence(); this.engLevel = 0; if (this.eng) this.eng.g.gain.value = 0; } catch (e) { /* ignore */ }
  }

  // Call from a click/tap/keypress handler. Safe to call repeatedly; creates the context only once and resumes it if the browser suspended it.
  unlock() {
    this.unlocked = true;
    try {
      if (this.ctx && this.ctx.state === 'closed') this.#dropContext();
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain(); this.master.gain.value = this.on ? 0.8 : 0; this.master.connect(this.ctx.destination);
        const len = Math.floor(this.ctx.sampleRate * 0.7), buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
        this.noise = buf;
      }
      this.#resumeCtx(true);
      this.#loadPickupBuffer();
    } catch (e) { this.#dropContext(); }
  }

  setOn(on) {
    this.on = on;
    try { localStorage.setItem(KEY, on ? 'on' : 'off'); localStorage.setItem(GAME_KEY, on ? '1' : '0'); } catch (e) { /* storage unavailable */ }
    if (on) this.unlock();
    if (this.master) this.master.gain.value = on ? 0.8 : 0;
    if (this.pickupAudio) this.pickupAudio.volume = on ? 0.55 : 0;
    for (const a of this.pickupPool) { try { a.volume = on ? 0.55 : 0; } catch (e) { /* read-only on some mobile browsers */ } }
    if (!on) this.silence();
  }
  toggle() { this.setOn(!this.on); return this.on; }

  get ready() { return this.on && this.ctx && this.ctx.state === 'running'; }

  // One short sound = oscillator/noise -> gain envelope -> master. Tracked so silence() can cut it on restart.
  #voice(src, g, dur, mid) { // mid: optional filter between src and g
    if (mid) { src.connect(mid); mid.connect(g); } else src.connect(g);
    g.connect(this.master);
    const v = { src, g }; this.live.add(v);
    src.onended = () => { this.live.delete(v); try { g.disconnect(); } catch (e) { /* already gone */ } };
    src.start(); src.stop(this.ctx.currentTime + dur);
  }
  #tone(type, f0, f1, t0, dur, vol) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    this.#voice(o, g, dur + 0.02 + (t0 - c.currentTime));
  }

  // Pick a free HTMLAudio element (a small pool of the same local WAV). A playing element is never restarted unless all are busy,
  // so a coin arriving while the previous pickup still rings no longer aborts it (single-element pause/seek/play was the unreliable part on mobile).
  #pickElement() {
    const pool = this.pickupPool, now = performance.now();
    for (let i = 0; i < pool.length; i++) { const k = (this.pickupNext + i) % pool.length; if (now >= this.pickupBusy[k]) { this.pickupNext = (k + 1) % pool.length; return k; } }
    if (pool.length < 4 && typeof Audio === 'function') {
      try { const a = new Audio(PICKUP_URL); a.preload = 'auto'; a.volume = this.on ? 0.55 : 0; pool.push(a); this.pickupBusy.push(0); this.pickupNext = 0; return pool.length - 1; } catch (e) { /* use an existing one */ }
    }
    const k = this.pickupNext; this.pickupNext = (k + 1) % pool.length; return k; // all busy: restart the oldest
  }
  #pickup(fallback) {
    if (!this.on || !this.unlocked) return false;
    // 1) decoded local WAV through Web Audio (works on mobile whenever the context is running)
    if (this.pickupBuf && this.ready) {
      try { const c = this.ctx, src = c.createBufferSource(), g = c.createGain(); src.buffer = this.pickupBuf; g.gain.value = 0.55; this.#voice(src, g, this.pickupBuf.duration + 0.05); return true; } catch {}
    }
    if (this.ctx && !this.pickupBuf) this.#loadPickupBuffer(); // not decoded yet (slow network / earlier failure): try again, bounded
    if (this.ctx && !this.ready) this.#resumeCtx(false); // context was suspended/interrupted: try to wake it (a real tap also does)
    // 2) HTMLAudio with the same local WAV, one element per overlapping pickup
    if (this.pickupPool.length) {
      try {
        const k = this.#pickElement(), el = this.pickupPool[k], now = performance.now();
        const busy = this.pickupBusy[k] > now; // only restarted when every element is busy
        if (busy) el.pause();
        el.currentTime = 0; el.volume = 0.55; this.pickupBusy[k] = now + (Number.isFinite(el.duration) && el.duration > 0 ? el.duration * 1000 : 400) + 30;
        const promise = el.play();
        // Some mobile browsers reject HTMLAudio playback even after the game starts.
        // Fall back to the already-unlocked Web Audio tones instead of silently dropping the pickup sound.
        if (promise && promise.catch) promise.catch(() => { this.pickupBusy[k] = 0; try { if (this.on && this.ready) fallback(); } catch {} });
        return true;
      } catch {}
    }
    return false;
  }
  // Coin and cash share ONE pickup path (buffer -> HTMLAudio pool -> synthesized cue); only the last-resort synthesized cue differs.
  #pickupSound(kind) {
    if (!this.on) return;
    const fb = kind === 'cash' ? () => this.#cashFallback() : () => this.#coinFallback();
    if (this.unlocked && this.#pickup(fb)) return;
    fb();
  }
  #coinFallback() { this.#cashFallback(); }
  #cashFallback() { const now=performance.now(); if(!this.ready || now-this.lastCash<80)return; this.lastCash=now; const t=this.ctx.currentTime; this.#tone('triangle',784,784,t,0.07,0.12);this.#tone('triangle',1175,1175,t+0.07,0.1,0.12);this.#tone('sine',2349,2349,t+0.12,0.28,0.08); }
  coin() { try { this.#pickupSound('cash'); } catch {} }  // coins now use the exact same cash pickup audio, including the same fallback cue
  cash() { try { this.#pickupSound('cash'); } catch {} }  // same pickup audio; cash remains a separate balance
  magnet() { // Chapter 5: rising "power-up" whoosh for the magnet box (respects mute, throttled)
    try {
      const now = performance.now(); if (!this.ready || now - this.lastMagnet < 150) return; this.lastMagnet = now;
      const t = this.ctx.currentTime;
      this.#tone('sawtooth', 220, 880, t, 0.28, 0.07); this.#tone('triangle', 440, 1320, t + 0.06, 0.3, 0.1);
    } catch (e) { /* ignore */ }
  }
  board() { // short rising three-note jingle when passengers board (Milestone 6A)
    try {
      if (!this.ready) return; const t = this.ctx.currentTime;
      [[523, 0], [659, 0.1], [784, 0.2]].forEach(([f, o]) => this.#tone('triangle', f, f, t + o, 0.16, 0.12));
    } catch (e) { /* ignore */ }
  }
  bump() { try { if (this.ready) this.#tone('sine', 140, 55, this.ctx.currentTime, 0.18, 0.28); } catch (e) { /* ignore */ } }
  crash() { // noise burst + low thud
    try {
      if (!this.ready) return;
      const c = this.ctx, t = c.currentTime, n = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      n.buffer = this.noise; f.type = 'lowpass'; f.frequency.setValueAtTime(2200, t); f.frequency.exponentialRampToValueAtTime(200, t + 0.6);
      g.gain.setValueAtTime(0.4, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
      this.#voice(n, g, 0.65, f);
      this.#tone('sine', 120, 35, t, 0.45, 0.45);
    } catch (e) { /* ignore */ }
  }

  // Subtle engine hum: ONE oscillator created on first use, level/pitch follow speed. Call every frame.
  engine(speedMs, active, dt) {
    try {
      if (!this.ctx) return;
      if (active && this.on && this.ctx.state !== 'running') this.#resumeCtx(false);
      if (!this.eng) {
        const c = this.ctx, o = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
        o.type = 'sawtooth'; f.type = 'lowpass'; f.frequency.value = 380; g.gain.value = 0;
        o.connect(f); f.connect(g); g.connect(this.master); o.start(); this.eng = { o, g };
      }
      const target = this.ready && active ? 0.03 + Math.min(1, speedMs / 36) * 0.03 : 0;
      this.engLevel += (target - this.engLevel) * Math.min(1, 8 * dt);
      this.eng.g.gain.value = this.engLevel < 0.0005 && target === 0 ? 0 : this.engLevel;
      this.eng.o.frequency.value = 48 + Math.min(1, speedMs / 36) * 70;
    } catch (e) { /* ignore */ }
  }

  // Cut every one-shot sound immediately (restart / mute) so nothing carries over.
  silence() {
    for (const v of this.live) { try { v.src.stop(); v.g.disconnect(); } catch (e) { /* ended already */ } }
    this.live.clear();
    if (this.pickupAudio) { try { this.pickupAudio.pause(); this.pickupAudio.currentTime = 0; } catch {} }
    for (let i = 0; i < this.pickupPool.length; i++) { try { this.pickupPool[i].pause(); this.pickupPool[i].currentTime = 0; } catch {} this.pickupBusy[i] = 0; }
  }
}
