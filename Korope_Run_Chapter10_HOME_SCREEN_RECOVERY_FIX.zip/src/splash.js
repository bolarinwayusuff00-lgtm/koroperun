// Non-blocking splash coordinator. The iframe owns the only progress animation.
const MAX_SPLASH_MS = 7500;

export function runSplash(onDone) {
  const frame = document.getElementById('splashFrame');
  let finished = false;
  let timer = 0;

  const finish = () => {
    if (finished) return;
    finished = true;
    clearTimeout(timer);
    removeEventListener('message', onMsg);
    // Reveal the home screen before retiring the splash frame, avoiding a blank-frame flash.
    try { if (frame) frame.style.visibility = 'hidden'; } catch {}
    try { onDone?.(); } catch (error) { console.error('KoropeRun home-screen transition failed:', error); }
    setTimeout(() => { try { if (frame) frame.src = 'about:blank'; } catch {} }, 0);
  };

  const onMsg = (e) => {
    if (e.origin !== location.origin || !e.data) return;
    if (e.data.type === 'koperun-splash-done') finish();
  };

  // Register before checking iframe state or sending a start message.
  addEventListener('message', onMsg);

  if (!frame) { finish(); return; }

  try {
    if (frame.contentDocument?.body?.dataset?.splashDone === '1') { finish(); return; }
    frame.contentWindow?.postMessage({ type: 'koperun-splash-fast-start' }, location.origin);
  } catch {}

  // Recovery only; the normal path is the splash's own completion event.
  timer = setTimeout(finish, MAX_SPLASH_MS);
}
