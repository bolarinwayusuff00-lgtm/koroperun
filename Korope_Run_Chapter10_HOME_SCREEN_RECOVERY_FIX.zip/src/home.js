import { runSplash } from './splash.js';
const $ = (id) => document.getElementById(id);
const safeGet = (key, fallback='') => { try { const v=localStorage.getItem(key); return v === null ? fallback : v; } catch { return fallback; } };
const safeSet = (key, value) => { try { localStorage.setItem(key, String(value)); return true; } catch { return false; } };
export const PROFILE_KEY='koroperun_nickname', WALLET_KEY='koroperun_coin_wallet', NAIRA_BALANCE_KEY='koroperun_naira_balance', TOUR_KEY='koroperun_tour_completed';
const RUNS_KEY='koroperun_local_runs';
const items=[
 {id:'food',name:'NO FOOD FOR LAZY MAN',category:'Large slogan',price:100},
 {id:'god',name:'GOD Dey',category:'Small sticker',price:50},
 {id:'aluta',name:'ALUTA CONTINUA',category:'Large slogan',price:100},
 {id:'osogbo',name:'OSOGBO BOY',category:'Premium decal',price:200},
 {id:'nogree',name:'NO GREE FOR ANYBODY',category:'Premium decal',price:200},
 {id:'love',name:'ONE LOVE',category:'Small sticker',price:50}
];
let wallet=0, nairaBalance=0, unlocked=[], equipped='', purchaseBusy=false, startDrive=()=>{};
function readWallet(){const n=Number(safeGet(WALLET_KEY,'0')); return Number.isFinite(n)&&n>=0?Math.floor(n):0;}
function setWallet(n){wallet=Math.max(0,Math.floor(n));safeSet(WALLET_KEY,wallet);refreshWallet();}
function refreshWallet(){ $('walletBalance').textContent=wallet.toLocaleString(); $('garageBalance').textContent=wallet.toLocaleString(); document.dispatchEvent(new CustomEvent('koroperun-wallet',{detail:{balance:wallet}})); }
function panelHide(){['settingsPanel','garagePanel','marketsPanel'].forEach(id=>$(id)?.classList.add('hidden'));}
function readRuns(){try{const rows=JSON.parse(safeGet(RUNS_KEY,'[]'));return Array.isArray(rows)?rows.filter(r=>r&&Number.isFinite(Number(r.score))&&Number.isFinite(Number(r.time))):[];}catch{return [];}}
function renderLeaderboard(period='today'){const root=$('leaderboardRows');if(!root)return;const now=new Date();let start=new Date(now.getFullYear(),now.getMonth(),now.getDate());if(period==='week'){const day=(start.getDay()+6)%7;start.setDate(start.getDate()-day);}if(period==='month')start=new Date(now.getFullYear(),now.getMonth(),1);const rows=readRuns().filter(r=>Number(r.time)>=start.getTime()&&Number(r.time)<=now.getTime()).sort((a,b)=>Number(b.score)-Number(a.score)).slice(0,5);root.replaceChildren();if(!rows.length){const empty=document.createElement('p');empty.className='leaderboard-empty';empty.textContent='No runs yet for this period. Tap to drive and set the first score!';root.append(empty);return;}rows.forEach((run,i)=>{const row=document.createElement('div');row.className='leaderboard-row';const rank=document.createElement('span');rank.className='leaderboard-rank';rank.textContent=String(i+1).padStart(2,'0');const name=document.createElement('b');name.textContent=run.name||'Driver';const score=document.createElement('strong');score.textContent=Number(run.score).toLocaleString()+' pts';row.append(rank,name,score);root.append(row);});}
function recordRun(score,coins,cash){const runs=readRuns();runs.push({name:safeGet(PROFILE_KEY,'Driver')||'Driver',score:Number(score)||0,coins:Number(coins)||0,cash:Number(cash)||0,time:Date.now()});safeSet(RUNS_KEY,JSON.stringify(runs.slice(-250)));renderLeaderboard(document.querySelector('.leaderboard-tab.active')?.dataset.period||'today');}
function renderGarage(){const root=$('garageItems');root.replaceChildren();items.forEach(item=>{const owned=unlocked.includes(item.id),active=equipped===item.id;const card=document.createElement('article');card.className='garage-item';const preview=document.createElement('div');preview.className='decal-preview';preview.textContent=item.name;const title=document.createElement('h3');title.textContent=item.name;const meta=document.createElement('p');meta.textContent=`${item.category} · ${item.price} coins`;const btn=document.createElement('button');btn.textContent=active?'UNEQUIP':owned?'EQUIP':`BUY · ${item.price} COINS`;btn.addEventListener('click',()=>{if(purchaseBusy)return;purchaseBusy=true;try{if(!unlocked.includes(item.id)){if(wallet<item.price){$('garageNotice').textContent='Not enough coins yet. Keep driving to earn more.';return;}setWallet(wallet-item.price);unlocked.push(item.id);safeSet('koroperun_garage_unlocked',JSON.stringify(unlocked));$('garageNotice').textContent=`Unlocked ${item.name}!`;}if(equipped===item.id)equipped='';else equipped=item.id;safeSet('koroperun_garage_equipped',equipped);document.dispatchEvent(new CustomEvent('koroperun-decal',{detail:{text:equipped?(items.find(x=>x.id===equipped)?.name||''):''}}));$('garageNotice').textContent=equipped?`${item.name} equipped on your korope.`:`${item.name} unequipped.`;renderGarage();}finally{purchaseBusy=false;}});card.append(preview,title,meta,btn);root.append(card);});}
export function initHomeUI({onStartDrive}){
 startDrive=onStartDrive||(()=>{});wallet=readWallet();nairaBalance=readNairaBalance();try{unlocked=JSON.parse(safeGet('koroperun_garage_unlocked','[]'));if(!Array.isArray(unlocked))unlocked=[];}catch{unlocked=[];}equipped=safeGet('koroperun_garage_equipped','');refreshWallet();
 let homeRevealed=false;
 const revealHome=()=>{
   if(homeRevealed)return;
   homeRevealed=true;
   const loading=$('loadingScreen'), home=$('homeScreen');
   // Reveal home first, then remove the overlay to avoid a blank frame during handoff.
   if (window.__koropeRevealHome) window.__koropeRevealHome();
   else {
     home.classList.remove('hidden');
     home.setAttribute('aria-hidden','false');
     loading.classList.add('hidden');
     loading.setAttribute('aria-hidden','true');
   }
   const nick=safeGet(PROFILE_KEY,'');
   $('nicknameInput').value=nick;
   if(!nick){$('nicknameNotice').textContent='Choose a nickname for your player profile.';}
 };
 runSplash(revealHome);
 // If startup JS has a recoverable error elsewhere, never leave the player trapped on a blank screen.
 window.addEventListener('error',()=>{if(!homeRevealed)revealHome();},{once:true});
 window.addEventListener('unhandledrejection',()=>{if(!homeRevealed)revealHome();},{once:true});
 $('saveNickname').addEventListener('click',()=>{const name=$('nicknameInput').value.trim();if(name.length<2){$('nicknameNotice').textContent='Nickname must be at least 2 characters.';return;}if(name.length>18){$('nicknameNotice').textContent='Nickname must be 18 characters or fewer.';return;}safeSet(PROFILE_KEY,name);$('nicknameInput').value=name;$('nicknameNotice').textContent=`Welcome, ${name}!`;});
 $('nicknameInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('saveNickname').click();});
 $('settingsBtn').addEventListener('click',()=>{$('gameSoundToggle').checked=safeGet('koroperun_game_sound','1')!=='0';$('musicToggle').checked=safeGet('koroperun_music','0')==='1';$('settingsNicknameInput').value=safeGet(PROFILE_KEY,'');$('settingsNairaBalance').textContent=formatNaira(nairaBalance);$('settingsPanel').classList.remove('hidden');});
 $('saveSettingsNickname').addEventListener('click',()=>{const name=$('settingsNicknameInput').value.trim();if(name.length<2){$('settingsNicknameNotice').textContent='Nickname must be at least 2 characters.';return;}if(name.length>18){$('settingsNicknameNotice').textContent='Nickname must be 18 characters or fewer.';return;}safeSet(PROFILE_KEY,name);$('nicknameInput').value=name;$('settingsNicknameNotice').textContent='Nickname updated.';});
 $('settingsNicknameInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('saveSettingsNickname').click();});
 $('gameSoundToggle').addEventListener('change',e=>{safeSet('koroperun_game_sound',e.target.checked?'1':'0');document.dispatchEvent(new CustomEvent('koroperun-game-sound',{detail:{enabled:e.target.checked}}));});
 $('musicToggle').addEventListener('change',e=>{safeSet('koroperun_music',e.target.checked?'1':'0');});
 $('garageBtn').addEventListener('click',()=>{$('garageNotice').textContent='';renderGarage();$('garagePanel').classList.remove('hidden');});$('garageBackBtn').addEventListener('click',()=>panelHide());
 $('marketsBtn').addEventListener('click',()=>$('marketsPanel').classList.remove('hidden'));
 $('leaderboardBtn').addEventListener('click',()=>{$('leaderboardPanel').classList.remove('hidden');renderLeaderboard(document.querySelector('.leaderboard-tab.active')?.dataset.period||'today');});
 document.querySelectorAll('[data-close-panel]').forEach(btn=>btn.addEventListener('click',()=>{panelHide();$('leaderboardPanel')?.classList.add('hidden');}));
 $('tapDriveBtn').addEventListener('click',()=>{
   const name=$('nicknameInput').value.trim();
   if(name.length<2){$('nicknameNotice').textContent='Save a nickname (at least 2 characters) before driving.';$('nicknameInput').focus();return;}
   safeSet(PROFILE_KEY,name);panelHide();
   try {
     startDrive();
     $('homeScreen').classList.add('hidden');
   } catch(error) {
     console.error('KoropeRun could not start gameplay:',error);
     $('homeScreen').classList.remove('hidden');
     $('nicknameNotice').textContent='The game could not start. Please tap Tap to Drive again.';
   }
 });
 document.querySelectorAll('.leaderboard-tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.leaderboard-tab').forEach(other=>{const active=other===btn;other.classList.toggle('active',active);other.setAttribute('aria-selected',String(active));});renderLeaderboard(btn.dataset.period);}));renderLeaderboard('today');
 const gasButton=document.querySelector('[data-hold=gas]');gasButton?.addEventListener('pointerdown',()=>{if(safeGet('koroperun_gas_tip_seen','')==='1')return;safeSet('koroperun_gas_tip_seen','1');$('firstDriveTip').classList.remove('hidden');setTimeout(()=>$('firstDriveTip').classList.add('hidden'),10000);});$('dismissDriveTip').addEventListener('click',()=>$('firstDriveTip').classList.add('hidden'));
 document.addEventListener('koroperun-wallet',e=>{wallet=Number(e.detail.balance)||0;nairaBalance=Number(e.detail.nairaBalance)||0;$('walletBalance').textContent=wallet.toLocaleString();$('garageBalance').textContent=wallet.toLocaleString();if($('nairaBalance'))$('nairaBalance').textContent=formatNaira(nairaBalance);});
 document.addEventListener('koroperun-record-run',e=>recordRun(e.detail.score,e.detail.coins,e.detail.cash));
}
export function addEarnedCoins(amount){if(!Number.isFinite(amount)||amount<=0)return wallet;setWallet(wallet+amount);return wallet;}
export function getWallet(){return wallet;}

export function addEarnedNaira(amount){return addNairaBalance(amount);}
export function getNairaBalance(){return nairaBalance;}
