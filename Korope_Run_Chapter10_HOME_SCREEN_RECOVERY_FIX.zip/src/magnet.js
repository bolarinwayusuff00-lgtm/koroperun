import * as THREE from 'three';

// Chapter 5: purple magnet power-up.
// - ONE pooled pickup box (built once, reused forever: no allocation or new GPU resources while playing).
// - Much rarer than coins (~9 m apart) and cash bundles (110-200 m apart): one box per 400-700 m.
// - What the magnet does (pulling pickups in, the countdown) lives in world.js / hud.js; this file only knows the box and the numbers.
// - Collecting a box while the magnet is already running REFRESHES the timer back to the full duration (it never stacks or adds).

export const MAGNET_DURATION = 8; // seconds (default). Change here, pass { magnetDuration } to createWorld, or call world.setMagnetDuration(n).

export const MAGNET = {
  GAP_MIN: 400, GAP_MAX: 700,       // metres between boxes (cash: 110-200, coins: ~9)
  FIRST_MIN: 250, FIRST_MAX: 400,   // first box after a (re)start is this far ahead
  SLOTS: [-4, -2, 0, 2, 4],         // x positions (lanes and line gaps), all reachable
  RADIUS_X: 1.6, RADIUS_Z: 2.5,     // pickup box (a touch more forgiving than cash, so it cannot be skipped at top speed)
  Y: 1.25, BOB: 0.12, BOB_SPEED: 2.2, SPIN: 1.6, // gentle bob and slow spin so the symbol shows on every side
  PASSED: 12,                       // a box this far behind the korope is recycled to the front
  RANGE: 16,                        // metres around the korope in which coins/cash are attracted
  PULL_MIN: 14, PULL_MAX: 50,       // m/s pull speed: gentle at the edge of the range, firm when close (never a jump: see attract())
  PULL_MAX_STEP: 2.5,               // hard cap per frame (m), however long the frame was
};

const seeded = (seed) => () => (seed = (seed * 16807) % 2147483647) / 2147483647;
export const validDuration = (n) => Number.isFinite(n) && n > 0;

// Purple face with a blocky red/white horseshoe magnet (rects only, so it also works with the tiny canvas mocks used in tests).
function faceTexture() {
  try {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = 128; c.height = 128;
    const x = c.getContext('2d'); if (!x) return null;
    x.fillStyle = '#c9a2ff'; x.fillRect(0, 0, 128, 128);
    x.fillStyle = '#7a2cf0'; x.fillRect(6, 6, 116, 116);
    x.fillStyle = '#e53935'; // red U: two legs and the bend
    x.fillRect(28, 30, 22, 52); x.fillRect(78, 30, 22, 52); x.fillRect(28, 82, 72, 22); x.fillRect(38, 92, 52, 22);
    x.fillStyle = '#f5f5f5'; x.fillRect(28, 30, 22, 16); x.fillRect(78, 30, 22, 16); // silver pole tips
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  } catch (e) { return null; }
}

export class MagnetBox {
  // opts: scene (required), random (0..1 generator, for tests), avoid(x, z) -> true when a spot is already taken
  constructor(scene, opts = {}) {
    this.scene = scene;
    this.random = opts.random || seeded((Date.now() % 2147483646) + 1); // own clock-seeded generator: it never touches Math.random, so the coin/traffic layout is exactly what it was in Chapter 4
    this.avoid = opts.avoid || null;
    this.onCollect = null;     // (x, y, z) fired exactly once per collected box
    this.collected = 0;
    this.lastSlot = -1;
    this.disposed = false;

    const plain = new THREE.MeshLambertMaterial({ color: 0x8a3dff, emissive: 0x3a0f8a });
    const face = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x4a1aa8, map: faceTexture() });
    if (!face.map) face.color.set(0x9a52ff);
    const red = new THREE.MeshLambertMaterial({ color: 0xe53935, emissive: 0x6a1010 });
    const tip = new THREE.MeshLambertMaterial({ color: 0xf5f5f5, emissive: 0x555555 });
    this.mats = [plain, face, red, tip];
    this.boxGeo = new THREE.BoxGeometry(1.3, 1.3, 1.3);
    this.bendGeo = new THREE.TorusGeometry(0.42, 0.14, 8, 14, Math.PI);
    this.legGeo = new THREE.BoxGeometry(0.28, 0.5, 0.28);
    this.tipGeo = new THREE.BoxGeometry(0.3, 0.14, 0.3);
    this.geos = [this.boxGeo, this.bendGeo, this.legGeo, this.tipGeo];

    // A real 3D horseshoe magnet on top of the box (so the symbol is visible from above and far away), plus the printed symbol on the four sides.
    const g = new THREE.Group();
    g.add(new THREE.Mesh(this.boxGeo, [face, face, plain, plain, face, face]));
    const mag = new THREE.Group();
    mag.add(new THREE.Mesh(this.bendGeo, red));
    for (const s of [-1, 1]) {
      const leg = new THREE.Mesh(this.legGeo, red); leg.position.set(s * 0.42, -0.25, 0); mag.add(leg);
      const cap = new THREE.Mesh(this.tipGeo, tip); cap.position.set(s * 0.42, -0.57, 0); mag.add(cap);
    }
    mag.position.y = 0.65 + 0.57; mag.scale.setScalar(0.85); g.add(mag);
    g.position.set(0, MAGNET.Y, -9999); g.rotation.order = 'YXZ'; scene.add(g);
    this.g = g;
    this.reset(0);
  }

  #gap() { return MAGNET.GAP_MIN + this.random() * (MAGNET.GAP_MAX - MAGNET.GAP_MIN); }

  #place(z) {
    let x = 0;
    for (let tries = 0; tries < 6; tries++) {
      let slot = Math.floor(this.random() * MAGNET.SLOTS.length);
      if (slot === this.lastSlot) slot = (slot + 1 + Math.floor(this.random() * (MAGNET.SLOTS.length - 1))) % MAGNET.SLOTS.length;
      x = MAGNET.SLOTS[slot]; this.lastSlot = slot;
      if (!this.avoid || !this.avoid(x, z)) break;
      z -= 4;
    }
    this.g.position.set(x, MAGNET.Y, z); this.g.visible = true;
  }

  // Fresh layout ahead of pz (PLAY / RESTART): clears the counter and re-places the box. No leftovers.
  reset(pz = 0) {
    this.collected = 0; this.lastSlot = -1;
    this.#place(pz - MAGNET.FIRST_MIN - this.random() * (MAGNET.FIRST_MAX - MAGNET.FIRST_MIN));
  }

  // Call every frame. Returns true on the frame the box is collected (never when collect=false).
  update(dt, px, pz, time, collect = true) {
    const p = this.g.position;
    this.g.rotation.y = time * MAGNET.SPIN; p.y = MAGNET.Y + Math.sin(time * MAGNET.BOB_SPEED) * MAGNET.BOB;
    if (p.z - pz > MAGNET.PASSED) { this.#place(pz - 60 - this.#gap()); return false; } // missed: back to the front
    if (collect && Math.abs(p.x - px) < MAGNET.RADIUS_X && Math.abs(p.z - pz) < MAGNET.RADIUS_Z) {
      const x = p.x, y = p.y, z = p.z;
      this.#place(pz - 60 - this.#gap()); // moved far ahead at once: it can never pay twice
      this.collected++;
      if (this.onCollect) this.onCollect(x, y, z);
      return true;
    }
    return false;
  }

  dispose() {
    if (this.disposed) return; this.disposed = true;
    this.scene.remove(this.g);
    for (const geo of this.geos) geo.dispose();
    for (const m of this.mats) { if (m.map) m.map.dispose(); m.dispose(); }
  }
}

// Pull one point (x, z) towards (px, pz) when it is within MAGNET.RANGE. Smooth: the step is the pull speed times dt, capped per frame, and never longer
// than the remaining distance (so it cannot overshoot or jump). Returns true if the point moved. `pt` is any object with numeric x and z.
export function attract(pt, px, pz, dt) {
  const dx = px - pt.x, dz = pz - pt.z, d = Math.hypot(dx, dz);
  if (d >= MAGNET.RANGE || d < 1e-6) return false;
  const k = 1 - d / MAGNET.RANGE;                                 // 0 at the edge of the range, 1 on top of the korope
  const step = Math.min(d, MAGNET.PULL_MAX_STEP, (MAGNET.PULL_MIN + (MAGNET.PULL_MAX - MAGNET.PULL_MIN) * k * k) * dt);
  pt.x += (dx / d) * step; pt.z += (dz / d) * step;
  return true;
}
