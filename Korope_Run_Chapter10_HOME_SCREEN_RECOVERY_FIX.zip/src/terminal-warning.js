import { PICKUP } from './route.js';

// Chapter 8: the old top-of-screen text alert is replaced by one animated down arrow (see #terminalArrow).
// This module only decides WHEN the arrow is visible (pure logic, no DOM, no timers). The bounce is a CSS animation on an element built once in index.html.
// Visible only while: the run is active, the Terminal pickup is still pending, and the bus is inside the approach window
// [PICKUP.start - APPROACH, PICKUP.start). It never stops the bus or boards anyone; Journey owns all of that.
export const TERMINAL_ARROW_APPROACH = 200;                                   // metres of route before the green bay
export const TERMINAL_ARROW_START = PICKUP.start - TERMINAL_ARROW_APPROACH;   // approach window opens
export const TERMINAL_ARROW_END = PICKUP.start;                               // reaching the bay hides it

export class TerminalArrow {
  constructor({ start = TERMINAL_ARROW_START, end = TERMINAL_ARROW_END } = {}) { this.start = start; this.end = end; this.visible = false; }
  reset() { this.visible = false; }
  // routeDistance: metres along the route; pickup: Journey.pickup ('pending' | 'done' | 'missed'); playing: state === 'playing'.
  // Returns true/false only when visibility CHANGES (so callers touch the DOM only then), otherwise null.
  update(routeDistance, pickup = 'pending', playing = true) {
    const d = Number(routeDistance);
    const v = !!playing && pickup === 'pending' && Number.isFinite(d) && d >= this.start && d < this.end;
    if (v === this.visible) return null;
    this.visible = v; return v;
  }
}
