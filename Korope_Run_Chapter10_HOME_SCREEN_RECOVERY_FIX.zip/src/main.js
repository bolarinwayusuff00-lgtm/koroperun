import * as THREE from 'three';
import { createWorld } from './world.js';
import { Korope } from './vehicle.js';
import { Controls } from './controls.js';
import { Hud } from './hud.js';
import { Effects } from './effects.js';
import { Sound } from './audio.js';
import { Journey, PICKUP, PICKUP_MAX_SPEED, inPickupZone } from './route.js';
import { TerminalArrow } from './terminal-warning.js';
import { Minimap } from './minimap.js';
import { TripPanel } from './trippanel.js';
import { CASH_REWARD, formatNaira } from './cash.js';
import { MAGNET, MAGNET_DURATION } from './magnet.js';
import { initHomeUI, addEarnedCoins, addEarnedNaira, getNairaBalance } from './home.js';

const canvas = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.outputColorSpace = THREE.SRGBColorSpace; // keep canvas textures and pickup artwork colour-consistent
let appliedPixelRatio = 0;
function targetPixelRatio() {
  const coarse = window.matchMedia?.('(pointer: coarse)').matches || innerWidth < 680;
  return Math.min(window.devicePixelRatio || 1, coarse ? 1.5 : 2); // mobile fill-rate guard; desktop keeps the sharper 2x cap
}

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 400);
const world = createWorld(scene, { cashReward: CASH_REWARD, magnetDuration: MAGNET_DURATION }); // Chapter 4: reward per cash bundle (src/cash.js). Chapter 5: magnet duration in seconds (src/magnet.js)
const bus = new Korope(); scene.add(bus.group);
const controls = new Controls();
const hud = new Hud();
const fx = new Effects(scene, camera);
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const SHAKE_SCALE = reduceMotion ? 0.3 : 1, SHAKE_MAX = 0.8; // camera shake is always capped
let touching = false, kick = 0, roll = 0; // touching: in contact with traffic (feedback fires once per contact); kick: FOV punch on impact; roll: smoothed camera lean
const sound = new Sound();
// Milestone 6A: route/journey. Passengers and fare live in `journey` and are separate from coins, score and best score.
const journey = new Journey(), minimap = new Minimap(document.getElementById('minimap')), tripPanel = new TripPanel(minimap);
let routeOriginZ = 0;
let boardingFarePending = false;
const terminalArrow = new TerminalArrow(); // decides when the Terminal approach arrow shows (pure logic)
function startTrip() { // new trip: the route starts where the bus is now (the bus keeps its world z across restarts)
  routeOriginZ = bus.z; terminalArrow.reset(); hud.showTerminalArrow(false); world.setRouteOrigin(routeOriginZ); journey.reset(); world.setBoarded(0); boardingFarePending = false; world.setPickupClear(true); hud.clearTrip();
  world.resetMagnet(bus.z); hud.updateMagnet(0); fx.magnetAura(0, bus.x, bus.z, 0); // Chapter 5: magnet off and a fresh box ahead on every PLAY/RESTART
  cash = 0; world.resetCash(bus.z); hud.updateCash(0); // fresh cash layout ahead of the bus: no leftover or duplicate bundles after a restart
  hud.updateTrip(journey.objective(0), 0, journey.capacity, 0); minimap.draw(0, bus.x, journey);
}
function tripHint(d) { // one clear instruction for the current situation
  if (journey.pickup === 'pending') {
    if (d < PICKUP.start - 250) return hud.setHint('');
    if (d < PICKUP.start) return hud.setHint('Terminal at Lamenco ahead \u2013 green bay on the LEFT');
    if (!inPickupZone(d, bus.x)) return hud.setHint('Move into the green bay (left side)');
    if (bus.speed > PICKUP_MAX_SPEED) return hud.setHint('Slow right down and stop to board');
    return hud.setHint('Boarding\u2026 hold still', journey.holdProgress);
  }
  if (journey.stage === 'arrived') return hud.setHint('Agunbelewo reached with ' + journey.passengers + ' passengers');
  if (journey.pickup === 'missed' && d < PICKUP.end + 120) return hud.setHint('Pickup missed \u2013 no passengers on board');
  if (journey.pickup === 'done' && d < PICKUP.end + 90) return hud.setHint('Head for Agunbelewo');
  return hud.setHint('');
}
// One collected coin = +1 coin (coins) and +COIN_POINTS score points (score). The popup shows the coin count only.
world.setCoinHandler((x, y, z) => { sound.coin(); /* first: a wallet/effects/DOM hiccup can never swallow the pickup sound */ addEarnedCoins(1); fx.coin(x, y, z, '+1 coin'); hud.pulseCoins(); });
// Chapter 4: one collected bundle = +CASH_REWARD naira in the cash counter only (not coins, score or fares). The handler fires once per bundle.
world.setCashHandler((x, y, z, amount) => { fx.cash(x, y, z, '+' + formatNaira(amount) + ' CASH'); hud.pulseCash(); sound.cash(); });
// Chapter 5: one collected purple box starts the magnet (or refreshes it to the full duration if it is already on). Nothing is added to coins, cash, score or fares.
world.setMagnetHandler((x, y, z) => { fx.magnet(x, y, z, 'MAGNET ' + Math.ceil(world.magnetDuration) + 's'); hud.pulseMagnet(); sound.magnet(); });
const soundBtn = document.getElementById('soundBtn');
const showSound = () => { soundBtn.textContent = sound.on ? '\u{1F50A}' : '\u{1F507}'; soundBtn.setAttribute('aria-pressed', String(!sound.on)); soundBtn.setAttribute('aria-label', sound.on ? 'Sound on, tap to mute' : 'Sound off, tap to unmute'); };
showSound();
soundBtn.addEventListener('click', () => { sound.toggle(); try { localStorage.setItem('koroperun_game_sound', sound.on ? '1' : '0'); } catch {} showSound(); });
addEventListener('keydown', (e) => { if (e.code === 'KeyM' && !e.repeat) { sound.toggle(); showSound(); updatePauseSound(); } });

let state = 'menu'; // 'menu' | 'playing' | 'paused' | 'over'
let coins = 0, cash = 0, runRecorded = false; // cash: naira from cash bundles (Chapter 4), reset on every PLAY/RESTART
const CRASH_CLOSING = 16; // m/s closing speed on a head-on/rear-end hit that ends the run
let shake = 0;
// Score = 1 point per 10 m driven + COIN_POINTS score points per coin (coins and score are separate counters). Best score is persisted; bad/missing values fall back to 0.
const COIN_POINTS = 25, BEST_KEY = 'koroperun_best_score';
const RAMP_M = 5000; // distance over which difficulty ramps from 0 to 1 (then stays capped)
let score = 0, bestScore = 0, bestDist = 0;
const loadNum = (k) => { try { const n = Number(localStorage.getItem(k)); return Number.isFinite(n) && n >= 0 ? n : 0; } catch (e) { return 0; } };
const saveNum = (k, n) => { try { localStorage.setItem(k, String(Math.floor(n))); } catch (e) { /* storage unavailable */ } };
bestScore = loadNum(BEST_KEY); bestDist = loadNum('koroperun_best_m');
const baseFov = () => (innerWidth / innerHeight < 1 ? 75 : 60); // wider view on portrait phones

function resize() {
  const ratio = targetPixelRatio();
  if (ratio !== appliedPixelRatio) { renderer.setPixelRatio(ratio); appliedPixelRatio = ratio; }
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

function recordCurrentRun(){if(runRecorded)return;runRecorded=true;document.dispatchEvent(new CustomEvent('koroperun-record-run',{detail:{score,coins,cash}}));}
function updatePauseCard(){
  let wallet=0; try { wallet=Math.max(0,Math.floor(Number(localStorage.getItem('koroperun_coin_wallet'))||0)); } catch {}
  document.getElementById('pauseCoins').textContent=wallet.toLocaleString();
  document.getElementById('pauseCash').textContent=formatNaira(getNairaBalance());
}
function setPaused(p) {
  if (state === 'menu' || state === 'over') return;
  state = p ? 'paused' : 'playing';
  if (p) { updatePauseCard(); updatePauseSound(); sound.pauseAudio(); terminalArrow.reset(); hud.showTerminalArrow(false); } // pause cuts one-shots + engine hum only; saved mute/Game Sound are untouched
  else sound.unlock(); // Continue is a user gesture: wake a suspended/interrupted AudioContext. Never changes the on/off preference.
  hud.showPause(p); controls.reset();
}
function startGame(){
  sound.unlock(); sound.silence(); coins=0; cash=0; score=0; runRecorded=false; touching=false; shake=0; kick=0; fx.reset(); hud.clearFlash(); bus.restart(); world.setDifficulty(0); world.resetTraffic(bus.z); controls.reset(); hud.hideGameOver(); document.getElementById('pauseScreen').classList.add('hidden'); document.getElementById('overScreen').classList.add('hidden'); document.getElementById('homeScreen').classList.add('hidden'); document.getElementById('startScreen').classList.add('hidden'); state='playing'; hud.showGame(); tripPanel.layout(); startTrip();
}
initHomeUI({ onStartDrive: startGame });
hud.updateBalance(getNairaBalance());
document.addEventListener('koroperun-naira-balance', e => hud.updateBalance(Number(e.detail.balance) || 0));
document.addEventListener('koroperun-game-sound', e => { if (!e.detail.enabled && sound.on) { sound.toggle(); showSound(); } else if (e.detail.enabled && !sound.on) { sound.toggle(); showSound(); } });
document.addEventListener('koroperun-decal', e => { if (typeof bus.setDecal === 'function') bus.setDecal(e.detail.text); });
try { const savedDecal = localStorage.getItem('koroperun_garage_equipped'); const savedItems = JSON.parse(localStorage.getItem('koroperun_garage_unlocked') || '[]'); if (savedDecal && savedItems.includes(savedDecal)) { const names = {food:'NO FOOD FOR LAZY MAN',god:'GOD Dey',aluta:'ALUTA CONTINUA',osogbo:'OSOGBO BOY',nogree:'NO GREE FOR ANYBODY',love:'ONE LOVE'}; bus.setDecal(names[savedDecal] || ''); } } catch {}
document.getElementById('playBtn').addEventListener('click', startGame);
document.getElementById('restartBtn').addEventListener('click', () => {
  sound.unlock(); sound.silence();
  coins = 0; cash = 0; score = 0; runRecorded = false; touching = false; shake = 0; kick = 0; fx.reset(); hud.clearFlash(); bus.restart(); world.setDifficulty(0); world.resetTraffic(bus.z); controls.reset(); hud.hideGameOver(); startTrip(); state = 'playing';
});
document.getElementById('pauseBtn').addEventListener('click', () => setPaused(true));
document.getElementById('resumeBtn').addEventListener('click', () => setPaused(false));
document.getElementById('continueBtn').addEventListener('click', () => setPaused(false));
document.getElementById('homeBtn').addEventListener('click', () => { if(state==='over')return; recordCurrentRun(); state='menu'; terminalArrow.reset(); hud.showTerminalArrow(false); controls.reset(); fx.reset(); hud.showPause(false); document.getElementById('hud').classList.add('hidden'); document.getElementById('touch').classList.add('hidden'); document.getElementById('trip').classList.add('hidden'); document.getElementById('firstDriveTip').classList.add('hidden'); document.getElementById('homeScreen').classList.remove('hidden'); });
const pauseSoundBtn=document.getElementById('pauseSoundBtn');
function updatePauseSound(){document.getElementById('pauseSoundIcon').textContent=sound.on?'🔊':'🔇';document.getElementById('pauseSoundLabel').textContent=sound.on?'SOUND ON':'SOUND OFF';}
pauseSoundBtn.addEventListener('click',()=>{sound.toggle();try{localStorage.setItem('koroperun_game_sound',sound.on?'1':'0');}catch{}showSound();updatePauseSound();});
controls.onPause = () => { if (state === 'playing') setPaused(true); else if (state === 'paused') setPaused(false); };
document.addEventListener('visibilitychange', () => { if (document.hidden && state === 'playing') setPaused(true); if (document.hidden) sound.pauseAudio(); else sound.resume(); });
// Any real tap/key re-wakes a context the browser suspended or interrupted (phone call, screen lock, tab switch). Registered once; cheap no-op while running.
['pointerup', 'touchend', 'click', 'keydown'].forEach((ev) => addEventListener(ev, () => sound.resume(), { capture: true, passive: true }));

const clock = new THREE.Clock();
const camTarget = new THREE.Vector3(), look = new THREE.Vector3();

function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05), t = clock.elapsedTime;
  { const active = state === 'playing'; if (controls.enabled !== active) controls.setEnabled(active); } // gameplay input only while actually playing
  controls.update(dt, bus.x);

  // Chapter 8: freeze the simulation outside active driving. Previously the bus/traffic/chunks
  // continued updating behind Home and Game Over even though pickup collection was disabled.
  // Paused/menu/game-over screens now keep a stable scene; only crash particles are allowed to fade.
  if (state === 'playing') {
    bus.update(dt, controls, state === 'playing');
    const got = world.update(dt, bus.x, bus.z, t, state === 'playing');
    fx.update(dt);
    sound.engine(bus.speed, true, dt);

    coins += got; cash += world.cashGot;
    // Gentle, capped progression: higher top speed and slightly tighter traffic gaps as the run goes on.
    const level = Math.min(1, bus.distance / RAMP_M);
    bus.MAX = 32 + 8 * level; world.setDifficulty(level);
    score = Math.floor(bus.distance / 10) + coins * COIN_POINTS;
    const d = routeOriginZ - bus.z;
    const ev = journey.update(dt, d, bus.x, bus.speed);
    terminalArrow.update(d, journey.pickup, true); // approach window only; hides on reaching the bay, boarding, missing it
    if (ev === 'boarded') { world.setBoarded(journey.passengers, bus.x, bus.z); world.setPickupClear(false); boardingFarePending = true; }
    if (boardingFarePending && world.boardingDone) {
      boardingFarePending = false;
      const earned = addEarnedNaira(journey.fare);
      hud.updateBalance(earned); hud.pulseBalance();
      sound.board();
      const fareText = '\u20A6' + journey.fare.toLocaleString('en-US');
      hud.celebrate(journey.passengers + ' passengers boarded!', '+' + fareText + ' fare');
      fx.coin(bus.x, 2.4, bus.z, '+' + fareText);
    }
    if (ev === 'missed') world.setPickupClear(false);
    else if (ev === 'arrived') hud.celebrate('Agunbelewo!', journey.passengers + ' passengers \u00B7 \u20A6' + journey.fare.toLocaleString('en-US'));
    hud.updateTrip(journey.objective(d), journey.passengers, journey.capacity, world.boardingDone ? journey.fare : 0); minimap.draw(d, bus.x, journey); tripHint(d);
    const h = bus.jumpHeight > 0.72 ? null : world.collide(bus.x, bus.z);
    let bumpSnd = false;
    const fresh = !!h && !touching; touching = !!h; // true only on the first frame of a contact
    if (h) {
      if (fresh) { // light bump feedback, once per contact (a fatal crash upgrades it below)
        shake = Math.max(shake, 0.3 * SHAKE_SCALE); hud.flash(false); kick = 1.5; bumpSnd = true;
        fx.hit((bus.x + h.v.x) / 2, 1, (bus.z + h.v.z) / 2, false);
      }
      if (h.oz < h.ox) { // front/rear contact: stop the bus at the other vehicle's bumper
        const closing = bus.dir > 0 ? bus.speed - h.v.speed : 0; // reversing (max ~21 km/h) is a bump, never a fatal crash
        bus.z = h.v.z + Math.sign(h.dz || 1) * (2.5 + h.v.hl);
        if (bus.dir < 0) bus.speed = 0;
        else if (closing > CRASH_CLOSING) {
          state = 'over'; world.clearMagnet(); bumpSnd = false; // a crash ends the magnet at once
          sound.crash(); bus.speed *= 0.2; controls.reset(); // fatal crash: runs once because state leaves 'playing'
          shake = SHAKE_MAX * SHAKE_SCALE; kick = 5; hud.flash(true);
          fx.hit((bus.x + h.v.x) / 2, 1.2, bus.z - Math.sign(h.dz || 1) * 0.5, true);
          recordCurrentRun();
          const isBest = score > bestScore;
          if (isBest) { bestScore = score; saveNum(BEST_KEY, bestScore); }
          if (bus.distance > bestDist) { bestDist = bus.distance; saveNum('koroperun_best_m', bestDist); }
          hud.showGameOver(score, coins, bus.distance, bestScore, isBest, cash);
        } else bus.speed = Math.min(bus.speed, h.v.speed * 0.9);
      } else { // side swipe: push apart and scrub speed
        bus.x += Math.sign(h.dx || 1) * h.ox; bus.speed *= 1 - 3 * dt; bus.yaw = Math.sign(h.dx || 1) * 0.1;
      }
    }
    if (bumpSnd) sound.bump();
    hud.update(bus.speed, bus.distance, coins, score, bus.dir < 0); hud.updateCash(cash); hud.updateBalance(getNairaBalance());
    hud.updateMagnet(world.magnetLeft); fx.magnetAura(world.magnetLeft, bus.x, bus.z, t, MAGNET.RANGE);
  } else {
    sound.engine(0, false, dt);
    if (state === 'over') fx.update(dt); // let crash debris finish while freezing traffic/world/gameplay
  }

  // Arrow follows the state every frame, but the DOM is touched only when it changes.
  if (state !== 'playing') terminalArrow.reset();
  hud.showTerminalArrow(terminalArrow.visible);
  // Chase camera: behind and above, eased; FOV opens up with speed
  const k = THREE.MathUtils.clamp(bus.speed / Math.max(1, bus.MAX), 0, 1);
  camTarget.set(bus.x * 0.7, 4.2 + k * 0.6, bus.z + 9.5 + k * 2);
  camera.position.lerp(camTarget, Math.min(1, 6 * dt));
  look.set(bus.x * 0.9 + bus.yaw * -2, 1.6, bus.z - 9); camera.lookAt(look); // look slightly into the turn
  roll += (bus.yaw * 0.15 - roll) * Math.min(1, 5 * dt); camera.rotateZ(roll); // subtle steering lean (max ~3 deg)
  shake = Math.min(SHAKE_MAX, Math.max(shake * Math.max(0, 1 - 6 * dt), state === 'playing' ? bus.edge * 0.1 : 0));
  kick *= Math.max(0, 1 - 7 * dt);
  if (shake > 0.002 && state === 'playing') { camera.position.x += (Math.random() - 0.5) * shake; camera.position.y += (Math.random() - 0.5) * shake; }
  camera.fov += (baseFov() + k * 12 + kick - camera.fov) * Math.min(1, 3 * dt); camera.updateProjectionMatrix();
  renderer.render(scene, camera);
}
loop();
