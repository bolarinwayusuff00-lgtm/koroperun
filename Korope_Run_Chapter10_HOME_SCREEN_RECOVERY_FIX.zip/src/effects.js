import * as THREE from 'three';

// Milestone 4: tiny pooled effects. Everything is allocated once up-front (no per-frame allocation, no external assets).
// - 3D sparks (gold sparkle on coin pickup, grey/orange debris on impact): shared geometry, shrink-to-vanish.
// - DOM floaters ("+25") from a small fixed pool, positioned by projecting the pickup point to the screen.
const POOL = 48, FLOATERS = 4, CASH_FLOATERS = 2;

export class Effects {
  constructor(scene, camera) {
    this.camera = camera;
    this.geo = new THREE.BoxGeometry(0.16, 0.16, 0.16);
    this.gold = new THREE.MeshBasicMaterial({ color: 0xffd84a });
    this.debris = new THREE.MeshBasicMaterial({ color: 0xff9b3d });
    this.grey = new THREE.MeshBasicMaterial({ color: 0x8b8f96 });
    this.paper = new THREE.MeshBasicMaterial({ color: 0x6fe39a }); // Chapter 4: cash sparkle
    this.parts = [];
    for (let i = 0; i < POOL; i++) {
      const m = new THREE.Mesh(this.geo, this.gold); m.visible = false; scene.add(m);
      this.parts.push({ m, vx: 0, vy: 0, vz: 0, life: 0, max: 1, size: 1, g: 0 });
    }
    this.next = 0;
    this.tmp = new THREE.Vector3();
    this.floaters = []; this.fnext = 0;
    for (let i = 0; i < FLOATERS; i++) {
      const el = document.createElement('div'); el.className = 'floater'; el.setAttribute('aria-hidden', 'true');
      document.body.appendChild(el); this.floaters.push(el);
    }
    // Chapter 4: cash notices have their own small pool so a run of coins can never overwrite them.
    // Chapter 5: purple sparks, one notice element of its own, and the aura (two flat transparent meshes built once, visible only while the magnet is on).
    this.violet = new THREE.MeshBasicMaterial({ color: 0xb06cff });
    this.magnetFloater = document.createElement('div'); this.magnetFloater.className = 'floater magnet'; this.magnetFloater.setAttribute('aria-hidden', 'true');
    document.body.appendChild(this.magnetFloater);
    this.auraGeo = new THREE.CircleGeometry(2.4, 24); this.auraGeo.rotateX(-Math.PI / 2);
    this.ringGeo = new THREE.RingGeometry(0.94, 1, 40); this.ringGeo.rotateX(-Math.PI / 2);
    this.auraMat = new THREE.MeshBasicMaterial({ color: 0x9b4dff, transparent: true, opacity: 0.25, depthWrite: false, fog: false });
    this.ringMat = new THREE.MeshBasicMaterial({ color: 0xc89bff, transparent: true, opacity: 0.4, depthWrite: false, fog: false });
    this.aura = new THREE.Mesh(this.auraGeo, this.auraMat); this.pulse = new THREE.Mesh(this.ringGeo, this.ringMat);
    this.aura.visible = this.pulse.visible = false; this.aura.position.y = this.pulse.position.y = 0.08; scene.add(this.aura, this.pulse);
    this.cashFloaters = []; this.cnext = 0;
    for (let i = 0; i < CASH_FLOATERS; i++) {
      const el = document.createElement('div'); el.className = 'floater cash'; el.setAttribute('aria-hidden', 'true');
      document.body.appendChild(el); this.cashFloaters.push(el);
    }
  }

  #spawn(x, y, z, vx, vy, vz, life, size, mat, g) {
    const p = this.parts[this.next]; this.next = (this.next + 1) % POOL; // ring buffer: oldest particle is recycled
    p.m.material = mat; p.m.position.set(x, y, z); p.m.scale.setScalar(size); p.m.visible = true;
    p.vx = vx; p.vy = vy; p.vz = vz; p.life = p.max = life; p.size = size; p.g = g;
  }

  // Coin pickup: small gold sparkle burst + floating "+N" text.
  coin(x, y, z, text) {
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + Math.random() * 0.5, s = 2 + Math.random() * 2;
      this.#spawn(x, y, z, Math.cos(a) * s, 2.5 + Math.random() * 2, Math.sin(a) * s, 0.45, 0.8 + Math.random() * 0.5, this.gold, 9);
    }
    const el = this.floaters[this.fnext]; this.fnext = (this.fnext + 1) % FLOATERS;
    const v = this.tmp.set(x, y + 0.8, z).project(this.camera);
    if (v.z < 1) {
      el.textContent = text; el.style.left = ((v.x * 0.5 + 0.5) * innerWidth) + 'px'; el.style.top = ((-v.y * 0.5 + 0.5) * innerHeight) + 'px';
      el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
    }
  }

  // Cash pickup (Chapter 4): green/gold sparkle + a large "+N500 CASH" notice from the cash pool.
  cash(x, y, z, text) {
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2 + Math.random() * 0.5, s = 2 + Math.random() * 2.5;
      this.#spawn(x, y, z, Math.cos(a) * s, 2.5 + Math.random() * 2.5, Math.sin(a) * s, 0.55, 0.8 + Math.random() * 0.6, i % 2 ? this.paper : this.gold, 9);
    }
    const el = this.cashFloaters[this.cnext]; this.cnext = (this.cnext + 1) % CASH_FLOATERS;
    const v = this.tmp.set(x, y + 0.8, z).project(this.camera);
    const onScreen = v.z < 1 && Math.abs(v.x) < 1.2;
    el.textContent = text;
    el.style.left = (onScreen ? (v.x * 0.5 + 0.5) * innerWidth : innerWidth / 2) + 'px'; // off-screen fallback: centre of the screen, so the notice is never lost
    el.style.top = (onScreen ? (-v.y * 0.5 + 0.5) * innerHeight : innerHeight * 0.4) + 'px';
    el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
  }

  // Magnet pickup (Chapter 5): purple sparkle burst + a notice such as "MAGNET 8s" from its own element.
  magnet(x, y, z, text) {
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2 + Math.random() * 0.5, s = 2 + Math.random() * 2.5;
      this.#spawn(x, y, z, Math.cos(a) * s, 2.5 + Math.random() * 2.5, Math.sin(a) * s, 0.55, 0.8 + Math.random() * 0.6, i % 2 ? this.violet : this.paper, 9);
    }
    const el = this.magnetFloater, v = this.tmp.set(x, y + 0.8, z).project(this.camera);
    const onScreen = v.z < 1 && Math.abs(v.x) < 1.2;
    el.textContent = text;
    el.style.left = (onScreen ? (v.x * 0.5 + 0.5) * innerWidth : innerWidth / 2) + 'px';
    el.style.top = (onScreen ? (-v.y * 0.5 + 0.5) * innerHeight : innerHeight * 0.4) + 'px';
    el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
  }

  // Subtle purple glow under the korope while the magnet is on: a soft disc plus a ring that expands and fades (the pull range). left = seconds remaining
  // (0 = off, everything hidden). In the last 2 s the glow flickers as a warning. Cheap: no lights, no allocation, two draw calls.
  magnetAura(left, x, z, time, range = 16) {
    const on = left > 0;
    this.aura.visible = this.pulse.visible = on;
    if (!on) return;
    const ph = (time * 1.2) % 1, warn = left < 2 ? (Math.sin(time * 18) > 0 ? 1 : 0.35) : 1;
    this.aura.position.x = this.pulse.position.x = x; this.aura.position.z = this.pulse.position.z = z;
    this.auraMat.opacity = (0.2 + 0.08 * Math.sin(time * 4)) * warn;
    this.pulse.scale.setScalar(2.4 + (range - 2.4) * ph); this.ringMat.opacity = 0.45 * (1 - ph) * warn;
  }

  // Impact: sparks/debris. big = fatal crash (more particles).
  hit(x, y, z, big) {
    const n = big ? 22 : 6;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = (big ? 3 : 1.5) + Math.random() * (big ? 6 : 3);
      this.#spawn(x, y, z, Math.cos(a) * s, 1.5 + Math.random() * 4, Math.sin(a) * s, 0.5 + Math.random() * 0.4, 0.8 + Math.random() * (big ? 1.4 : 0.6), i % 3 ? this.debris : this.grey, 12);
    }
  }

  update(dt) {
    for (const p of this.parts) {
      if (!p.m.visible) continue;
      p.life -= dt;
      if (p.life <= 0) { p.m.visible = false; continue; }
      p.vy -= p.g * dt;
      p.m.position.x += p.vx * dt; p.m.position.y = Math.max(0.05, p.m.position.y + p.vy * dt); p.m.position.z += p.vz * dt;
      p.m.scale.setScalar(p.size * (p.life / p.max));
    }
  }

  reset() {
    for (const p of this.parts) p.m.visible = false;
    for (const el of this.floaters) el.classList.remove('go');
    for (const el of this.cashFloaters) el.classList.remove('go');
    this.magnetFloater.classList.remove('go'); this.aura.visible = this.pulse.visible = false; // Chapter 5: no magnet glow or notice left over
  }
}
