import * as THREE from 'three';
import { LAMENCO_D, AGUNBELEWO_D, JUNCTION, PICKUP, WAITING_PASSENGERS } from './route.js';
import { CashField, CASH_REWARD } from './cash.js';
import { MagnetBox, MAGNET_DURATION, validDuration, attract } from './magnet.js';

// buildTraffic(scene) remains the single shared traffic system; Chapter 6 only adds reusable vehicle variants.
export const ROAD = { width: 12, lanes: [-4, 0, 4], limit: 4.75, soft: 4.1 }; // limit = road half-width (6) minus the bus half-width, so the body stays on the asphalt
const CHUNK = 60, COUNT = 7;
// Chapter 8: share immutable geometry/material resources across repeated street props and traffic models.
// Meshes keep independent transforms; sharing only the underlying shape/material reduces GPU memory use
// and repeated WebGL resource creation without changing scene layout or collision behaviour.
const worldMaterialCache = new Map();
const boxGeometryCache = new Map();
const torusGeometryCache = new Map();
const sphereGeometryCache = new Map();
const icoGeometryCache = new Map();
const cacheKey = (...values) => values.map((v) => Number(v).toString()).join('|');
const M = (c) => {
  const key = String(c);
  if (!worldMaterialCache.has(key)) worldMaterialCache.set(key, new THREE.MeshLambertMaterial({ color: c }));
  return worldMaterialCache.get(key);
};
const getBoxGeometry = (w, h, d) => {
  const key = cacheKey(w, h, d);
  if (!boxGeometryCache.has(key)) boxGeometryCache.set(key, new THREE.BoxGeometry(w, h, d));
  return boxGeometryCache.get(key);
};
const getTorusGeometry = (radius, tube, radialSegments, tubularSegments, rotateY = false) => {
  const key = cacheKey(radius, tube, radialSegments, tubularSegments, rotateY ? 1 : 0);
  if (!torusGeometryCache.has(key)) {
    const geometry = new THREE.TorusGeometry(radius, tube, radialSegments, tubularSegments);
    if (rotateY) geometry.rotateY(Math.PI / 2);
    torusGeometryCache.set(key, geometry);
  }
  return torusGeometryCache.get(key);
};
const getSphereGeometry = (radius, widthSegments, heightSegments) => {
  const key = cacheKey(radius, widthSegments, heightSegments);
  if (!sphereGeometryCache.has(key)) sphereGeometryCache.set(key, new THREE.SphereGeometry(radius, widthSegments, heightSegments));
  return sphereGeometryCache.get(key);
};
const getIcoGeometry = (radius, detail) => {
  const key = cacheKey(radius, detail);
  if (!icoGeometryCache.has(key)) icoGeometryCache.set(key, new THREE.IcosahedronGeometry(radius, detail));
  return icoGeometryCache.get(key);
};
const box = (w, h, d, m, x, y, z) => { const b = new THREE.Mesh(getBoxGeometry(w, h, d), m); b.position.set(x, y, z); return b; };
const rng = (seed) => () => (seed = (seed * 16807) % 2147483647) / 2147483647; // tiny seeded random

const SHOPS = ['IYA IBEJI STORES', 'OSUN PHARMACY', 'ADUNNI FASHION', 'BOLA MOBILE', 'EKO POS & TRANSFER', 'MAMA PUT BUKKA', 'GLORY SALON', 'OSOGBO TYRES'];
const PAINTS = [0xe8c36a, 0x3f8f6b, 0xd9d2c3, 0xc9573a, 0x5aa0c8, 0xf0e0b0];
const signCache = {};
function signMaterial(text, bg) {
  const key = text + bg;
  if (signCache[key]) return signCache[key];
  const c = document.createElement('canvas'); c.width = 512; c.height = 80;
  const x = c.getContext('2d');
  x.fillStyle = '#' + new THREE.Color(bg).getHexString(); x.fillRect(0, 0, 512, 80);
  x.fillStyle = '#fff'; x.font = 'bold 42px Trebuchet MS, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(text, 256, 42);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return (signCache[key] = new THREE.MeshLambertMaterial({ map: t }));
}

const shared = {
  asphalt: M(0x34373b), line: M(0xf5f5f0), yellowLine: M(0xffc928), walk: M(0xb9b3a6),
  roof: M(0x8a4b32), trunk: M(0x5b3a24), leaf: M(0x2f7d3a), leaf2: M(0x4a9a3c), pole: M(0x6b6258), door: M(0x2b2b30),
};

// One 60 m slice of street: road, markings, pavements, poles, wires, trees, shops.
function buildChunk(index) {
  const r = rng(1000 + index * 77);
  const g = new THREE.Group();
  g.add(box(ROAD.width, 0.1, CHUNK, shared.asphalt, 0, -0.05, 0));
  for (const x of [-5.85, 5.85]) g.add(box(0.15, 0.02, CHUNK, shared.yellowLine, x, 0.02, 0));
  for (const x of [-2, 2]) for (let i = 0; i < 6; i++) g.add(box(0.15, 0.02, 4, shared.line, x, 0.02, -27.5 + i * 10));
  for (const s of [-1, 1]) {
    g.add(box(2.2, 0.25, CHUNK, shared.walk, s * 7.1, 0.05, 0));
    for (const z of [-20, 0, 20]) {
      g.add(box(0.25, 7, 0.25, shared.pole, s * 6.6, 3.5, z));
      g.add(box(2, 0.15, 0.15, shared.pole, s * 6.6, 6.7, z));
    }
    for (const dy of [6.2, 6.7]) g.add(box(0.03, 0.03, CHUNK, shared.door, s * 6.6, dy, 0));
    for (const z of [-10, 10]) {
      g.add(box(0.4, 2.8, 0.4, shared.trunk, s * 7.9, 1.4, z));
      const crown = new THREE.Mesh(getIcoGeometry(1, 0), r() > 0.5 ? shared.leaf : shared.leaf2);
      crown.scale.setScalar(1.8 + r() * 0.6); // shared unit geometry keeps the tree canopy varied without allocating a new shape per tree
      crown.position.set(s * 7.9, 4.2, z); g.add(crown);
    }
    for (const z of [-20, 0, 20]) {
      const h = 4 + r() * 5, paint = PAINTS[Math.floor(r() * PAINTS.length)];
      g.add(box(6, h, 14, M(paint), s * 11.5, h / 2, z));
      g.add(box(6.4, 0.3, 14.4, shared.roof, s * 11.5, h + 0.15, z)); // rusty corrugated roof
      const face = s * 8.5, rot = s < 0 ? Math.PI / 2 : -Math.PI / 2;
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(9, 1.4), signMaterial(SHOPS[Math.floor(r() * SHOPS.length)], [0x1f4fb5, 0x2e7d32, 0xb71c1c][Math.floor(r() * 3)]));
      sign.position.set(face - s * 0.03, 3.3, z); sign.rotation.y = rot; g.add(sign);
      g.add(box(0.1, 2.3, 2.2, shared.door, face, 1.15, z - 2.5));
    }
  }
  return g;
}


// ---- Chapter 6 traffic variety: cars remain the majority; motorcycles and bicycles use the same traffic/collision lifecycle.
// Probabilities can be overridden with createWorld(scene, { trafficProbabilities: { motorcycle: .14, bicycle: .08 } }).
const LANE_SPEED = { '-4': 11, '0': 8, '4': 10 };
const CAR_COLOURS = [0xd62828, 0xf2f2ee, 0x2e7d32, 0xe07b20, 0x9aa0a6, 0x6a3fa0];
const TRAFFIC_DEFAULTS = { motorcycle: 0.14, bicycle: 0.08 };
function buildTraffic(scene, opts = {}) {
  const dark = M(0x1a2433), tail = new THREE.MeshLambertMaterial({ color: 0xd62828, emissive: 0x801010 });
  const probs = { ...TRAFFIC_DEFAULTS, ...(opts.trafficProbabilities || {}) };
  probs.motorcycle = Math.max(0, Math.min(0.45, Number(probs.motorcycle) || 0));
  probs.bicycle = Math.max(0, Math.min(0.35, Number(probs.bicycle) || 0));
  if (probs.motorcycle + probs.bicycle > 0.45) { const scale = 0.45 / (probs.motorcycle + probs.bicycle); probs.motorcycle *= scale; probs.bicycle *= scale; }
  const random = typeof opts.trafficRandom === 'function' ? opts.trafficRandom : rng((Date.now() % 2147483646) + 1);
  const list = [];
  function model(lane, i) {
    const root = new THREE.Group();
    // Car/truck model (always prepared, hidden when this traffic slot is a rider).
    const car = new THREE.Group(), paint = M(CAR_COLOURS[i % CAR_COLOURS.length]);
    const truck = i % 3 === 2, hl = truck ? 2.6 : 2.1;
    if (truck) { car.add(box(2.1, 1.5, 5.2, paint, 0, 1.1, 0)); car.add(box(2.0, 0.7, 1.4, dark, 0, 1.55, -1.9)); }
    else { car.add(box(2.0, 0.8, 4.2, paint, 0, 0.8, 0)); car.add(box(1.8, 0.7, 2.2, dark, 0, 1.5, 0.3)); }
    for (const sx of [-1, 1]) car.add(box(0.35, 0.2, 0.08, tail, sx * 0.7, 0.9, hl));
    for (const sx of [-1, 1]) for (const z of [-hl + 0.8, hl - 0.8]) car.add(box(0.3, 0.7, 0.7, dark, sx * 1.0, 0.35, z));
    root.add(car);
    // Motorcycle: two wheels, frame/body, seat and a clearly visible rider + helmet.
    const moto = new THREE.Group(), rubber = M(0x17191c), metal = M(0xd2d5d8), bikePaint = M([0xe04424, 0x1976d2, 0x252525, 0xebb92f][i % 4]), skin = M(0x754b30);
    const wheelGeo = getTorusGeometry(0.36, 0.085, 6, 12, true);
    for (const z of [-0.72, 0.72]) { const w = new THREE.Mesh(wheelGeo, rubber); w.position.set(0, 0.38, z); moto.add(w); }
    moto.add(box(0.22, 0.18, 1.05, metal, 0, 0.62, 0)); moto.add(box(0.34, 0.34, 0.65, bikePaint, 0, 0.8, -0.05));
    moto.add(box(0.38, 0.12, 0.5, dark, 0, 0.98, 0.3)); moto.add(box(0.34, 0.48, 0.28, M(0x263238), 0, 1.27, 0.15));
    const mh = new THREE.Mesh(getSphereGeometry(0.19, 10, 8), M(0x111820)); mh.position.set(0, 1.65, 0.03); moto.add(mh);
    moto.add(box(0.15, 0.12, 0.55, skin, 0, 1.43, -0.05));
    moto.scale.setScalar(1.28); root.add(moto);
    // Bicycle: slim frame, visible wheels and rider; much slower than powered traffic.
    const cycle = new THREE.Group(), cycleFrame = M(0x1f9b75), riderCloth = M([0x2d67c7, 0xd64a35, 0x5b8f35, 0x7b3fa0][i % 4]);
    const cycleWheelGeo = getTorusGeometry(0.34, 0.055, 5, 12, true);
    for (const z of [-0.68, 0.68]) { const w = new THREE.Mesh(cycleWheelGeo, rubber); w.position.set(0, 0.36, z); cycle.add(w); }
    cycle.add(box(0.07, 0.07, 0.85, cycleFrame, 0, 0.65, 0)); cycle.add(box(0.07, 0.07, 0.62, metal, 0, 0.66, -0.3));
    cycle.add(box(0.09, 0.09, 0.42, cycleFrame, 0, 0.77, 0.28)); cycle.add(box(0.35, 0.08, 0.2, dark, 0, 0.9, 0.3));
    cycle.add(box(0.28, 0.48, 0.22, riderCloth, 0, 1.15, 0.05));
    const ch = new THREE.Mesh(getSphereGeometry(0.14, 8, 7), skin); ch.position.set(0, 1.5, -0.02); cycle.add(ch);
    cycle.add(box(0.3, 0.09, 0.3, M(0x222831), 0, 1.61, -0.02));
    cycle.scale.setScalar(1.48); root.add(cycle); root.add(new THREE.Group()); // empty compatibility anchor; all vehicle variants remain inside this one traffic slot
    scene.add(root);
    const v = { g: root, slot: i, lane, speed: LANE_SPEED[lane], x: lane, z: -9999, hw: 1, hl, type: 'car', models: { car, motorcycle: moto, bicycle: cycle }, lengths: { car: hl, motorcycle: 1.28, bicycle: 1.02 }, widths: { car: 1, motorcycle: 0.58, bicycle: 0.42 } };
    return v;
  }
  function chooseType(v) {
    const r = random();
    v.type = r < probs.bicycle ? 'bicycle' : r < probs.bicycle + probs.motorcycle ? 'motorcycle' : 'car';
    for (const [type, g] of Object.entries(v.models)) g.visible = type === v.type;
    v.cruiseSpeed = v.type === 'bicycle' ? 3.2 + random() * 2.4 : v.type === 'motorcycle' ? 11 + random() * 5 : LANE_SPEED[v.lane];
    v.speed = v.cruiseSpeed;
    v.hw = v.widths[v.type]; v.hl = v.lengths[v.type];
  }
  // Nine reusable slots (three per lane); cars are the clear majority, riders are occasional.
  for (const lane of ROAD.lanes) for (let k = 0; k < 2; k++) { const v = model(lane, list.length); chooseType(v); list.push(v); }
  return { list, chooseType, probabilities: probs, random };
}

// ---- Milestone 6A: route landmarks (Lamenco junction + traffic light + pickup bay + waiting passengers, Agunbelewo gate).
// Built once in a group whose z is the route origin; local z = -d (d = metres along the route). Moved by setRouteOrigin().
const flat = (w, d, m, x, y, z, ry = 0) => { const b = box(w, 0.02, d, m, x, y, z); b.rotation.y = ry; return b; };
function gantry(text, bg, d) { // sign across the whole road
  const g = new THREE.Group(), post = M(0x4a4f57);
  for (const s of [-1, 1]) g.add(box(0.4, 7, 0.4, post, s * 6.6, 3.5, 0));
  g.add(box(13.6, 1.9, 0.3, M(bg), 0, 6.3, 0));
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(9, 1.4), signMaterial(text, bg)); sign.position.set(0, 6.3, 0.2); g.add(sign);
  g.position.z = -d; return g;
}
function buildRoute() {
  const g = new THREE.Group(), white = shared.line, yellow = shared.yellowLine;
  // Lamenco junction: hatched box, zebra crossing, stop line, traffic lights (decorative: always green, they do not control traffic)
  const jd = JUNCTION.d, jh = JUNCTION.half, len = jh * 2;
  g.add(flat(12, len, M(0x3d4045), 0, 0.01, -jd));
  g.add(flat(12, 0.3, yellow, 0, 0.03, -(jd - jh))); g.add(flat(12, 0.3, yellow, 0, 0.03, -(jd + jh)));
  const ang = Math.atan2(12, len), diag = Math.hypot(12, len);
  g.add(flat(0.2, diag, yellow, 0, 0.03, -jd, ang)); g.add(flat(0.2, diag, yellow, 0, 0.03, -jd, -ang));
  for (let i = -3; i <= 3; i++) g.add(flat(0.8, 3, white, i * 1.55, 0.03, -(jd - jh - 3)));
  g.add(flat(12, 0.5, white, 0, 0.03, -(jd - jh - 6)));
  const dim = M(0x3a1a1a), amber = M(0x4a3a10), green = new THREE.MeshLambertMaterial({ color: 0x38d96b, emissive: 0x1a8a3a });
  for (const s of [-1, 1]) {
    const lz = -(jd - jh - 8);
    g.add(box(0.3, 4.6, 0.3, shared.pole, s * 6.4, 2.3, lz)); g.add(box(0.6, 1.6, 0.45, shared.door, s * 6.4, 4.9, lz));
    [[dim, 5.4], [amber, 4.9], [green, 4.4]].forEach(([m, y]) => g.add(box(0.32, 0.32, 0.1, m, s * 6.4, y, lz + 0.26)));
  }
  g.add(gantry('LAMENCO JUNCTION', 0x1f4fb5, jd));
  // Pickup bay (left lane edge): green painted area, yellow outline, STOP HERE text, shelter and sign board
  const bz = -(PICKUP.start + PICKUP.end) / 2, bl = PICKUP.end - PICKUP.start, bx = (PICKUP.xMin + PICKUP.xMax) / 2, bw = PICKUP.xMax - PICKUP.xMin - 0.1;
  g.add(flat(bw, bl, M(0x2e9d57), bx, 0.03, bz));
  for (const x of [PICKUP.xMax, PICKUP.xMin + 0.1]) g.add(flat(0.15, bl, yellow, x, 0.045, bz));
  for (const z of [-PICKUP.start, -PICKUP.end]) g.add(flat(bw, 0.15, yellow, bx, 0.045, z));
  const txt = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 0.47), signMaterial('TERMINAL', 0x1f7a3a)); txt.rotation.x = -Math.PI / 2; txt.position.set(bx, 0.06, bz); g.add(txt);
  g.add(box(0.2, 3.6, 0.2, shared.pole, -6.2, 1.8, -PICKUP.start + 1));
  const board = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 0.7), signMaterial('TERMINAL', 0x2e7d32)); board.position.set(-6.2, 3.7, -PICKUP.start + 1.1); g.add(board);
  for (const z of [-PICKUP.start - 3, -PICKUP.end + 3]) g.add(box(0.15, 2.4, 0.15, shared.pole, -8.7, 1.2, z));
  g.add(box(1.8, 0.15, bl - 4, M(0x1f4fb5), -8.7, 2.45, bz));
  // Waiting passengers on the pavement (shared geometry/materials; first N are hidden when N board)
  const bodyG = getBoxGeometry(0.45, 0.95, 0.3), headG = getBoxGeometry(0.28, 0.28, 0.28), limbGeo = getBoxGeometry(0.13, 0.48, 0.14);
  const clothes = [0xe53935, 0xfdd835, 0x43a047, 0x8e24aa, 0xff7043, 0xf5f5f5].map((c) => M(c)), skins = [0x6b4226, 0x8d5a36, 0x4a2c17].map((c) => M(c)), legMat = M(0x2b3036);
  const people = [];
  for (let i = 0; i < WAITING_PASSENGERS; i++) {
    const p = new THREE.Group(); const torso = new THREE.Mesh(bodyG, clothes[i % clothes.length]); torso.position.y = 0.6; p.add(torso);
    const head = new THREE.Mesh(headG, skins[i % skins.length]); head.position.y = 1.28; p.add(head);
    const limbMat = clothes[i % clothes.length];
    const armL = new THREE.Mesh(limbGeo, limbMat), armR = new THREE.Mesh(limbGeo, limbMat), legL = new THREE.Mesh(limbGeo, legMat), legR = new THREE.Mesh(limbGeo, legMat);
    armL.position.set(-0.31,0.65,0); armR.position.set(0.31,0.65,0); legL.position.set(-0.13,0.23,0); legR.position.set(0.13,0.23,0); p.add(armL,armR,legL,legR);
    p.userData.walkParts = [armL,armR,legL,legR];
    p.position.set(i % 2 ? -7.6 : -6.8, 0.2, -(PICKUP.start + 4 + (i / (WAITING_PASSENGERS - 1)) * (PICKUP.end - PICKUP.start - 8)));
    p.userData.start = p.position.clone(); p.userData.boarding = false; p.userData.boarded = false;
    g.add(p); people.push(p);
  }
  // Agunbelewo: end-of-route gate and a chequered strip
  g.add(gantry('AGUNBELEWO - END OF ROUTE', 0xb71c1c, AGUNBELEWO_D));
  for (let i = -5; i <= 5; i++) g.add(flat(1.2, 1.2, i % 2 ? white : shared.door, i * 1.1, 0.03, -AGUNBELEWO_D + 3));
  return { g, people };
}

// Chapter 9 — a connected, recognisable Osogbo streetscape. This city layer is built once (low-poly,
// reusable materials) and anchored to the trip origin, so it remains aligned when a run is restarted.
export const CITY_JUNCTIONS = [
  { id: 'station-road', name: 'STATION ROAD', d: 220 },
  { id: 'old-garage', name: 'OLD GARAGE', d: 470 },
  { id: 'oja-oba', name: 'OJA OBA', d: 700 },
  { id: 'igbona', name: 'IGBONA', d: 900 },
  { id: 'lamenco', name: 'LAMENCO', d: 1000 },
  { id: 'alekuwoodo', name: 'ALEKUWODO', d: 1230 },
  { id: 'oke-baale', name: 'OKE BAALE', d: 1480 },
  { id: 'gra', name: 'GRA', d: 1730 },
  { id: 'oroiki-estate', name: 'OROKI ESTATE', d: 1980 },
  { id: 'ilobu-road', name: 'ILOBU ROAD', d: 2210 },
  { id: 'gbodofon', name: 'GBODOFON', d: 2440 },
];
export const CITY_LANDMARKS = [
  { id: 'oja-oba-market', name: 'OJA OBA MARKET', d: 700 },
  { id: 'central-mosque', name: 'OSOGBO CENTRAL MOSQUE', d: 850 },
  { id: 'nike-art-centre', name: 'NIKE ART CENTRE', d: 1430 },
  { id: 'sacred-grove', name: 'OSUN-OSOGBO SACRED GROVE', d: 1990 },
];
function buildCity() {
  const g = new THREE.Group();
  const concrete = M(0xaaa69c), road = M(0x424449), white = shared.line, yellow = shared.yellowLine;
  const signPost = M(0x555b60), marketPaint = [0xb64d36, 0xd2a342, 0x477a59, 0xeee0bd].map(M);
  // Connected side streets join the existing main road at real junction positions. Geometry is deliberately
  // lightweight; these are navigable-looking streetscape connections, not a claim of survey-accurate mapping.
  for (let i = 0; i < CITY_JUNCTIONS.length; i++) {
    const j = CITY_JUNCTIONS[i], z = -j.d;
    g.add(box(116, 0.08, 8, road, 0, -0.035, z));
    g.add(box(116, 0.025, 0.13, yellow, 0, 0.015, z));
    for (const x of [-52, -42, -32, -22, -12, -2, 8, 18, 28, 38, 48]) g.add(box(4.2, 0.02, 0.12, white, x, 0.02, z + 2.0));
    // Junction corner paving and zebra stripes.
    g.add(box(13, 0.035, 3.2, concrete, -9.5, 0.015, z - 6.1));
    g.add(box(13, 0.035, 3.2, concrete, 9.5, 0.015, z + 6.1));
    for (let k = -5; k <= 5; k++) {
      g.add(box(0.55, 0.025, 2.1, white, k * 1.1, 0.04, z - 5.1));
      g.add(box(0.55, 0.025, 2.1, white, k * 1.1, 0.04, z + 5.1));
    }
    // Named street signposts at the edges of each cross street.
    for (const side of [-1, 1]) {
      const x = side * 9.5;
      g.add(box(0.12, 3.1, 0.12, signPost, x, 1.55, z - 2.4));
      const plate = new THREE.Mesh(new THREE.PlaneGeometry(5.8, 0.85), signMaterial(j.name, 0x175a45));
      plate.position.set(x + side * 2.7, 2.55, z - 2.4); plate.rotation.y = side < 0 ? Math.PI / 2 : -Math.PI / 2; g.add(plate);
    }
    // Each district gets a varied cluster of low-rise shops and homes; no external models or downloads.
    const districtPaint = [0xd5b78a, 0xc86b4b, 0x8ca78a, 0xd7d0b8, 0x7f9eaf, 0xe1c96c].map(M);
    for (const side of [-1, 1]) {
      for (let n = 0; n < 3; n++) {
        const x = side * (17 + n * 10), zz = z + (n - 1) * 13 + (i % 2 ? 3 : -3);
        const h = 3.8 + ((i * 3 + n * 2) % 4) * 0.85, w = 7.5 + (n % 2) * 1.5;
        g.add(box(w, h, 8.5, districtPaint[(i + n + (side > 0 ? 2 : 0)) % districtPaint.length], x, h / 2, zz));
        g.add(box(w + 0.35, 0.32, 8.8, n === 1 ? marketPaint[i % marketPaint.length] : shared.roof, x, h + 0.15, zz));
        g.add(box(1.3, 1.8, 0.08, shared.door, x, 1.0, zz + (side < 0 ? 4.28 : -4.28)));
      }
    }
    // A bus-stop shelter at selected districts, facing the main street.
    if (i % 2 === 0) {
      const x = i % 4 === 0 ? -8.1 : 8.1;
      g.add(box(2.4, 0.12, 3.8, M(0x247c59), x, 2.35, z - 10));
      for (const dx of [-1, 1]) g.add(box(0.12, 2.2, 0.12, signPost, x + dx, 1.15, z - 10));
      g.add(box(1.8, 0.08, 1.5, M(0x4e5d62), x, 0.65, z - 10));
      const stop = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.7), signMaterial('BUS STOP', 0x176b4b));
      stop.position.set(x, 2.0, z - 8.05); g.add(stop);
    }
  }
  // Landmark modules are distinctive silhouettes placed at their named route distances.
  const landmarkSign = (label, x, z, colour = 0x8a2e26) => {
    g.add(box(0.18, 3.6, 0.18, signPost, x, 1.8, z));
    g.add(box(7.8, 1.05, 0.22, M(colour), x, 3.15, z));
    const text = new THREE.Mesh(new THREE.PlaneGeometry(7.4, 0.72), signMaterial(label, colour));
    text.position.set(x, 3.15, z + 0.13); g.add(text);
  };
  // Oja Oba: open market stalls with bright awnings and a central entrance sign.
  const marketZ = -700;
  for (let side of [-1, 1]) for (let n = 0; n < 4; n++) {
    const x = side * (18 + (n % 2) * 7), z = marketZ + (n - 1.5) * 5.5;
    g.add(box(5.8, 2.8, 4.2, marketPaint[n % marketPaint.length], x, 1.4, z));
    g.add(box(6.2, 0.22, 4.6, marketPaint[(n + 1) % marketPaint.length], x, 2.9, z));
    g.add(box(1.5, 1.4, 0.08, shared.door, x, 0.8, z + (side < 0 ? 2.15 : -2.15)));
  }
  landmarkSign('OJA OBA MARKET', -23, marketZ - 13, 0x8e3527);
  // Osogbo Central Mosque: central dome, two minarets, and arched facade cues.
  const mosqueZ = -850, mosqueX = 25, mosqueWhite = M(0xe8e3d6), domeMat = M(0x4f9e82);
  g.add(box(15, 6, 13, mosqueWhite, mosqueX, 3, mosqueZ));
  { const dome = new THREE.Mesh(new THREE.SphereGeometry(4.1, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), domeMat); dome.position.set(mosqueX, 6, mosqueZ); g.add(dome); }
  for (const dx of [-8.5, 8.5]) {
    g.add(box(1.7, 10, 1.7, mosqueWhite, mosqueX + dx, 5, mosqueZ));
    { const minaretCap = new THREE.Mesh(new THREE.ConeGeometry(1.3, 2.5, 8), domeMat); minaretCap.position.set(mosqueX + dx, 11.2, mosqueZ); g.add(minaretCap); }
  }
  landmarkSign('OSOGBO CENTRAL MOSQUE', 26, mosqueZ - 11, 0x176b4b);
  // Nike Art Centre: gallery block, bold abstract colour panels, and a large stylised art sculpture.
  const artZ = -1430, artX = -25;
  g.add(box(15, 6.5, 14, M(0xd9b783), artX, 3.25, artZ));
  g.add(box(15.4, 0.45, 14.4, M(0x6c3427), artX, 6.7, artZ));
  for (let n = 0; n < 5; n++) g.add(box(1.65, 3.5, 0.22, M([0xc43e36, 0x176b4b, 0xd7a92e, 0x304e8a, 0x762d69][n]), artX - 5.5 + n * 2.75, 3.4, artZ + 7.15));
  { const sculpture = new THREE.Mesh(new THREE.TorusKnotGeometry(2.3, 0.42, 48, 6), M(0xc58b24)); sculpture.position.set(artX - 10, 3.1, artZ - 4); g.add(sculpture); }
  landmarkSign('NIKE ART CENTRE', -26, artZ - 13, 0x8e3527);
  // Osun-Osogbo Sacred Grove entrance: timber gate, symbolic carved forms and lush trees.
  const groveZ = -1990, groveX = 27, wood = M(0x563a28);
  for (const dx of [-7, 7]) g.add(box(0.8, 7.5, 0.8, wood, groveX + dx, 3.75, groveZ));
  g.add(box(15.5, 0.9, 0.9, wood, groveX, 7.2, groveZ));
  for (const dx of [-5, -2.5, 0, 2.5, 5]) {
    g.add(box(0.22, 4.2 + (Math.abs(dx) % 3), 0.25, M(0x735036), groveX + dx, 2.2, groveZ - 0.3));
    { const groveCanopy = new THREE.Mesh(new THREE.ConeGeometry(1.8, 3.4, 7), M(dx % 2 ? 0x2f7d3a : 0x4a9a3c)); groveCanopy.position.set(groveX + dx, 5.2, groveZ - 6 - (Math.abs(dx) % 2) * 2); g.add(groveCanopy); }
  }
  for (const side of [-1, 1]) for (let n = 0; n < 4; n++) {
    const x = groveX + side * (14 + n * 4), treeZ = groveZ - (n % 2) * 11;
    g.add(box(0.55, 3.4, 0.55, shared.trunk, x, 1.7, treeZ));
    { const canopy = new THREE.Mesh(new THREE.IcosahedronGeometry(2.7 + (n % 2) * 0.4, 0), shared.leaf); canopy.position.set(x, 4.8, treeZ); g.add(canopy); }
  }
  landmarkSign('OSUN-OSOGBO SACRED GROVE', 27, groveZ - 15, 0x176b4b);
  // Retain existing journey names and add a visible route gate near the current destination.
  landmarkSign('AGUNBELEWO', -24, -AGUNBELEWO_D + 15, 0x8e3527);
  return { g };
}


// opts.cashReward: naira per cash bundle (Chapter 4, default CASH_REWARD = 500). opts.random: optional 0..1 generator for the cash layout (tests).
// opts.magnetDuration: seconds the purple magnet (Chapter 5) stays on after a pickup box (default MAGNET_DURATION = 8).
export function createWorld(scene, opts = {}) {
  scene.background = new THREE.Color(0xf3cf98);
  scene.fog = new THREE.Fog(0xf3cf98, 60, 230);
  scene.add(new THREE.HemisphereLight(0xfff0d0, 0x8a5a3a, 1.6));
  const sun = new THREE.DirectionalLight(0xffe2a8, 2.2); sun.position.set(-30, 50, 20); scene.add(sun);
  const sunDisc = new THREE.Mesh(new THREE.SphereGeometry(14, 16, 16), new THREE.MeshBasicMaterial({ color: 0xfff1b8, fog: false }));
  scene.add(sunDisc);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), M(0xb2623a)); // laterite red earth
  ground.rotation.x = -Math.PI / 2; scene.add(ground);

  const chunks = [];
  for (let i = 0; i < COUNT; i++) { const c = buildChunk(i); c.position.z = CHUNK - i * CHUNK; scene.add(c); chunks.push(c); }

  const coinGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.12, 20); coinGeo.rotateX(Math.PI / 2);
  const coinMat = new THREE.MeshLambertMaterial({ color: 0xffc928, emissive: 0x7a5a00 });
  const coins = [];
  const placeCoin = (c, z) => c.position.set(ROAD.lanes[Math.floor(Math.random() * 3)], 1.1, z);
  for (let i = 0; i < 30; i++) { const c = new THREE.Mesh(coinGeo, coinMat); placeCoin(c, -25 - i * 9); scene.add(c); coins.push(c); }

  const trafficSystem = buildTraffic(scene, opts), traffic = trafficSystem.list;
  const trafficByLane = new Map(ROAD.lanes.map((lane) => [lane, []])); // reused buckets: one predictable following pass, no per-frame bucket allocation
  // Chapter 4: naira bundles mixed among the coins. Spots next to a coin, or where a car will be when the bus gets there, are avoided.
  let lastPz = 0, cashGot = 0;
  const cashField = new CashField(scene, { reward: opts.cashReward ?? CASH_REWARD, random: opts.random, avoid: (x, z) => {
    for (const c of coins) if (Math.abs(c.position.x - x) < 1.8 && Math.abs(c.position.z - z) < 4) return true;
    const eta = Math.max(0, (lastPz - z) / 28); // roughly when the bus arrives, so a slow car is not sitting on the bundle
    for (const v of traffic) if (Math.abs(v.x - x) < 1.8 && Math.abs(v.z - v.speed * eta - z) < 7) return true;
    return false;
  } });
  // Chapter 5: one rare purple magnet box. While the timer runs, coins and cash bundles (only those) are pulled towards the korope.
  let magnetLeft = 0, magnetDuration = validDuration(opts.magnetDuration) ? opts.magnetDuration : MAGNET_DURATION, onMagnet = null, onMagnetEnd = null;
  const magnetBox = new MagnetBox(scene, { random: opts.magnetRandom, avoid: (x, z) => {
    for (const c of coins) if (Math.abs(c.position.x - x) < 1.8 && Math.abs(c.position.z - z) < 4) return true;
    for (const b of cashField.items) if (Math.abs(b.g.position.x - x) < 2.5 && Math.abs(b.g.position.z - z) < 8) return true;
    const eta = Math.max(0, (lastPz - z) / 28);
    for (const v of traffic) if (Math.abs(v.x - x) < 1.8 && Math.abs(v.z - v.speed * eta - z) < 7) return true;
    return false;
  } });
  magnetBox.onCollect = (x, y, z) => { // picking up another box while active just refreshes the timer to the full duration (no stacking)
    const was = magnetLeft > 0; magnetLeft = magnetDuration;
    if (onMagnet) onMagnet(x, y, z, was);
  };
  const stopMagnet = () => { magnetLeft = 0; if (onMagnetEnd) onMagnetEnd(); }; // runs once per magnet: on expiry or on a crash
  const route = buildRoute(); scene.add(route.g);
  const city = buildCity(); scene.add(city.g);
  let routeOrigin = 0, pickupClear = false, boarded = 0;
  let boardingQueue = [], boardingActive = [], boardingDone = true, boardingTarget = { x: -4, z: 0 };  // pickupClear: keep lane -4 free of cars right behind the bus near the bay
  let onCoin = null; // optional (x, y, z) callback fired once per collected coin
  let diff = 0; // 0..1, set by main from distance travelled
  const placeCar = (v, pz, respawn = true) => {
    // Preserve the established spacing algorithm; the shared lane list also accounts for shorter riders.
    let far = pz - 200;
    for (const o of traffic) if (o !== v && o.lane === v.lane && o.z < far && o.z > pz - 400) far = o.z;
    v.z = Math.max(far - (45 - 13 * diff) - Math.random() * (40 - 10 * diff), pz - 400);
    if (respawn) trafficSystem.chooseType(v);
  };
  const resetTraffic = (pz) => { // lane-by-lane stagger gives every traffic type a clear initial headway
    for (const lane of ROAD.lanes) {
      const row = traffic.filter((v) => v.lane === lane);
      row.forEach((v, i) => { if (v.slot > 0) trafficSystem.chooseType(v); v.z = pz - 90 - i * 105 - Math.random() * 14; });
    }
  };
  resetTraffic(0);

  return {
    resetTraffic,
    get traffic() { return traffic; },
    get trafficProbabilities() { return { ...trafficSystem.probabilities }; },
    // Route landmarks: set where the route starts (world z), hide the first n waiting passengers, keep the bay approach clear of rear traffic.
    setRouteOrigin(z) { routeOrigin = z; route.g.position.z = z; city.g.position.z = z; },
    get cityMap() { return { junctions: CITY_JUNCTIONS, landmarks: CITY_LANDMARKS }; },
    setBoarded(n, busX = -4, busZ = routeOrigin) {
      boarded = Math.max(0, Math.min(route.people.length, Math.floor(n || 0))); boardingQueue = []; boardingActive = []; boardingDone = boarded === 0;
      route.people.forEach((p, i) => { p.position.copy(p.userData.start); p.visible = true; p.userData.boarding = false; p.userData.boarded = false; p.rotation.set(0,0,0); for(const part of (p.userData.walkParts||[]))part.rotation.x=0; });
      if (boarded > 0) { boardingDone = false; boardingTarget = { x: busX - 1.55, z: busZ - routeOrigin }; for(let i=0;i<boarded;i++) boardingQueue.push(route.people[i]); }
    },
    get boardingDone() { return boardingDone; },
    setPickupClear(on) { pickupClear = !!on; },
    get routeOrigin() { return routeOrigin; },
    setCoinHandler(fn) { onCoin = fn; },
    // Chapter 4 cash: handler(x, y, z, amount) fires once per collected bundle; cashGot = naira collected by the last update() call.
    setCashHandler(fn) { cashField.onCollect = fn; },
    setCashReward(n) { return cashField.setReward(n); },
    resetCash(pz) { lastPz = pz; cashField.reset(pz); cashGot = 0; },
    get cashReward() { return cashField.reward; },
    get cashGot() { return cashGot; },
    cash: cashField,
    // Chapter 5 magnet: handler(x, y, z, wasActive) fires once per collected box (wasActive = the timer was refreshed); endHandler() fires once when the magnet stops.
    setMagnetHandler(fn) { onMagnet = fn; },
    setMagnetEndHandler(fn) { onMagnetEnd = fn; },
    setMagnetDuration(n) { if (validDuration(n)) magnetDuration = n; return magnetDuration; },
    get magnetDuration() { return magnetDuration; },
    get magnetLeft() { return magnetLeft; },       // seconds remaining (0 = off)
    get magnetActive() { return magnetLeft > 0; },
    clearMagnet() { if (magnetLeft > 0) stopMagnet(); },                // crash: the magnet stops at once
    resetMagnet(pz) { magnetLeft = 0; lastPz = pz; magnetBox.reset(pz); }, // PLAY / RESTART: off, and a fresh box ahead
    magnetBox,
    setDifficulty(d) { diff = Math.min(1, Math.max(0, d)); },
    // Returns the first traffic vehicle overlapping the player's box (or null), with penetration depths.
    collide(px, pz, hw = 1.1, hl = 2.5) {
      for (const v of traffic) {
        const dx = px - v.x, dz = pz - v.z, ox = hw + v.hw - Math.abs(dx), oz = hl + v.hl - Math.abs(dz);
        if (ox > 0 && oz > 0) return { v, dx, dz, ox, oz };
      }
      return null;
    },
    // Call every frame with the player's position. Returns coins collected this frame (collect=false: coins are ignored, e.g. after a crash).
    update(dt, px, pz, time, collect = true) {
      for (const c of chunks) if (c.position.z - pz > CHUNK * 1.5) c.position.z -= CHUNK * COUNT; // recycle chunks behind us
      ground.position.set(px, -0.12, pz); sunDisc.position.set(-60, 55, pz - 280);
      let got = 0;
      // Chapter 5: the timer only runs (and the pull only works) while the game is being played: collect=false (menu, crash) pauses nothing here, and a paused game never calls update().
      let ticked = false;
      if (collect && magnetLeft > 0) {
        for (const c of coins) attract(c.position, px, pz, dt);            // coins and cash bundles ONLY: traffic, passengers, signs and scenery are never touched
        for (const b of cashField.items) attract(b.g.position, px, pz, dt);
        magnetLeft -= dt; ticked = true; // expiry is checked after this frame's box pickup, so a refresh in the last frame keeps it running
      }
      for (const c of coins) {
        c.rotation.y = time * 3;
        if (c.position.z - pz > 12) placeCoin(c, pz - 250 - Math.random() * 60);
        else if (collect && Math.abs(c.position.x - px) < 1.4 && Math.abs(c.position.z - pz) < 2.2) { if (onCoin) onCoin(c.position.x, c.position.y, c.position.z); placeCoin(c, pz - 260 - Math.random() * 60); got++; } // moved away at once, so it can never be collected twice
      }
      lastPz = pz; cashGot = cashField.update(dt, px, pz, time, collect);
      magnetBox.update(dt, px, pz, time, collect); // its onCollect (above) starts or refreshes the timer
      if (ticked && magnetLeft <= 0) stopMagnet();
      const dBus = routeOrigin - pz, clearing = pickupClear && dBus > PICKUP.start - 60 && dBus < PICKUP.end + 5;
      route.people.forEach((p, i) => { if (p.visible && !p.userData.boarding) p.position.y = 0.2 + Math.max(0, Math.sin(time * 3 + i * 1.7)) * 0.035; });
      while (boardingActive.length < 3 && boardingQueue.length) { const p = boardingQueue.shift(); p.userData.boarding = true; p.userData.target = { x: boardingTarget.x, z: Math.max(boardingTarget.z - 1.5, Math.min(boardingTarget.z + 1.5, p.position.z)) }; boardingActive.push(p); }
      for (let bi = boardingActive.length - 1; bi >= 0; bi--) {
        const p = boardingActive[bi], target = p.userData.target || boardingTarget, dx = target.x - p.position.x, dz = target.z - p.position.z, dist = Math.hypot(dx,dz), step = Math.min(dist, 3.5 * dt);
        if (dist > 0.06) { p.position.x += dx / dist * step; p.position.z += dz / dist * step; p.rotation.y = Math.atan2(dx, -dz); const swing = Math.sin(time * 13 + bi) * 0.48; (p.userData.walkParts||[]).forEach((part,j)=>part.rotation.x = (j < 2 ? -swing : swing)); }
        else { p.visible = false; p.userData.boarding = false; p.userData.boarded = true; boardingActive.splice(bi,1); }
      }
      if (!boardingQueue.length && !boardingActive.length) boardingDone = true;
      // Two-phase, lane-local traffic update. All speeds are decided from the same frame snapshot,
      // then all vehicles move together. This avoids update-order artefacts where one vehicle sees
      // its neighbour before movement while another sees it after movement. The buckets are reused.
      for (const row of trafficByLane.values()) row.length = 0;
      for (const v of traffic) trafficByLane.get(v.lane).push(v);
      for (const row of trafficByLane.values()) {
        row.sort((a, b) => a.z - b.z); // the first vehicle is furthest ahead (more-negative z)
        for (let i = 0; i < row.length; i++) {
          const v = row[i], ahead = i > 0 ? row[i - 1] : null;
          let nextSpeed = v.cruiseSpeed;
          if (ahead) {
            const nearestGap = v.z - ahead.z, safeGap = v.hl + ahead.hl + 4;
            if (nearestGap < safeGap + 8) nextSpeed = Math.min(v.cruiseSpeed, Math.max(0, ahead.nextSpeed + (nearestGap - safeGap) * 1.2));
          }
          v.nextSpeed = nextSpeed;
        }
      }
      for (const v of traffic) {
        v.speed = Number.isFinite(v.nextSpeed) ? v.nextSpeed : v.cruiseSpeed;
        v.z -= v.speed * dt;
        if (clearing && v.lane === -4 && v.z - pz > 8 && v.z - pz < 80) placeCar(v, pz); // a car right behind would shove the stopped bus
        if (v.z - pz > 20 || v.z - pz < -420) placeCar(v, pz);
        v.g.position.set(v.x, 0, v.z);
      }
      return got;
    },
  };
}
