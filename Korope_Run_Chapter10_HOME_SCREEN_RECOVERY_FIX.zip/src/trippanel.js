// Chapter 3: the trip panel (toggle + objective + passengers/fare + route map).
// - The header (objective, passengers, fare) is ALWAYS visible. Only the map can be hidden.
// - Size and position are worked out from the real HUD row and the real GAS/BRAKE/REVERSE row, so the panel
//   never sits on pause, mute, the buttons or the steering area, in portrait or landscape.
import { mapLayout, PANEL_GAP } from './minimap.js';

const PREF_KEY = 'koroperun_map_open';
const FALLBACK_HEADER_H = 92;

export class TripPanel {
  constructor(minimap, doc = document) {
    this.doc = doc; this.minimap = minimap;
    this.trip = doc.getElementById('trip'); this.toggle = doc.getElementById('mapToggle');
    this.stats = doc.getElementById('tripStats'); this.hud = doc.getElementById('hud');
    this.expanded = this.#loadPref();     // what the player asked for (the map may still be hidden if there is no room)
    this.last = null;
    this.toggle.addEventListener('click', () => this.setExpanded(!this.expanded));
    const relayout = () => this.layout();
    addEventListener('resize', relayout);
    addEventListener('orientationchange', () => setTimeout(relayout, 200)); // some phones report the new size a moment late
    if (typeof ResizeObserver !== 'undefined' && this.hud) new ResizeObserver(relayout).observe(this.hud); // the HUD can wrap to 2 rows as numbers grow
  }
  #loadPref() { try { return localStorage.getItem(PREF_KEY) !== '0'; } catch (e) { return true; } }
  #savePref() { try { localStorage.setItem(PREF_KEY, this.expanded ? '1' : '0'); } catch (e) { /* private mode: just not remembered */ } }

  setExpanded(on) { this.expanded = !!on; this.#savePref(); this.layout(); }

  // Measure the free band, ask mapLayout for sizes, apply. Returns the layout (or null while the HUD is not on screen yet).
  layout() {
    const W = innerWidth, H = innerHeight, hudR = this.hud.getBoundingClientRect();
    if (!hudR || hudR.height <= 0) return null;                       // menu screen: nothing to place yet
    const pad = this.doc.querySelector('#touch .pad'), padR = pad ? pad.getBoundingClientRect() : null;
    const rowTop = padR && padR.height > 0 ? padR.top : H - 12;       // no touch buttons (desktop): use the bottom of the window
    const top = Math.round(hudR.bottom + PANEL_GAP), bottom = Math.round(rowTop - PANEL_GAP);
    const headerH = (this.toggle.offsetHeight + this.stats.offsetHeight) || FALLBACK_HEADER_H;
    const L = mapLayout({ W, H, top, bottom, headerH });
    this.last = { ...L, top, bottom, headerH };
    this.#apply(L, top);
    return this.last;
  }
  #apply(L, top) {
    const show = this.expanded && L.canExpand;                        // is the map actually visible?
    const t = this.trip, m = this.minimap;
    t.style.top = top + 'px'; t.style.width = L.w + 'px';
    t.classList.toggle('compact', L.compact); t.classList.toggle('collapsed', !show);
    if (L.canExpand) m.setSize(L.w, L.mapH);
    else if (m.w !== L.w) m.setSize(L.w, m.h);
    m.visible = show; m.key = '';                                      // redraw on the next frame after showing
    this.toggle.classList.toggle('hidden', !L.canExpand);             // no room for a map: no point offering the button
    this.toggle.textContent = show ? '\u25B2 HIDE MAP' : '\u25BC SHOW MAP';
    this.toggle.setAttribute('aria-expanded', String(show));
    this.toggle.setAttribute('aria-label', show ? 'Hide map' : 'Show map');
  }
  get mapVisible() { return !!(this.last && this.expanded && this.last.canExpand); }
}
