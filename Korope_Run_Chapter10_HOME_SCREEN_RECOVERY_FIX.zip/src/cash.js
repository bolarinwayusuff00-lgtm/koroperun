import * as THREE from 'three';

// Chapter 4: collectible naira cash bundles.
// - A small pool of bundles (POOL) is built once and reused forever: no allocation, no new geometry/materials after start-up.
// - A bundle is an upright brick (about 1.5 x 0.95 m, a bit bigger than a coin so it reads from far away) of notes (one box, shared geometry) with a paper band and a printed N-with-two-bars symbol on the notes.
// - Bundles are rare compared with coins (about one per 110-200 m; coins come roughly every 9 m) and sit at varied, reachable x slots.
// - Cash is its own counter: it is never added to coins, score, best score or passenger fares.

export const CASH_REWARD = 500; // naira per bundle (default). Change here, pass { reward } to CashField / { cashReward } to createWorld, or call setReward().
export const NAIRA = '₦';

export const CASH = {
  POOL: 3,                          // bundles alive at once (rare: they are spread 110-200 m apart)
  GAP_MIN: 110, GAP_MAX: 200,       // metres between consecutive bundles
  FIRST_MIN: 80, FIRST_MAX: 130,    // first bundle after a (re)start is this far ahead
  SLOTS: [-4, -2, 0, 2, 4],         // x positions: the three lanes and the two line gaps. All are inside the road limit (4.75) so the korope can reach them
  RADIUS_X: 1.5, RADIUS_Z: 2.4,     // pickup box around the bundle (coins use 1.4 / 2.2)
  Y: 1.25, BOB: 0.14, BOB_SPEED: 2.4,           // gentle bobbing
  SWAY: 1.0, SWAY_SPEED: 1.3, TILT: 0.2,        // slow turning: swings +/-1 rad (57 deg) either side of facing the camera, so the printed faces are never edge-on
  PASSED: 12,                       // a bundle this far behind the korope is recycled to the front
};

const seeded = (seed) => () => (seed = (seed * 16807) % 2147483647) / 2147483647; // tiny seeded random (same generator style as world.js)
const validReward = (n) => Number.isFinite(n) && n > 0;
export const formatNaira = (n) => NAIRA + Math.round(n).toLocaleString('en-US');

// Printed face of the notes (a few fillRect/fillText calls on a tiny canvas; falls back to plain colour when no canvas is available).
function noteTexture() {
  try {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = 256; c.height = 160;
    const x = c.getContext('2d'); if (!x) return null;
    x.fillStyle = '#2f9e57'; x.fillRect(0, 0, 256, 160);
    x.fillStyle = '#7fd69a'; x.fillRect(6, 6, 244, 148);
    x.fillStyle = '#2f9e57'; x.fillRect(12, 12, 232, 136);
    x.fillStyle = '#e8ffe9'; x.font = 'bold 104px Arial, Helvetica, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(NAIRA, 52, 84); x.fillText(NAIRA, 204, 84); // one on each side of the paper band
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 2;
    return t;
  } catch (e) { return null; }
}
function bandTexture() {
  try {
    if (typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = 64; c.height = 128;
    const x = c.getContext('2d'); if (!x) return null;
    x.fillStyle = '#f4e7c3'; x.fillRect(0, 0, 64, 128);
    x.fillStyle = '#c0392b'; x.fillRect(0, 0, 64, 10); x.fillRect(0, 118, 64, 10); // red edge stripes
    x.fillStyle = '#7a1f14'; x.font = 'bold 54px Arial, Helvetica, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(NAIRA, 32, 66);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  } catch (e) { return null; }
}

export class CashField {
  // opts: scene (required), reward, random (0..1 generator, for tests), avoid(x, z) -> true when a spot is already taken (coins / traffic)
  constructor(scene, opts = {}) {
    this.scene = scene;
    this.reward = validReward(opts.reward) ? Math.round(opts.reward) : CASH_REWARD;
    this.random = opts.random || seeded(Math.floor(Math.random() * 2147483646) + 1); // own generator: cash never consumes the random stream that lays out coins and traffic
    this.avoid = opts.avoid || null;
    this.onCollect = null;      // (x, y, z, amount) fired exactly once per collected bundle
    this.collected = 0;         // bundles collected since the last reset()
    this.lastSlot = -1;
    this.disposed = false;

    // Shared geometry/materials: every bundle reuses them.
    const edge = new THREE.MeshLambertMaterial({ color: 0x8fd19f, emissive: 0x1f4d2c });
    const face = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x2a6a3a, map: noteTexture() });
    if (!face.map) face.color.set(0x3aa560);
    const bandFace = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x6a5a38, map: bandTexture() });
    if (!bandFace.map) bandFace.color.set(0xf4e7c3);
    const bandSide = new THREE.MeshLambertMaterial({ color: 0xf4e7c3, emissive: 0x6a5a38 });
    this.bodyGeo = new THREE.BoxGeometry(1.5, 0.95, 0.5);
    this.bandGeo = new THREE.BoxGeometry(0.38, 1.03, 0.56);
    this.bodyMats = [edge, edge, edge, edge, face, face]; // +x -x +y -y +z -z: printed faces front and back
    this.bandMats = [bandSide, bandSide, bandSide, bandSide, bandFace, bandFace];
    this.mats = [edge, face, bandFace, bandSide];

    this.items = [];
    for (let i = 0; i < CASH.POOL; i++) {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(this.bodyGeo, this.bodyMats), new THREE.Mesh(this.bandGeo, this.bandMats));
      g.position.set(0, CASH.Y, -9999); g.rotation.order = 'YXZ'; scene.add(g);
      this.items.push({ g, phase: i * 2.1 });
    }
    this.reset(0);
  }

  setReward(n) { if (validReward(n)) this.reward = Math.round(n); return this.reward; }

  #gap() { return CASH.GAP_MIN + this.random() * (CASH.GAP_MAX - CASH.GAP_MIN); }

  // Put a bundle at world z in a varied x slot (never the same slot twice in a row), nudging away from taken spots.
  #place(b, z) {
    let x = 0;
    for (let tries = 0; tries < 6; tries++) {
      let slot = Math.floor(this.random() * CASH.SLOTS.length);
      if (slot === this.lastSlot) slot = (slot + 1 + Math.floor(this.random() * (CASH.SLOTS.length - 1))) % CASH.SLOTS.length;
      x = CASH.SLOTS[slot]; this.lastSlot = slot;
      if (!this.avoid || !this.avoid(x, z)) break;
      z -= 4; // blocked: slide a little further ahead and try another slot
    }
    b.g.position.set(x, CASH.Y, z); b.g.visible = true;
  }

  // Start a fresh layout ahead of pz: clears the collected counter and re-places every bundle (no leftovers after restart).
  reset(pz = 0) {
    this.collected = 0; this.lastSlot = -1;
    let z = pz - CASH.FIRST_MIN - this.random() * (CASH.FIRST_MAX - CASH.FIRST_MIN);
    for (const b of this.items) { this.#place(b, z); z -= this.#gap(); }
  }

  // The next free spot beyond every other bundle (and beyond the view), so spacing stays 110-200 m.
  #nextZ(self, pz) {
    let far = pz - 60;
    for (const o of this.items) if (o !== self && o.g.position.z < far) far = o.g.position.z;
    return far - this.#gap();
  }

  // Call every frame. Returns the naira collected this frame (0 when collect=false, e.g. before PLAY or after a crash).
  update(dt, px, pz, time, collect = true) {
    let naira = 0;
    for (const b of this.items) {
      const p = b.g.position;
      b.g.rotation.y = Math.sin(time * CASH.SWAY_SPEED + b.phase) * CASH.SWAY; b.g.rotation.x = CASH.TILT;
      p.y = CASH.Y + Math.sin(time * CASH.BOB_SPEED + b.phase) * CASH.BOB;
      if (p.z - pz > CASH.PASSED) { this.#place(b, this.#nextZ(b, pz)); continue; } // missed: recycle to the front
      if (collect && Math.abs(p.x - px) < CASH.RADIUS_X && Math.abs(p.z - pz) < CASH.RADIUS_Z) {
        const x = p.x, y = p.y, z = p.z;
        this.#place(b, this.#nextZ(b, pz)); // moved far ahead at once, so the same bundle can never pay twice
        this.collected++; naira += this.reward;
        if (this.onCollect) this.onCollect(x, y, z, this.reward);
      }
    }
    return naira;
  }

  // Remove everything this field added to the scene and free GPU resources.
  dispose() {
    if (this.disposed) return; this.disposed = true;
    for (const b of this.items) this.scene.remove(b.g);
    this.items.length = 0;
    this.bodyGeo.dispose(); this.bandGeo.dispose();
    for (const m of this.mats) { if (m.map) m.map.dispose(); m.dispose(); }
  }
}
