import { ROUTE, PICKUP } from './route.js';
// GPS-style route strip. The street is a straight line in the game world, so the map is a straight line too:
// bottom = Oke-Fia, top = Agunbelewo. Stop positions come from ROUTE, the player's dot from the live bus position.
export const mapY = (d, h, pad = 14) => { const t = Math.min(1, Math.max(0, d / ROUTE.length)); return h - pad - t * (h - 2 * pad); };

// ---- Responsive sizing (pure maths, so it can be tested). ----
// The trip panel sits at the top-right, between the HUD row (pause / mute) and the GAS-BRAKE-REVERSE row.
// `top` / `bottom` are the free band in px; `headerH` is the always-visible part (toggle + objective + passengers/fare).
export const MIN_MAP_H = 80;          // below this the map is not worth drawing: the panel stays collapsed (labels would collide)
export const PANEL_GAP = 8;           // px kept clear around the panel
const PANEL_BORDER = 4;               // the yellow bottom border
export function mapLayout({ W, H, top, bottom, headerH }) {
  const compact = Math.min(W, H) < 600;               // phones (either orientation); tablets and desktop use the roomy size
  const portrait = H > W;
  const w = compact ? 88 : 96;
  const cap = compact ? (portrait ? 140 : 120) : Math.round(Math.min(200, Math.max(120, H * 0.32))); // desktop cap = the original sizing rule
  const room = Math.floor(bottom - top - headerH - PANEL_BORDER);
  const mapH = Math.max(0, Math.min(cap, room));
  const canExpand = mapH >= MIN_MAP_H;
  return { compact, portrait, w, cap, mapH: canExpand ? mapH : 0, canExpand };
}

export class Minimap {
  constructor(canvas) {
    this.c = canvas; this.ctx = canvas.getContext ? canvas.getContext('2d') : null; this.w = 96; this.h = 180; this.dpr = 1; this.key = ''; this.visible = true;
    this.resize();
  }
  resize() { this.setSize(this.w, Math.round(Math.min(200, Math.max(120, innerHeight * 0.32)))); } // initial size; TripPanel takes over once the game starts
  setSize(w, h) {
    this.w = w; this.h = h; this.dpr = Math.min(typeof devicePixelRatio === 'number' ? devicePixelRatio : 1, 2);
    this.c.width = this.w * this.dpr; this.c.height = this.h * this.dpr;
    if (this.c.style) { this.c.style.width = this.w + 'px'; this.c.style.height = this.h + 'px'; }
    this.key = '';
  }
  draw(d, x, journey) {
    const ctx = this.ctx; if (!ctx || !this.visible) return; // hidden (collapsed): nothing to draw
    const key = Math.round(d) + '|' + Math.round(x * 2) + '|' + journey.stage + journey.pickup; if (key === this.key) return; this.key = key;
    const { w, h } = this, small = w < 96, lx = small ? 17 : 22; // slightly tighter on phones so 'Agunbelewo' still fits
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(27,27,34,.72)'; ctx.fillRect(0, 0, w, h);
    const py = mapY(d, h), yBottom = mapY(0, h), yTop = mapY(ROUTE.length, h);
    ctx.lineCap = 'round'; ctx.lineWidth = 6; ctx.strokeStyle = '#8a8f98'; ctx.beginPath(); ctx.moveTo(lx, yBottom); ctx.lineTo(lx, yTop); ctx.stroke(); // whole route
    ctx.strokeStyle = '#ffc928'; ctx.beginPath(); ctx.moveTo(lx, yBottom); ctx.lineTo(lx, py); ctx.stroke();                                          // driven part
    // pickup bay (left side of the road = left of the line)
    ctx.fillStyle = journey.pickup === 'done' ? '#7be07b' : '#3ddc84'; ctx.fillRect(lx - 11, mapY(PICKUP.end, h), 5, mapY(PICKUP.start, h) - mapY(PICKUP.end, h));
    ctx.font = 'bold ' + (small ? 9 : 10) + 'px Trebuchet MS, sans-serif'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    for (const s of ROUTE.stops) {
      const y = mapY(s.d, h); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(lx, y, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = s.id === 'lamenco' ? '#ffc928' : '#fff'; ctx.fillText(s.name, lx + 10, y + (s.id === 'oke-fia' ? -6 : s.id === 'agunbelewo' ? 8 : 0));
    }
    // player: blue arrow pointing along the route; small sideways offset mirrors the lane position
    const px = lx + Math.max(-1, Math.min(1, x / 6)) * 4;
    ctx.fillStyle = '#079fb8'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(px, py - 8); ctx.lineTo(px + 6, py + 6); ctx.lineTo(px, py + 3); ctx.lineTo(px - 6, py + 6); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
}
