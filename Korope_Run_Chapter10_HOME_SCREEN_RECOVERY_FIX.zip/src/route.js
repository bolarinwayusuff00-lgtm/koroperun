// Milestone 6A: route + journey logic. Pure data/logic (no Three.js, no DOM) so it can be unit-tested.
// The game world is one straight street driven toward -Z. Route distance "d" = metres driven along it since the trip started
// (main.js computes d = routeOriginZ - bus.z, so restarts work even though the bus keeps its world z).
// Route: Oke-Fia (d=0, start) -> Lamenco (junction at d=1000) -> Agunbelewo (d=2600, end).
export const LAMENCO_D = 1000, AGUNBELEWO_D = 2600;
export const ROUTE = {
  name: 'Oke-Fia \u2192 Lamenco \u2192 Agunbelewo',
  length: AGUNBELEWO_D,
  stops: [
    { id: 'oke-fia', name: 'Oke-Fia', d: 0 },
    { id: 'lamenco', name: 'Lamenco', d: LAMENCO_D },
    { id: 'agunbelewo', name: 'Agunbelewo', d: AGUNBELEWO_D },
  ],
};
// Lamenco junction (traffic light) is centred at LAMENCO_D and spans +/-8 m. The pickup bay is on the LEFT of the road,
// 45-75 m BEFORE the junction, so stopping there never blocks the crossing.
export const JUNCTION = { d: LAMENCO_D, half: 8 };
export const PICKUP = { start: LAMENCO_D - 75, end: LAMENCO_D - 45, xMax: -2.4, xMin: -6 }; // bay: route distance range and x range (left side)

export const FARE_PER_PASSENGER = 200;   // naira per passenger
export const DEFAULT_CAPACITY = 9;       // seats the korope can load
export const WAITING_PASSENGERS = 12;    // people at the stop (more than capacity, so the limit matters)
export const PICKUP_MAX_SPEED = 1.0;     // m/s (3.6 km/h): "nearly stopped"
export const BOARD_HOLD = 0.6;           // seconds the bus must stay (nearly) stopped in the bay before boarding

export const inPickupZone = (d, x) => d >= PICKUP.start && d <= PICKUP.end && x <= PICKUP.xMax && x >= PICKUP.xMin;

export class Journey {
  constructor({ capacity = DEFAULT_CAPACITY, waiting = WAITING_PASSENGERS, farePerPassenger = FARE_PER_PASSENGER } = {}) {
    const n = (v, f) => (Number.isFinite(v) && v >= 0 ? Math.floor(v) : f);
    this.capacity = n(capacity, DEFAULT_CAPACITY); this.waiting = n(waiting, WAITING_PASSENGERS); this.fareEach = n(farePerPassenger, FARE_PER_PASSENGER);
    this.reset();
  }
  reset() {
    this.stage = 'toLamenco';   // 'toLamenco' | 'toAgunbelewo' | 'arrived'
    this.pickup = 'pending';    // 'pending' | 'done' | 'missed'  (boarding happens at most once per trip)
    this.reachedLamenco = false; this.reachedAgunbelewo = false;
    this.passengers = 0; this.fare = 0;   // independent of coins / score / best score
    this.hold = 0;                         // seconds stopped inside the bay so far
  }
  get holdProgress() { return Math.min(1, this.hold / BOARD_HOLD); }
  // Call each frame while playing. Returns an event string the first time something happens, otherwise null.
  update(dt, d, x, speed) {
    let ev = null;
    if (!this.reachedLamenco && d >= PICKUP.start) { this.reachedLamenco = true; ev = 'reachedLamenco'; }
    if (this.pickup === 'pending') {
      if (inPickupZone(d, x) && speed <= PICKUP_MAX_SPEED) {
        this.hold += dt;
        if (this.hold >= BOARD_HOLD) {
          this.pickup = 'done'; this.stage = 'toAgunbelewo';
          this.passengers = Math.min(this.capacity, this.waiting);
          this.fare = this.passengers * this.fareEach;
          this.hold = 0; ev = 'boarded';
        }
      } else this.hold = 0; // moving, or left the bay: progress restarts
      if (this.pickup === 'pending' && d > PICKUP.end) { this.pickup = 'missed'; this.stage = 'toAgunbelewo'; this.hold = 0; ev = ev || 'missed'; }
    }
    if (!this.reachedAgunbelewo && d >= AGUNBELEWO_D) { this.reachedAgunbelewo = true; this.stage = 'arrived'; ev = ev || 'arrived'; }
    return ev;
  }
  // Short text for the minimap panel.
  objective(d) {
    const km = (m) => (m >= 1000 ? (m / 1000).toFixed(1) + ' km' : Math.max(0, Math.round(m)) + ' m');
    if (this.stage === 'arrived') return 'Arrived';
    if (this.stage === 'toLamenco') return d >= PICKUP.start ? 'Stop in bay' : 'Lamenco ' + km(PICKUP.start - d);
    return 'Agunbelewo ' + km(AGUNBELEWO_D - d);
  }
}
