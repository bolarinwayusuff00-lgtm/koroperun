import { formatNaira } from './cash.js';
// Simple DOM HUD + menu screens.
const $ = (id) => document.getElementById(id);

export class Hud {
  constructor() {
    this.el = { hud: $('hud'), touch: $('touch'), start: $('startScreen'), pause: $('pauseScreen'),
      over: $('overScreen'), flash: $('flash'), overDist: $('overDist'), overCoins: $('overCoins'), overBest: $('overBest'),
      score: $('score'), overScore: $('overScore'), overNew: $('overNew'),
      speed: $('speed'), speedUnit: $('speedUnit'), distance: $('distance'), coins: $('coins'), balance: $('balance'), cash: $('cash'), overCash: $('overCash'),
      magnet: $('magnetStat'), magnetText: $('magnetText'), terminalArrow: $('terminalArrow'), trip: $('trip'), hint: $('hint'), banner: $('banner'), objective: $('objective'), pax: $('pax'), cap: $('cap'), fare: $('fare') };
    this.rev = false; this.arrowShown = false; this.hintKey = ''; this.bar = null; this.cashShown = null; this.balanceShown = null; this.magnetShown = 0;
  }
  showGame() { this.el.start.classList.add('hidden'); this.el.hud.classList.remove('hidden'); this.el.touch.classList.remove('hidden'); this.el.trip.classList.remove('hidden'); }
  showPause(on) { this.el.pause.classList.toggle('hidden', !on); }
  // Terminal arrow: the element and its CSS animation exist once; this only flips the class when the state actually changes.
  showTerminalArrow(on) { on = !!on; if (on === this.arrowShown || !this.el.terminalArrow) return; this.arrowShown = on; this.el.terminalArrow.classList.toggle('hidden', !on); }
  showGameOver(score, coins, distM, bestScore, isBest, cash = 0) {
    this.el.overScore.textContent = score; this.el.overCoins.textContent = coins; if (this.el.overCash) this.el.overCash.textContent = formatNaira(cash);
    this.el.overDist.textContent = (distM / 1000).toFixed(2); this.el.overBest.textContent = bestScore;
    this.el.overNew.classList.toggle('hidden', !isBest); this.el.over.classList.remove('hidden');
  }
  hideGameOver() { this.el.over.classList.add('hidden'); }
  flash(big) { const f = this.el.flash; f.classList.remove('go', 'big'); void f.offsetWidth; f.classList.add(big ? 'big' : 'go'); }
  clearFlash() { this.el.flash.classList.remove('go', 'big'); }
  pulseCoins() { const e = this.el.coins.parentElement; e.classList.remove('pop'); void e.offsetWidth; e.classList.add('pop'); }
  pulseCash() { const e = this.el.cash.parentElement; e.classList.remove('pop'); void e.offsetWidth; e.classList.add('pop'); }
  pulseBalance() { const e = this.el.balance?.parentElement; if (!e) return; e.classList.remove('pop'); void e.offsetWidth; e.classList.add('pop'); }
  // Chapter 4: cash counter (naira). Separate from coins, score, best score and fares; only touches the DOM when the value changes.
  updateCash(cash) { if (cash === this.cashShown) return; this.cashShown = cash; this.el.cash.textContent = formatNaira(cash); }
  updateBalance(balance) { if (!this.el.balance || balance === this.balanceShown) return; this.balanceShown = balance; this.el.balance.textContent = formatNaira(balance); }
  // Chapter 5: purple "MAGNET 8s" countdown. left = seconds remaining (0 hides it). Only touches the DOM when the whole-second value changes.
  updateMagnet(left) {
    const sec = left > 0 ? Math.ceil(left - 1e-9) : 0, e = this.el.magnet; if (!e) return;
    if (sec === this.magnetShown) return;
    const was = this.magnetShown; this.magnetShown = sec;
    if (sec === 0) { e.classList.add('hidden'); e.classList.remove('low', 'pop'); return; }
    this.el.magnetText.textContent = 'MAGNET ' + sec + 's';
    e.classList.toggle('low', sec <= 2);
    if (was === 0) { // just appeared: sit just below the HUD row (it can wrap on phones), outside the row so the trip panel never has to move
      e.classList.remove('hidden');
      const r = this.el.hud && this.el.hud.getBoundingClientRect ? this.el.hud.getBoundingClientRect() : null;
      if (r && r.height > 0) e.style.top = Math.round(r.bottom + 6) + 'px';
    }
  }
  pulseMagnet() { const e = this.el.magnet; if (!e) return; e.classList.remove('pop'); void e.offsetWidth; e.classList.add('pop'); }
  update(speedMs, distanceM, coins, score, reversing = false) {
    if (reversing !== this.rev) { this.rev = reversing; this.el.speedUnit.textContent = reversing ? 'km/h \u00B7 R' : 'km/h'; } // tiny gear indicator
    this.el.score.textContent = score;
    this.el.speed.textContent = Math.round(speedMs * 3.6);
    this.el.distance.textContent = (distanceM / 1000).toFixed(2);
    this.el.coins.textContent = coins;
  }
  // Milestone 6A: trip panel (passengers/fare are separate from coins and score), hint line and success banner.
  updateTrip(objective, passengers, capacity, fare) {
    this.el.objective.textContent = objective; this.el.pax.textContent = passengers; this.el.cap.textContent = capacity;
    this.el.fare.textContent = fare.toLocaleString('en-US');
  }
  // text '' hides the hint; progress (0..1) shows a boarding bar. Only touches the DOM when something changed.
  setHint(text, progress = -1) {
    const key = text + '|' + (progress < 0 ? '-' : Math.round(progress * 20));
    if (key === this.hintKey) return; this.hintKey = key;
    const h = this.el.hint;
    if (!text) { h.classList.add('hidden'); return; }
    h.classList.remove('hidden'); h.textContent = text;
    if (progress >= 0) { const bar = document.createElement('span'); bar.className = 'bar'; const i = document.createElement('i'); i.style.width = Math.round(progress * 100) + '%'; bar.appendChild(i); h.appendChild(bar); }
  }
  celebrate(title, sub) {
    const b = this.el.banner; b.firstElementChild.textContent = title; b.lastElementChild.textContent = sub;
    b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
    const t = this.el.trip; t.classList.remove('pop'); void t.offsetWidth; t.classList.add('pop');
  }
  clearTrip() { this.hintKey = ''; this.el.hint.classList.add('hidden'); this.el.banner.classList.remove('go'); }
}
